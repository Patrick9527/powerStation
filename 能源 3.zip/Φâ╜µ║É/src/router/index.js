import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

import Layout from '@/layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    name: '登录',
    component: () => import('@/views/login/index'),
    hidden: true
  },

  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },
  {
    path: '/',
    component: Layout,
    name: '主页',
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        component: () => import('@/views/dashboard/index'),
        name: 'dashboard',
        meta: { title: '主页', icon: 'el-icon-toilet-paper' }
      }
    ]
  },
  {
    path: '/',
    component: Layout,
    name: '发电步道',
    redirect: '/powertrail',
    children: [
      {
        path: 'powertrail',
        component: () => import('@/views/powertrail/index'),
        name: 'powertrail',
        meta: { title: '发电步道', icon: 'el-icon-toilet-paper' }
      }
    ]
  },
  {
    path: '/energy',
    component: Layout,
    name: '能耗统计',
    redirect: '/energy/bridge',
    children: [
      {
        path: '/energy/bridge',
        component: () => import('@/views/energy/bridge'),
        name: 'QC',
        meta: { title: '岸桥电耗', icon: 'el-icon-toilet-paper' }
      }, {
        path: '/energy/shore-power',
        component: () => import('@/views/energy/andian'),
        name: 'AD',
        meta: { title: '岸电电耗', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/energy/crane',
        component: () => import('@/views/energy/crane'),
        name: 'ASC',
        meta: { title: '轨道吊电耗', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/energy/agv',
        component: () => import('@/views/energy/agv'),
        name: 'AGV',
        meta: { title: 'AGV电耗', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/energy/agvSingle',
        component: () => import('@/views/energy/agvSingle'),
        name: 'AGVSingle',
        meta: { title: 'AGV电耗（设备）', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/energy/icebox',
        component: () => import('@/views/energy/icebox'),
        name: 'YARD',
        meta: { title: '冷箱电耗', icon: 'el-icon-toilet-paper' }
      },
      // {
      //   path: '/energy/iceboxStatistics',
      //   component: () => import('@/views/energy/iceboxStatistics'),
      //   name: 'iceboxStatistics',
      //   meta: { title: '冷箱能耗统计', icon: 'el-icon-toilet-paper' }
      // },
      {
        path: '/energy/produceEnergy',
        component: () => import('@/views/energy/produceEnergy'),
        name: 'ZHSC',
        meta: { title: '综合生产电耗', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/energy/livingEnergy',
        component: () => import('@/views/energy/livingEnergy'),
        name: 'BGSH',
        meta: { title: '办公生活电耗', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/energy/otherEnergy',
        component: () => import('@/views/energy/otherEnergy'),
        name: 'QTNH',
        meta: { title: '其他电耗', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/energy/otherEnergyConsume',
        component: () => import('@/views/energy/otherEnergyConsume'),
        name: 'QTNYXH',
        meta: { title: '其他能源消耗', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/energy/SCEH',
        component: () => import('@/views/energy/sche'),
        name: 'SCZHNH',
        meta: { title: '生产综合能耗', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/energy/ZHXH',
        component: () => import('@/views/energy/zhxh'),
        name: 'ZHNH',
        meta: { title: '综合能耗', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/energy/qtwh',
        component: () => import('@/views/energy/qtwh'),
        name: 'QTNYWH',
        meta: { title: '其他能源维护', icon: 'el-icon-toilet-paper' }
      }
    ]
  },
  {
    path: '/work',
    component: Layout,
    name: '作业统计',
    redirect: '/work/bridge',
    children: [
      {
        path: '/work/bridge',
        component: () => import('@/views/work/bridge'),
        name: 'bridgeWork',
        meta: { title: '岸桥作业', icon: 'el-icon-toilet-paper', id: 'QC', select: '桥吊' }
      },
      {
        path: '/work/crane',
        component: () => import('@/views/work/crane'),
        name: 'craneWork',
        meta: { title: '轨道吊作业', icon: 'el-icon-toilet-paper', id: 'ASC', select: '轨道吊' }
      },
      {
        path: '/work/agv',
        component: () => import('@/views/work/agv'),
        name: 'agvWork',
        meta: { title: 'AGV作业', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/work/icebox',
        component: () => import('@/views/work/icebox'),
        name: 'iceboxWork',
        meta: { title: '冷箱作业', icon: 'el-icon-toilet-paper', id: 'YARD', select: '堆场' }
      }
    ]
  },
  {
    path: '/green',
    redirect: '/green/index',
    component: Layout,
    name: '绿色能源监控',
    children: [
      {
        path: '/green/index',
        component: () => import('@/views/green/overall'),
        name: 'greenOverall',
        meta: { title: '总览', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/green/Wind',
        component: () => import('@/views/green/wind'),
        name: 'greenWind',
        meta: { title: '风能监测', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/green/Light',
        component: () => import('@/views/green/light'),
        name: 'greenLight',
        meta: { title: '光能监测', icon: 'el-icon-toilet-paper' }
      }
    ]
  },
  {
    path: '/cost',
    component: Layout,
    name: '能源成本报表',
    redirect: '/cost/electron',
    children: [
      {
        path: '/cost/electron',
        component: () => import('@/views/cost/electron'),
        name: 'costElectron',
        meta: { title: '月度用电汇总表', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/cost/energy',
        component: () => import('@/views/cost/energy'),
        name: 'costEnergy',
        meta: { title: '月度能耗表', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/cost/monthly',
        component: () => import('@/views/cost/monthly'),
        name: 'monthly',
        meta: { title: '月单耗指标', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/cost/stockReport',
        component: () => import('@/views/cost/stock'),
        name: 'stockReport',
        meta: { title: '月度冷箱用电量和堆存量报表', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/cost/boxNumber',
        component: () => import('@/views/cost/boxNumber'),
        name: 'boxNumber',
        meta: { title: '月度冷箱堆存天数和对应箱量（自然箱）统计表', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/cost/temp',
        component: () => import('@/views/cost/temp'),
        name: 'temp',
        meta: { title: '月度冷箱温差值和对应箱量（自然箱）统计表', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/cost/monthlyCost',
        component: () => import('@/views/cost/monthlyCost'),
        name: 'temp',
        meta: { title: '月度能耗成本表', icon: 'el-icon-toilet-paper' }
      }
    ]
  },
  {
    path: '/analysis',
    component: Layout,
    name: '成本分析',
    redirect: '/analysis/bridge',
    children: [
      {
        path: '/analysis/bridge',
        component: () => import('@/views/analysis/bridgeCost'),
        name: 'analysisBridge',
        meta: { title: '岸桥成本分析', icon: 'el-icon-toilet-paper', name: 'QC', label: '桥吊' }
      },
      {
        path: '/analysis/crane',
        component: () => import('@/views/analysis/craneCost'),
        name: 'analysisCrane',
        meta: { title: '轨道吊成本分析', icon: 'el-icon-toilet-paper', name: 'ASC', label: '轨道吊' }
      },
      {
        path: '/analysis/agv',
        component: () => import('@/views/analysis/agvCost'),
        name: 'analysisAGV',
        meta: { title: 'AGV成本分析', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/analysis/agvSingle',
        component: () => import('@/views/analysis/agvSingle'),
        name: 'analysisAGVSingle',
        meta: { title: 'AGV成本分析（设备）', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/analysis/icebox',
        component: () => import('@/views/analysis/iceboxCost'),
        name: 'analysisIcebox',
        meta: { title: '冷箱成本分析', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/analysis/produce',
        component: () => import('@/views/analysis/produceCost'),
        name: 'analysisProduce',
        meta: { title: '综合生产成本分析', icon: 'el-icon-toilet-paper', name: 'ZHSC', label: '综合生产' }
      },
      {
        path: '/analysis/living',
        component: () => import('@/views/analysis/livingCost'),
        name: 'analysisLiving',
        meta: { title: '办公生活成本分析', icon: 'el-icon-toilet-paper', name: 'BGSH', label: '办公生活' }
      }
    ]
  },
  {
    path: '/feedback',
    component: Layout,
    name: '能源回馈',
    children: [
      {
        path: '/feedback',
        component: () => import('@/views/feedback/index'),
        name: 'feedback',
        meta: { title: '能源回馈', icon: 'el-icon-toilet-paper' }
      }
    ]
  },
  {
    path: '/fee',
    component: Layout,
    name: '电费',
    children: [
      {
        path: '/fee',
        component: () => import('@/views/fee/index'),
        name: 'fee',
        meta: { title: '电费', icon: 'el-icon-toilet-paper' }
      }
    ]
  },
  {
    path: '/alarm',
    component: Layout,
    name: '预警管理',
    children: [
      {
        path: '/alarm',
        component: () => import('@/views/alarm/index'),
        name: 'alarm',
        meta: { title: '预警设置', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/alarm/alarmInfo',
        component: () => import('@/views/alarm/alarmInfo'),
        name: 'alarmInfo',
        meta: { title: '报警列表', icon: 'el-icon-toilet-paper' }
      },
      {
        path: '/alarm/earlyAlarm',
        component: () => import('@/views/alarm/earlyAlarm'),
        name: 'earlyAlarm',
        meta: { title: '预警列表', icon: 'el-icon-toilet-paper' }
      }
    ]
  },
  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () =>
  new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRoutes
  })
const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  // 重置路由的思路是 重新生成路由实例，把静态路由重新赋值给路由实例
  const newRouter = createRouter()
  // 重置路由规则
  router.matcher = newRouter.matcher // reset router
}

export default router
