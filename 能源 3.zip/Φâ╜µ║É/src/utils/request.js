import axios from 'axios'
import { MessageBox, Message } from 'element-ui'
import store from '@/store'
import { storage } from '@/utils/utils'

// 根据环境更改基地址
const env = process.env.NODE_ENV
console.log(env)
const service = axios.create({
  // baseURL: process.env.VUE_APP_BASE_API,
  baseURL: env === 'development' ? '/power' : process.env.VUE_APP_BASE_API,
  withCredentials: true,
  timeout: 50000,
})

// response interceptor
service.interceptors.response.use(
  (response) => {
    if (response.status === 200) {
      if (response.data.code && response.data.code !== '200') {
        Message.error(response.data.ErrorText || response.data.message)
      }
      const res = response.data
      return res
    } else {
      Message.error(response.data.ErrorText)
    }
  },
  (error) => {
    console.log('err' + error) // for debug
    if (error.response) {
      if (error.response.status === 401) {
        MessageBox.alert('登录信息超时，请重新登录', '登录超时', {
          confirmButtonText: '确定',
          callback: (action) => {
            storage.clear()
            store.dispatch('user/resetToken').then(() => {
              location.reload()
            })
            const url = window.location.href
            const redirect_uri = `${url.substring(0, url.lastIndexOf('#'))}#/login`
            window.location.href = redirect_uri
          },
        })
      } else {
        Message.error('网络错误')
      }
      return Promise.reject(error)
    }
  }
)

export default service
