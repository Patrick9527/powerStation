import moment from 'moment'
import 'moment/locale/zh-cn'
moment.locale('zh-cn')

export const storage = {
  set(key, value, expire = false) {
    window.localStorage.setItem(key, JSON.stringify({ data: value, expire }))
  },
  get(key) {
    const content = window.localStorage.getItem(key)
    if (content) {
      const expire = JSON.parse(content).expire
      const balance = new Date().valueOf() - expire
      if (Number(24 * 60 * 60 * 100) < Number(balance)) {
        // 超过一天就清空
        storage.clear()
      } else {
        return JSON.parse(content).data
      }
    }
    return false
  },
  remove(key) {
    return window.localStorage.removeItem(key)
  },
  clear() {
    window.localStorage.clear()
  },
}
export function deepCopy(inObject) {
  let value, key

  if (typeof inObject !== 'object' || inObject === null) {
    return inObject // Return the value if inObject is not an object
  }

  // Create an array or object to hold the values
  const outObject = Array.isArray(inObject) ? [] : {}

  for (key in inObject) {
    value = inObject[key]

    // Recursively (deep) copy for nested objects, including arrays
    outObject[key] = deepCopy(value)
  }

  return outObject
}

export function debounce(func, wait, immediate) {
  var timeout
  return function () {
    var context = this
    var args = arguments
    clearTimeout(timeout)
    timeout = setTimeout(function () {
      timeout = null
      if (!immediate) func.apply(context, args)
    }, wait)
    if (immediate && !timeout) func.apply(context, args)
  }
}

const arr = []
export function recursion(obj, type) {
  if (!type) {
    for (var a in obj) {
      if (typeof obj[a] === 'object') {
        if (a === 'children' && obj.children.length === 1) obj.alwaysShow = true
        recursion(obj[a])
      } else {
        obj.meta = { title: obj.LMTITLE, icon: 'el-icon-toilet-paper' }
      }
    }
    return obj
  } else {
    for (var a in obj) {
      if (typeof obj[a] === 'object' && obj[a].children && obj[a].children.length > 0) {
        if (obj[a].LMLINK) arr.push(obj)
        recursion(obj[a].children, 'link')
      } else {
        if (obj[a].LMLINK) arr.push(obj[a])
      }
    }
    return arr
  }
}

const menu = []
export function fetchPermissionPath(obj) {
  for (var a in obj) {
    if (typeof obj[a] === 'object') {
      fetchPermissionPath(obj[a])
    } else {
      if (a === 'PATH') {
        menu.push(obj.PATH)
      }
    }
  }
  return menu
}

export function transformDate(time, format) {
  const origin = moment(time).format(format || 'YYYY-MM-DD')
  return origin
}

// JS对象深度合并   可能有问题 但暂未发现
export function deepMerge(target = {}, source = {}) {
  target = deepCopy(target)
  if (typeof target !== 'object' || typeof source !== 'object') return false
  for (var prop in source) {
    if (!source.hasOwnProperty(prop)) continue
    if (prop in target) {
      if (typeof target[prop] !== 'object') {
        target[prop] = source[prop]
      } else {
        if (typeof source[prop] !== 'object') {
          target[prop] = source[prop]
        } else {
          if (target[prop].concat && source[prop].concat) {
            target[prop] = target[prop].concat(source[prop])
          } else {
            target[prop] = deepMerge(target[prop], source[prop])
          }
        }
      }
    } else {
      target[prop] = source[prop]
    }
  }
  return target
}

/**
 * @param {date} time 需要转换的时间
 * @param {String} fmt 需要转换的格式 如 yyyy-MM-dd、yyyy-MM-dd HH:mm:ss
 */
export function formatTime(time, fmt) {
  if (!time) return ''
  else {
    const date = new Date(time)
    const o = {
      'M+': date.getMonth() + 1,
      'd+': date.getDate(),
      'H+': date.getHours(),
      'm+': date.getMinutes(),
      's+': date.getSeconds(),
      'q+': Math.floor((date.getMonth() + 3) / 3),
      S: date.getMilliseconds(),
    }
    if (/(y+)/.test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
    }
    for (const k in o) {
      if (new RegExp('(' + k + ')').test(fmt)) {
        fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length))
      }
    }
    return fmt
  }
}

/**
 * @param {string} path
 * @returns {Boolean}
 */
export function isExternal(path) {
  return /^(https?:|mailto:|tel:)/.test(path)
}

/**
 * 生成一个从 start 到 end 的连续数组
 * @param start
 * @param end
 */
export function generateArray(start, end) {
  return Array.from(new Array(end + 1).keys()).slice(start)
}

let title = ''
export function findTitle(data = storage.get('energyMenu'), target) {
  if (!data || data.length === 0) return false
  data.forEach((i) => {
    if (i.PATH === target) {
      title = i.LMTITLE
      return i.LMTITLE
    }
    if (i.CHILDREN && i.CHILDREN.length > 0) return findTitle(i.CHILDREN, target)
  })
  return title
}
