<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
import { storage } from '@/utils/utils'

export default {
  name: 'App',
  methods: {
    loadRoutesInfo() {
      // 在页面加载时读取sessionStorage里的状态信息
      try {
        sessionStorage.getItem('routesInfo') &&
          this.$store.commit('setRouterArray', JSON.parse(sessionStorage.getItem('routesInfo')))
        // sessionStorage.setItem("routesInfo", "")
      } catch (e) {
        console.log(e)
      }
      // 在页面刷新时将vuex里的信息保存到sessionStorage里
      window.addEventListener('beforeunload', () => {
        console.log(window.location.pathname)
        storage.set('pathName', window.location.pathname)
      })
    }
  }
}
</script>
