<template>
  <div class="navbar">
    <el-row class="navbar-row" type="flex" justify="space-between">
      <el-col :span="6" class="pl-20 text-left"><img style="width: 45%" src="~@/assets/img/logo.png" alt=""></el-col>
      <el-col :span="12" class="pt-10 text-center navbar-title">能源成本分析平台</el-col>
      <el-col :span="6" class="text-right navbar-time">
        <img src="~@/assets/img/qqctnlogo.png" class="mr-20" style="width: 56px; height: 35px" alt="">
        <div class="timeyear">{{ dateYear }}</div>
        {{ dateWeek }} {{ dateDay }}
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { formatTime } from '@/utils/utils'

export default {
  data() {
    return {
      dateDay: null,
      dateYear: null,
      dateWeek: null,
      weekday: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
    }
  },
  mounted() {
    this.timeFn()
  },
  methods: {
    timeFn() {
      setInterval(() => {
        this.dateDay = formatTime(new Date(), 'HH: mm: ss')
        this.dateYear = formatTime(new Date(), 'yyyy.MM.dd')
        this.dateWeek = this.weekday[new Date().getDay()]
      }, 1000)
    }
  }
}
</script>

<style lang="scss" scoped>
.text-left {
  padding-top: 0.8rem;
}
.timeyear {
  margin-right: 2.5rem;
}
.navbar {
  height: 58px;
  overflow: hidden;
  position: relative;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  .navbar-row {
    height: 100%;
    line-height: 58px;
    .navbar-title {
      font-size: 3.3rem;
      color: #75d1ff;
      font-weight: bold;
    }
    .navbar-time {
      text-align: right;
      display: flex;
      color: #66b8e3;
      align-items: center;
      font-size: 1.6rem;
      padding-right: 4.4rem;
      justify-content: flex-end;
    }
  }
}
</style>
