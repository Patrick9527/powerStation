<template>
  <el-row type="flex" justify="center" align="middle" class="mt-20">
    <el-pagination
      :page-size="pageSize"
      class="text-center"
      background
      layout="prev, pager, next"
      :total="Number(total)"
      @current-change="handleCurrentChange"
    />
    <!-- <span class="ml-10 export" @click="download">一键导出</span> -->
  </el-row>
</template>

<script>
export default {
  props: {
    total: {
      type: [String, Number],
      default: 0,
    },
    pageSize: {
      type: [String, Number],
      default: 10,
    },
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {
    download() {
      this.$emit('download')
    },
    handleCurrentChange(val) {
      console.log(val)
      this.$emit('refreshList', val)
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~@/styles/pagination.scss';
</style>
