<template>
  <section class="app-main" :style="{ '--width': width }">
    <hamburger :key="$route.name" :is-active="sidebar.opened" class="mt-10" @toggleClick="toggleSideBar" />
    <transition name="fade-transform" mode="out-in">
      <router-view :key="key" class="app-main-container" />
    </transition>
  </section>
</template>

<script>
import Hamburger from '@/components/Hamburger'
import { mapGetters } from 'vuex'

export default {
  name: 'AppMain',
  components: {
    Hamburger
  },
  data() {
    return {
      width: ''
    }
  },
  computed: {
    ...mapGetters(['sidebar']),
    key() {
      return this.$route.path
    }
  },
  watch: {
    sidebar: {
      handler: 'calculateWidth',
      deep: true
    }
  },
  created() {
    this.sidebar.opened ? (this.width = '210px') : (this.width = '54px')
  },
  methods: {
    calculateWidth(val) {
      val.opened ? (this.width = '210px') : (this.width = '54px')
    },
    toggleSideBar() {
      this.$store.dispatch('app/toggleSideBar')
    }
  }
}
</script>

<style scoped lang="scss">
.app-main {
  /*60 = navbar  */
  min-height: calc(100vh - 60px);
  width: 100%;
  position: relative;
  overflow: hidden;
}
.fixed-header + .app-main {
  padding-top: 50px;
}
</style>

<style lang="scss">
// fix css style bug in open el-dialog
.el-popup-parent--hidden {
  .fixed-header {
    padding-right: 15px;
  }
}
</style>
