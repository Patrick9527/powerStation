<template>
  <div v-if="!item.hidden">
    <template
      v-if="
        hasOneShowingChild(item.CHILDREN, item) &&
          (!onlyOneChild.children || onlyOneChild.noShowingChildren) &&
          !item.alwaysShow
      "
    >
      <app-link v-if="onlyOneChild.meta" :to="resolvePath(onlyOneChild.PATH)">
        <el-menu-item :index="resolvePath(onlyOneChild.PATH)" :class="{ 'submenu-title-noDropdown': !isNest }">
          <item :icon="onlyOneChild.meta.icon || (item.meta && item.meta.icon)" :title="onlyOneChild.meta.title" />
        </el-menu-item>
      </app-link>
    </template>

    <el-submenu v-else ref="subMenu" popper-append-to-body :index="resolvePath(item.PATH)">
      <template slot="title">
        <item v-if="item.meta" :icon="item.meta && item.meta.icon" :title="item.meta.title" />
      </template>
      <el-tooltip
        v-for="child in item.CHILDREN"
        :key="child.PATH"
        effect="dark"
        :content="child.meta.title"
        placement="right"
      >
        <sidebar-item
          :key="child.path"
          :is-nest="true"
          :item="child"
          :base-path="resolvePath(child.PATH)"
          class="nest-menu"
        />
      </el-tooltip>
    </el-submenu>
  </div>
</template>

<script>
import path from 'path'
import { isExternal } from '@/utils/utils'
import Item from './Item'
import AppLink from './Link'
import FixiOSBug from './FixiOSBug'

export default {
  name: 'SidebarItem',
  components: { Item, AppLink },
  mixins: [FixiOSBug],
  props: {
    // route object
    item: {
      type: Object,
      required: true
    },
    isNest: {
      type: Boolean,
      default: false
    },
    basePath: {
      type: String,
      default: ''
    }
  },
  data() {
    this.onlyOneChild = null
    return {}
  },
  methods: {
    hasOneShowingChild(children = [], parent) {
      const showingChildren = children.filter(item => {
        if (item.hidden) {
          return false
        } else {
          // Temp set(will be used if only has one showing child)
          this.onlyOneChild = item
          return true
        }
      })

      // When there is only one child router, the child router is displayed by default
      if (showingChildren.length === 1) {
        return true
      }

      // Show parent if there are no child router to display
      if (showingChildren.length === 0) {
        this.onlyOneChild = { ...parent, path: '', noShowingChildren: true }
        return true
      }

      return false
    },
    resolvePath(routePath) {
      if (isExternal(routePath)) {
        return routePath
      }
      if (isExternal(this.basePath)) {
        return this.basePath
      }
      return path.resolve(this.basePath, routePath)
    }
  }
}
</script>
<style lang="scss" scoped>
.el-menu-item {
  min-width: none;
  background-color: #06213c;
}
::v-deep .el-submenu__title,
.submenu-title-noDropdown {
  border: 1px solid #1c5393;
  i {
    color: #3399ff !important;
  }
}
.el-submenu {
  background-color: #06213c;
}
::v-deep .el-menu .is-active {
  color: #fff;
}
::v-deep .is-active .el-submenu__title {
  background-color: #3399ff !important;
  i {
    color: #fff !important;
  }
}
</style>
