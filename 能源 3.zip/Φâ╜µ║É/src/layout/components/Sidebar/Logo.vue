<template>
  <div class="sidebar-logo-container" :style="collapse ? 'margin-bottom:0' : ''" :class="{ collapse: collapse }">
    <transition name="sidebarLogoFade">
      <div v-if="collapse" key="collapse" class="sidebar-logo-link collapse cursor-pointer" @click="open">
        <el-avatar :size="34" src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png" />
      </div>
      <div v-else key="expand" class="sidebar-logo-link">
        <el-dropdown class="avatar-container" trigger="click">
          <div class="avatar-wrapper">
            <el-avatar :size="56">管理员</el-avatar>
            <div class="avatar-right ml-20">
              <div>
                <span>Admin</span>
                <i class="el-icon-arrow-down ml-10" />
              </div>
              <div>超级管理员</div>
            </div>
          </div>
          <el-dropdown-menu slot="dropdown" class="user-dropdown">
            <el-dropdown-item @click.native="logout">
              <span style="display:block;">退出登录</span>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </transition>
  </div>
</template>

<script>
export default {
  name: 'SidebarLogo',
  props: {
    collapse: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      showLogOut: false,
      title: 'Vue Admin Template',
      logo: 'https://wpimg.wallstcn.com/69a1c46c-eb1c-4b46-8bd4-e9e686ef5251.png'
    }
  },
  methods: {
    open() {
      this.$confirm('确定退出登录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.logout()
      })
    },
    async logout() {
      await this.$store.dispatch('user/logout')
      this.$router.push(`/login?redirect=${this.$route.fullPath}`)
    }
  }
}
</script>

<style lang="scss" scoped>
.sidebarLogoFade-enter-active {
  transition: opacity 1.5s;
}

.sidebarLogoFade-enter,
.sidebarLogoFade-leave-to {
  opacity: 0;
}

.sidebar-logo-container {
  position: relative;
  width: 100%;
  height: 60px;
  // line-height: 50px;
  // background: #2b2f3a;
  // text-align: center;
  overflow: hidden;
  margin-bottom: 30px;
  & .sidebar-logo-link {
    height: 100%;
    width: 100%;

    & .sidebar-title {
      display: inline-block;
      margin: 0;
      color: #fff;
      font-weight: 600;
      line-height: 50px;
      font-size: 14px;
      font-family: Avenir, Helvetica Neue, Arial, Helvetica, sans-serif;
      vertical-align: middle;
    }
  }
  .collapse {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .avatar-container {
    width: 100%;
    .avatar-wrapper {
      display: flex;
      width: 100%;
      span {
        color: #fff;
      }
    }
    .avatar-right {
      // width: calc(100% - 56px);
      > div {
        line-height: 30px;
      }
      div:nth-child(1) {
        font-size: 1.6rem;
      }
      div:nth-child(2) {
        font-size: 1.4rem;
        color: #818692;
      }
    }
  }
}
</style>
