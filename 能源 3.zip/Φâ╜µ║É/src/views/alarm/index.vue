<template>
  <div>
    <div class="box-container mt-10 pl-30 pr-30">
      <div class="box-title flex font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="" />
        <span>预警设置</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="" />
      </div>
      <div class="create-button">
        <el-button type="primary" @click="create">
          新增
        </el-button>
      </div>
      <div class="alarm-table">
        <el-table
          v-loading="load"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(0,0,0,0)"
          :data="list"
          :row-style="getRowClass"
          :header-cell-style="getHeaderClass"
        >
          <el-table-column
            v-for="(item, index) in column"
            :key="index"
            :label="item.label"
            :prop="item.prop"
            align="center"
          >
            <template slot-scope="scope">
              <slot v-if="item.slot" :name="scope.column.property" :row="scope.row" :$index="scope.$index">
                <div v-if="scope.column.label === '操作'">
                  <el-button type="primary" @click="edit(scope.row)">
                    编辑
                  </el-button>
                  <el-popconfirm title="确定删除吗？" class="ml-10" @confirm="remove(scope.row.SEQ)">
                    <el-button slot="reference" type="danger">删除</el-button>
                  </el-popconfirm>
                </div>
                <el-switch v-else v-model="scope.row.status" />
              </slot>
              <span v-else>{{ scope.row[scope.column.property] || '暂无' }}</span>
            </template>
          </el-table-column>
        </el-table>
        <pagination :total="total" @download="download" @refreshList="fetchAlarm" />
      </div>
    </div>
    <alarm-modal :visible="showModal" :select="select" @close="close" />
  </div>
</template>

<script>
import pagination from '@/layout/components/pagination.vue'
import AlarmModal from './alarmModal.vue'
import { fetchAlarm, editAlarm } from '@/api/alarm'

export default {
  name: 'Alarm',
  components: { pagination, AlarmModal },
  data() {
    return {
      list: [],
      load: false,
      total: 0,
      column: [
        { prop: 'TYPE', label: '设备分类' },
        { prop: 'MS', label: '预警名称' },
        { prop: 'MAX', label: '预警最大值' },
        { prop: 'SUGGEST', label: '预警建议值' },
        { prop: 'STATES', label: '当权状态', slot: true },
        { prop: 'TIME', label: '预警周期' },
        { prop: 'name', label: '操作', slot: true }
      ],
      select: {},
      showModal: false
    }
  },
  created() {
    this.fetchAlarm()
  },
  methods: {
    download() {
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = '/power/ajaxJsp/screen/ajaxEquipmentCompanyWarning.jsp?postType=download')
        : (url = process.env.VUE_APP_BASE_API + 'ajaxJsp/screen/ajaxEquipmentCompanyWarning.jsp?postType=download')
      window.location.href = url
    },
    remove(id) {
      if (id) {
        editAlarm({ postType: 'delete', SEQ: id }).then(res => {
          res.code === '200' ? this.done(res.message, 'success') : this.done(res.message, 'error')
        })
      }
    },
    done(val, type) {
      this.$message({
        message: val,
        type: type
      })
      if (type === 'success') this.fetchAlarm()
    },
    create() {
      this.select = {}
      this.showModal = true
    },
    fetchAlarm(val) {
      console.log(val)
      this.load = true
      fetchAlarm({ pageNumber: val || 1 }).then(res => {
        res.data.items.forEach(item => {
          switch (item.STATES) {
            case 'Y':
              item.status = true
              break
            case 'N':
              item.status = false
              break
            default:
              return res.data
          }
        })
        this.list = res.data.items
        this.total = res.data.totalCount
        this.load = false
      })
    },
    close(val) {
      this.select = {}
      if (val) this.fetchAlarm()
      this.showModal = false
    },
    edit(data) {
      this.showModal = true
      this.select = data
    },
    getHeaderClass() {
      return {
        background: '#071b39',
        color: '#fff'
      }
    },
    getRowClass({ row, column, rowIndex, columnIndex }) {
      if (rowIndex % 2 === 0) {
        return {
          background: '#03102d',
          color: '#fff'
        }
      } else {
        return {
          background: '#0c2e52',
          color: '#fff'
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.box-container {
  position: relative;
  height: 830px;
  padding-top: 5rem;
  color: #fff;
  background-image: url('~@/assets/img/report_bg.png');
  background-size: 100% 100%;
  // margin: 20px 30px;
  .create-button {
    position: absolute;
    right: 2%;
    top: 2rem;
  }
  ::v-deep .alarm-table {
    padding-top: 20px;
    .el-table--enable-row-hover .el-table__body tr:hover > td {
      background-color: transparent !important;
    }
    .el-table::before {
      height: 0px;
    }
    .el-button {
      border-radius: 0;
    }
    /* 表格内背景颜色 */
    .el-table th,
    .el-table tr,
    .el-table,
    .el-table td {
      border: 0;
      background-color: transparent;
    }
    .el-table__footer-wrapper {
      background-color: rgba(39, 129, 174, 0.8);
      td {
        color: #fff;
      }
    }
    .el-checkbox__inner {
      border: 2px solid #407997;
      background-color: rgba(21, 61, 57, 0.7);
      border-radius: 0;
    }
    .el-table {
      color: #fff;
    }
    .el-table__header-wrapper {
      border: 1px solid #30a0d8;
    }
    .el-table td,
    .el-table th.is-leaf {
      border-bottom: none;
    }
  }
  .box-title {
    position: absolute;
    top: 0;
    left: 0px;
    width: 16.7%;
    height: 4%;
    color: #fff;
    background-image: url('~@/assets/img/index_title.png');
    background-size: 100% 100%;
    font-size: 15px;
  }
}
</style>
