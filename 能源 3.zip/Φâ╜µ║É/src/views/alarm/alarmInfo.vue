<template>
  <div>
    <div class="box-container mt-10 pl-30 pr-30">
      <div class="box-title flex font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="" />
        <span>报警列表</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="" />
      </div>
      <el-row type="flex" justify="space-between">
        <div class="flex-between">
          <el-date-picker
            v-model="query.startTime"
            style="width:45%;"
            type="datetime"
            class="mr-20"
            :format="format"
            :value-format="valueFormat"
            :picker-options="timeChange"
            placeholder="选择日期时间"
          />
          <el-date-picker
            v-model="query.endTime"
            :format="format"
            :value-format="valueFormat"
            style="width:45%;"
            :picker-options="timeChange"
            type="datetime"
            placeholder="选择日期时间"
          />
        </div>
        <el-radio-group v-model="query.cycle" class="circle-range">
          <el-radio label="年">年</el-radio>
          <el-radio label="月">月</el-radio>
          <el-radio label="周">周</el-radio>
          <el-radio label="日">日</el-radio>
        </el-radio-group>
        <div class="select-row-search ml-30" @click="fetchAlarmInfo('reset')">查询</div>
      </el-row>
      <div class="alarm-table">
        <el-table
          v-loading="load"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(0,0,0,0)"
          :data="list"
          :row-style="getRowClass"
          :header-cell-style="getHeaderClass"
        >
          <el-table-column
            v-for="(item, index) in column"
            :key="index"
            :label="item.label"
            :prop="item.prop"
            align="center"
          >
            <template slot-scope="scope">
              <slot v-if="item.slot" :name="scope.column.property" :row="scope.row" :$index="scope.$index">
                <div v-if="scope.column.label === '操作'">
                  <el-popconfirm title="确定操作吗？" class="ml-10" @confirm="changeStatus(scope.row)">
                    <el-button slot="reference" type="danger">
                      {{ scope.row.DISABLE === 'N' ? '是否关闭' : '是否开启' }}
                    </el-button>
                  </el-popconfirm>
                </div>
                <div v-if="scope.column.label === '状态'">
                  {{ scope.row[scope.column.property] === 'N' ? '可用' : '不可用' }}
                </div>
              </slot>
              <span v-else>{{ scope.row[scope.column.property] || '暂无' }}</span>
            </template>
          </el-table-column>
        </el-table>
        <el-row type="flex" justify="center" align="middle" class="mt-20">
          <el-pagination
            :page-size="10"
            class="text-center"
            background
            layout="prev, pager, next"
            :total="Number(total)"
            @current-change="handleCurrentChange"
          />
        </el-row>
      </div>
    </div>
  </div>
</template>

<script>
import { fetchAlarmInfo, editAlarm } from '@/api/dashboard'
import moment from 'moment'

export default {
  name: 'Alarm',
  data() {
    return {
      list: [],
      timeChange: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      load: false,
      total: 0,
      format: 'yyyy 年 MM 月 dd 日 HH 时',
      valueFormat: 'yyyy-MM-dd HH',
      query: {
        pageNumber: 1,
        startTime: moment().format('YYYY-MM') + '-' + '01' + ' ' + '00',
        endTime: moment().format('YYYY-MM-DD') + ' ' + '23',
        cycle: '',
        type: 'ALARM',
        seq: undefined
      },
      column: [
        { prop: 'TYPE', label: '报警信息' },
        { prop: 'SHOWTIME', label: '报警时间' },
        { prop: 'NUM', label: '实际能耗占比' },
        { prop: 'KW', label: '能耗' },
        { prop: 'DISABLE', label: '状态', slot: true },
        { prop: 'name', label: '操作', slot: true }
      ],
      select: {}
    }
  },
  created() {
    console.log(this.$route.query.id)
    if (this.$route.query.id) this.query.seq = this.$route.query.id
    this.fetchAlarmInfo()
  },
  methods: {
    done(val, type) {
      this.$message({
        message: val,
        type: type
      })
      if (type === 'success') this.fetchAlarmInfo()
    },
    handleCurrentChange(val) {
      this.query.pageNumber = val
      this.fetchAlarmInfo()
    },
    create() {
      this.select = {}
      this.showModal = true
    },
    fetchAlarmInfo(type) {
      if (type) this.query.seq = undefined
      console.log(this.query)
      this.load = true
      fetchAlarmInfo(this.query).then(res => {
        this.list = res.data.items
        this.total = res.data.totalCount
        this.load = false
      })
    },
    changeStatus(data) {
      editAlarm({
        seq: data.SEQ,
        disable: data.DISABLE === 'N' ? 'Y' : 'N'
      }).then(res => {
        if (res.code === '200') this.success('success', res.message)
      })
    },
    success(type, data) {
      this.$message({
        message: data,
        type: type
      })
      this.fetchAlarmInfo()
    },
    getHeaderClass() {
      return {
        background: '#071b39',
        color: '#fff'
      }
    },
    getRowClass({ row, column, rowIndex, columnIndex }) {
      if (rowIndex % 2 === 0) {
        return {
          background: '#03102d',
          color: '#fff'
        }
      } else {
        return {
          background: '#0c2e52',
          color: '#fff'
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/pagination.scss';
.flex-between {
  width: 50%;
}
::v-deep .el-radio {
  color: #fff;
}
::v-deep .el-input__inner {
  background-color: #1b2742;
  border: 1px solid #7c818f;
  border-radius: 0;
  color: #a4a7b1;
}
.circle-range {
  display: flex;
  align-items: center;
}
.select-row-search {
  display: inline-block;
  width: 120px;
  text-align: center;
  line-height: 4rem;
  height: 4rem;
  font-size: 1.6rem;
  background-color: #3399ff;
  cursor: pointer;
}
.box-container {
  position: relative;
  height: 830px;
  padding-top: 5rem;
  color: #fff;
  background-image: url('~@/assets/img/report_bg.png');
  background-size: 100% 100%;
  // margin: 20px 30px;
  .create-button {
    position: absolute;
    right: 2%;
    top: 2rem;
  }
  ::v-deep .alarm-table {
    padding-top: 20px;
    .el-table--enable-row-hover .el-table__body tr:hover > td {
      background-color: transparent !important;
    }
    .el-table::before {
      height: 0px;
    }
    .el-button {
      border-radius: 0;
    }
    /* 表格内背景颜色 */
    .el-table th,
    .el-table tr,
    .el-table,
    .el-table td {
      border: 0;
      background-color: transparent;
    }
    .el-table__footer-wrapper {
      background-color: rgba(39, 129, 174, 0.8);
      td {
        color: #fff;
      }
    }
    .el-checkbox__inner {
      border: 2px solid #407997;
      background-color: rgba(21, 61, 57, 0.7);
      border-radius: 0;
    }
    .el-table {
      color: #fff;
    }
    .el-table__header-wrapper {
      border: 1px solid #30a0d8;
    }
    .el-table td,
    .el-table th.is-leaf {
      border-bottom: none;
    }
  }
  .box-title {
    position: absolute;
    top: 0;
    left: 0px;
    width: 16.7%;
    height: 4%;
    color: #fff;
    background-image: url('~@/assets/img/index_title.png');
    background-size: 100% 100%;
    font-size: 15px;
  }
}
</style>
