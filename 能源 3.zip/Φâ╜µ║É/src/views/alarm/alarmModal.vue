<template>
  <el-dialog :close-on-click-modal="false" width="30%" title="提示" :visible="visible" @close="cancel">
    <div slot="title" class="dialog-title">
      <span> {{ title }}分类( </span>
      <span> * </span>
      <span>表示必填或必选)</span>
    </div>
    <el-form ref="form" :model="form" label-width="auto">
      <el-form-item label="预警分类" prop="TYPE" :rules="[{ required: true, message: '预警分类不能为空' }]">
        <el-select v-model="form.TYPE" placeholder="请选择预警分类" style="width:100%;">
          <el-option v-for="(item, index) in option" :key="index" :label="item" :value="item" />
        </el-select>
      </el-form-item>
      <el-form-item label="预警周期" prop="CYCLE" :rules="[{ required: true, message: '预警周期不能为空' }]">
        <el-select v-model="form.CYCLE" placeholder="请选择预警周期" style="width:100%;">
          <el-option label="日" value="日" />
          <el-option label="周" value="周" />
          <el-option label="月" value="月" />
          <el-option label="年" value="年" />
        </el-select>
      </el-form-item>
      <el-form-item label="预警描述" prop="MSG" :rules="[{ required: true, message: '预警描述不能为空' }]">
        <el-input v-model="form.MSG" />
      </el-form-item>
      <el-form-item label="预警最大值">
        <el-input-number
          v-model="form.VAL"
          class="max-number"
          style="width:100%;"
          step-strictly
          :min="0"
          :controls="false"
        />
      </el-form-item>
      <el-form-item label="预警建议值">
        <el-input v-model="form.SUGGEST" disabled style="width:100%;" />
      </el-form-item>
      <el-form-item
        label="
          当前状态"
      >
        <el-switch v-model="form.status" />
      </el-form-item>
      <el-form-item>
        <el-button style="width:200px;" type="primary" @click="onSubmit">提交</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>
<script>
import { editAlarm, fetchSuggest } from '@/api/alarm'

export default {
  name: 'AlarmModal',
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    select: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {
      title: '新增',
      form: {
        CYCLE: '',
        SUGGEST: 0,
        TYPE: '',
        MSG: '',
        status: false,
        ENABLED: '',
        VAL: 0,
        postType: 'query'
      },
      option: ['岸桥', '机房', 'AGV', '食堂', '轨道吊', '冷箱', '其他辅助', '办公生活', '堆场照明']
    }
  },
  computed: {
    type() {
      return this.form.TYPE
    },
    cycle() {
      return this.form.CYCLE
    }
  },
  watch: {
    select(val) {
      val.SEQ ? (this.title = '编辑') : (this.title = '新增')
      if (val.ROWNO) {
        Object.assign(this.form, val)
        this.form.VAL = Number(val.MAX)
        this.form.MSG = val.MS
        this.form.CYCLE = val.TIME
      }
    },
    type: {
      handler: 'fetchSuggest'
    },
    cycle: {
      handler: 'fetchSuggest'
    }
  },
  created() {},
  methods: {
    fetchSuggest() {
      if (this.form.CYCLE && this.form.TYPE) {
        fetchSuggest({
          TYPE: this.form.TYPE,
          CYCLE: this.form.CYCLE
        }).then(res => {
          console.log(res)
          this.form.SUGGEST = res.data
        })
      }
    },
    cancel(val) {
      Object.assign(this.form, {
        CYCLE: '',
        TYPE: '',
        MSG: '',
        status: false,
        ENABLED: '',
        VAL: 0,
        SEQ: '',
        SUGGEST: 0,
        postType: 'query'
      })
      val ? this.$emit('close', val) : this.$emit('close')
    },
    onSubmit() {
      this.$refs['form'].validate(valid => {
        if (valid) {
          this.form.status ? (this.form.ENABLED = 'Y') : (this.form.ENABLED = 'N')
          this.select.SEQ ? (this.form.postType = 'update') : (this.form.postType = 'insert')
          editAlarm(this.form).then(res => {
            res.code === '200' ? this.done(res.message, 'success') : this.done(res.message, 'error')
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    done(val, type) {
      this.$message({
        message: val,
        type: type
      })
      type === 'success' ? this.cancel('refresh') : this.cancel()
    }
  }
}
</script>
<style lang="scss" scoped>
::v-deep .el-dialog {
  border: 1px solid #3399ff;
  color: #fff;
  background: none;
  .el-dialog__body {
    color: #fff;
    background-color: rgba(0, 1, 4, 0.5);
  }
  .max-number .el-input .el-input__inner {
    text-align: left;
  }
  .el-dialog__header {
    border-bottom: 1px solid #3399ff;
    background-color: rgba(26, 78, 130, 0.9);
  }
  .el-form-item__label {
    color: #efefef;
  }
  .el-input__inner {
    background-color: rgba(26, 28, 32, 0.7);
    border: 1px solid #7c818f;
    border-radius: 0;
    color: #a4a7b1;
  }
  .el-button {
    border-radius: 0;
  }
  .dialog-title {
    color: #fff;
    font-size: 1.6rem;
    > span:nth-child(2) {
      color: red;
    }
  }
}
</style>
