<template>
  <div class="monitor-table">
    <div>
      <el-table
        v-loading="load"
        size="mini"
        element-loading-text="拼命加载中"
        element-loading-background="rgba(0,0,0,0)"
        :data="monitorList"
        :row-style="getRowClass"
        :header-cell-style="getHeaderClass"
      >
        <el-table-column
          v-for="(item, index) in monitorColumn"
          :key="index"
          :label="item.label"
          :prop="item.prop"
          align="center"
        />
      </el-table>
    </div>
  </div>
</template>

<script>
import { fetchGridArkMonitor } from '@/api/dashboard'

export default {
  name: 'MonitorTable',
  data() {
    return {
      monitorList: [],
      load: false,
      monitorColumn: [
        { prop: 'DESCRIPTION', label: '设备分类' },
        { prop: 'ZENERGY', label: '总有功电能' },
        { prop: 'RENERGY', label: '总每日电能' },
        { prop: 'POWER', label: '总有功功率' }
      ]
    }
  },
  created() {
    this.fetchGridArkMonitor()
  },
  methods: {
    fetchGridArkMonitor(val) {
      this.load = true
      fetchGridArkMonitor().then(res => {
        this.monitorList = res.data
        this.load = false
      })
    },
    getHeaderClass() {
      return {
        background: '#071b39',
        color: '#fff'
      }
    },
    getRowClass({ row, column, rowIndex, columnIndex }) {
      if (rowIndex % 2 === 0) {
        return {
          background: '#03102d',
          color: '#fff'
        }
      } else {
        return {
          background: '#0c2e52',
          color: '#fff'
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.monitor-table {
  width: 90%;
  margin: 0 auto;
  ::v-deep > div {
    .el-table--enable-row-hover .el-table__body tr:hover > td {
      background-color: transparent !important;
    }
    .el-table::before {
      height: 0px;
    }
    .el-button {
      border-radius: 0;
    }
    /* 表格内背景颜色 */
    .el-table th,
    .el-table tr,
    .el-table,
    .el-table td {
      border: 0;
      background-color: transparent;
    }
    .el-table__footer-wrapper {
      background-color: rgba(39, 129, 174, 0.8);
      td {
        color: #fff;
      }
    }
    .el-checkbox__inner {
      border: 2px solid #407997;
      background-color: rgba(21, 61, 57, 0.7);
      border-radius: 0;
    }
    .el-table {
      color: #fff;
    }
    .el-table__header-wrapper {
      border: 1px solid #30a0d8;
    }
    .el-table td,
    .el-table th.is-leaf {
      border-bottom: none;
    }
  }
}
</style>
