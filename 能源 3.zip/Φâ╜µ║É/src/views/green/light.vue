<template>
  <div class="wrapper">
    <el-row type="flex" justify="space-between">
      <el-col :span="5" class="wind-left">
        <img src="@/assets/img/light-title.png" alt="">
        <div class="wind-left-wrap">
          <img src="@/assets/img/supply.png" alt="">
          <el-tree
            :current-node-key="device"
            style="width:80%"
            :data="treeData"
            :props="defaultProps"
            @node-click="handleNodeClick"
          />
        </div>
      </el-col>
      <el-col :span="18" class="wind-right">
        <div class="wind-top">
          <ul>
            <li v-for="i of powerInfo" :key="i.DESCRIPTION">
              <p>
                {{ i.VALUE }}
                <span class="ml-10" style="font-size:14px">
                  {{ i.DESCRIPTION.slice(-2) === '时间' ? '小时' : 'kW·h' }}
                </span>
              </p>
              <p>{{ i.DESCRIPTION }}</p>
            </li>
          </ul>
        </div>
        <div class="wind-bottom">
          <ul class="wind-info">
            <li v-for="(v, k, i) in powerDetail" :key="i">
              <span>{{ k }}</span>
              <span class="ml-10">{{ v }}</span>
            </li>
          </ul>
          <div class="wind-search">
            <span
              v-for="(x, i) of switchArr"
              :key="i"
              :class="lineType === x.value ? 'current' : ''"
              class="wind-search-switch "
              @click="switchType(x.value)"
            >
              {{ x.name }}
            </span>
            <el-date-picker
              v-model="value"
              class="mr-20"
              type="daterange"
              :format="format"
              :value-format="valueFormat"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            />
            <el-button type="primary" @click="search">查询</el-button>
          </div>
          <div id="wind-line" v-loading="load" />
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import { fetchLightMenu, fetchEquipmentGreenEnergy } from '@/api/dashboard'
import moment from 'moment'

export default {
  name: 'Dashboard',
  components: {},
  data() {
    return {
      switchArr: [
        { name: '电流', value: 'I' },
        { name: '电压', value: 'V' },
        { name: '有功功率', value: 'P' },
        { name: '发电量', value: 'elec' }
      ],
      value: [
        moment()
          .add(-7, 'd')
          .format('YYYY-MM-DD'),
        moment().format('YYYY-MM-DD')
      ],
      treeData: [],
      format: 'yyyy 年 MM 月 dd 日',
      valueFormat: 'yyyy-MM-dd',
      defaultProps: {
        children: 'value',
        label: 'description'
      },
      device: '',
      powerInfo: [],
      load: false,
      line: null,
      powerDetail: [],
      lineType: 'I'
    }
  },
  mounted() {},
  created() {
    this.init()
  },
  methods: {
    switchType(data) {
      this.lineType = data
    },
    search() {
      fetchLightMenu({
        postType: 'queryLineData',
        device: this.device,
        lineType: this.lineType,
        startDate: this.value[0],
        endDate: this.value[1]
      }).then(res => {
        this.transformData(res.data)
      })
    },
    drawLine(series, time) {
      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: '#6a7985'
            }
          },
          formatter: params => {
            let str = ''
            params.forEach((i, index) => {
              if (index !== 0 && (index + 1) % 3 === 0) {
                str = str + i.marker + i.seriesName + ' ' + i.value + '<br>'
              } else {
                str = str + i.marker + `<span style='margin-right:10px;'>${i.seriesName} ${i.value}</span>`
              }
            })
            return str
          }
        },
        legend: {
          type: 'scroll',
          textStyle: {
            color: '#fff',
            fontSize: 16
          }
        },
        grid: {
          top: '15%',
          left: '0%',
          right: '3%',
          bottom: '0%',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            axisLabel: {
              show: true,
              textStyle: {
                color: '#fff'
              }
            },
            data: time
          }
        ],
        yAxis: [
          {
            type: 'value',
            axisLabel: {
              show: true,
              textStyle: {
                color: '#17bae0'
              }
            }
          }
        ],
        series: series
      }
      this.line = echarts.init(document.getElementById('wind-line'))
      option && this.line.setOption(option)
      this.load = false
    },
    init() {
      this.fetchLightMenu()
    },
    fetchLightMenu() {
      fetchLightMenu({ postType: 'queryMenuTree' }).then(res => {
        this.treeData = res.data
        this.device = res.data[0].value[0].device
        this.fetchWindPower()
      })
    },
    fetchWindPower(data) {
      this.load = true
      fetchLightMenu({ postType: 'queryPower', device: data || this.device }).then(res => {
        this.powerInfo = res.data
      })
      fetchEquipmentGreenEnergy({ postType: 'queryLight', type: data || this.device }).then(res => {
        this.powerDetail = res.data
      })
      fetchLightMenu({
        postType: 'queryLineData',
        device: data || this.device,
        lineType: this.lineType,
        startDate: this.value[0],
        endDate: this.value[1]
      }).then(res => {
        this.transformData(res.data)
      })
    },
    transformData(data) {
      const series = []
      let time = []
      data.forEach(item => {
        time = item.value.map(ele => ele.time)
        series.push({
          name: item.description,
          type: 'line',
          data: item.value.map(ele => ele.value)
        })
      })
      console.log(series)
      if (this.line) this.line.clear()
      this.drawLine(series, time)
    },
    handleNodeClick(data) {
      if (data.device) {
        this.device = data.device
        this.fetchWindPower(data.device)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.wind-left {
  position: relative;
  // overflow-y: scroll;
  height: 900px;
  padding: 50px 15px 0;
  border: 1px solid #15add2;
  > img {
    position: absolute;
    top: -5px;
    left: -2px;
  }
  .wind-left-wrap {
    display: flex;
    align-items: center;
    justify-content: space-between;
    img {
      height: 100%;
    }
    ::v-deep .el-tree {
      background: none;
      color: #fff;
      > .el-tree-node > .el-tree-node__content:nth-child(1) {
        background-color: rgba(12, 46, 83, 0.6);
        border: 1px solid #30a0d8;
        color: #30a0d8;
        padding: 20px;
        margin: 15px 0;
      }
      .el-tree-node__content:hover,
      .el-tree-node:focus > .el-tree-node__content {
        background: none;
      }
      .el-tree-node__children .is-current .el-tree-node__content {
        background: #f5f7fa;
        color: #000;
      }
    }
  }
}
.wind-right {
  .wind-top,
  .wind-bottom {
    border: 1px solid #15add2;
  }
  .wind-top {
    padding: 25px;
    ul {
      display: flex;
      justify-content: space-between;
      li {
        border: 1px solid #30a0d8;
        text-align: center;
        width: 18%;
        color: #1ad5fd;
        p:nth-child(1) {
          background-color: #0b2b4d;
          font-size: 38px;
          padding: 20px;
          font-weight: bold;
        }
        p:nth-child(2) {
          background-color: #30a0d8;
          font-size: 18px;
          color: #fff;
          padding: 10px;
        }
      }
    }
  }
}
.wind-bottom {
  margin-top: 30px;
  padding: 30px 25px;
  color: #19ccf3;
  #wind-line {
    height: 280px;
    width: 100%;
    margin: 40px auto 0;
  }
  .wind-search {
    .wind-search-switch {
      padding: 10px 20px;
      color: #19ccf3;
      background-color: #042644;
      border: 1px solid #19ccf3;
      border-radius: 5px;
      margin-right: 20px;
      font-size: 16px;
      cursor: pointer;
    }
    .current {
      color: #fff;
      background-color: #1ad5fd;
    }
    .wind-search-switch:nth-child(4) {
      margin-right: 100px;
    }
  }
  .progress-row {
    display: flex;
    justify-content: space-between;
    > div {
      width: 45%;
      span {
        font-size: 18px;
        color: #19ccf3;
        margin-bottom: 18px;
        display: inline-block;
      }
    }
  }
  .wind-info {
    margin-top: 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    li {
      width: 30%;
      text-align: center;
      font-size: 16px;
      span:nth-child(2) {
        background-color: #0c2e53;
        border: 1px solid #19ccf3;
        padding: 10px 55px;
        margin-bottom: 30px;
        display: inline-block;
        border-radius: 5px;
        color: #fff;
        width: 65%;
        text-align: center;
      }
    }
  }
}
</style>
