<template>
  <div class="wrapper">
    <div class="dashboard-container">
      <el-row class="mb-15" style="margin-left: 0; margin-right: 0" type="flex" justify="space-between">
        <el-col :span="7" class="mr-15 dashboard-left">
          <div class="real-energy mb-15">
            <div class="flex vital-energy-title font-weight">
              <span>当日光伏实时数据总览</span>
            </div>
            <div>
              <ul class="data-overall">
                <li v-for="(v, k, i) in statisticData" :key="i">
                  <p>{{ v }}</p>
                  <p>{{ k }}</p>
                </li>
              </ul>
              <div id="aliveDataBar" v-on-echart-resize />
            </div>
          </div>
          <div class="vital-energy">
            <div class="flex vital-energy-title font-weight">
              <span>并网柜监控</span>
            </div>
            <monitor-table />
          </div>
        </el-col>
        <el-col :span="11" class="mr-15">
          <div id="middle" class="dashboard-middle">
            <div class="vital-energy-bigtitle font-weight">
              <span>总览数据显示</span>
            </div>
            <ul v-for="(v, k) of overallEnergyData" :key="k">
              <li>{{ v.name }}</li>
              <ul>
                <li v-for="(x, y, z) in v.value" :key="z">
                  <div>{{ x }}</div>
                  <div>{{ y }}</div>
                </li>
                <!-- <li class="seperator" /> -->
              </ul>
            </ul>
          </div>
        </el-col>
        <el-col :span="6" class="dashboard-right">
          <div class="save-energy mb-15" style="height: 40%">
            <div class="flex save-energy-title font-weight">
              <span>节能降本</span>
            </div>
            <div class="pl-15 pr-15">
              <div v-for="(x, y) of saveEnergyData" :key="y" class="save-item">
                <div class="pt-10">
                  <p style="font-size: 16px">{{ x.type }}</p>
                  <span class="save-flex-wrap">
                    <span style="font-size: 30px; color: #fff">{{ x.cost }}</span>
                    <span>
                      <span
                        class="mr-20"
                        :style="x.rate[0] === '-' ? 'color:#e8224e' : 'color:#22e8a0'"
                      >{{ x.rate[0] === '-' ? '↓' : '↑' }} {{ x.rate }}</span>
                      <span class="mr-20">同比上月</span>
                      <img src="@/assets/img/wealth.png" alt="">
                    </span>
                  </span>
                </div>
                <div v-show="y === 0" class="divided mt-15 mb-15" />
              </div>
            </div>
          </div>
          <div class="today-energy" style="height: 56%">
            <div class="flex today-energy-title font-weight">
              <span>当日电能产量分析</span>
            </div>
            <div class="today-energy-wrap">
              <div class="today-energy-wrap-title">
                <span :class="current === 'Invert' ? 'current' : ''" @click="changePie('Invert')">光伏</span>
                <span :class="current === 'Wind' ? 'current' : ''" @click="changePie('Wind')">风电</span>
              </div>
              <div id="pie" />
            </div>
          </div>
        </el-col>
      </el-row>
      <el-row class="index-bottom" type="flex" justify="space-between">
        <el-col :span="7">
          <div class="wind-energy">
            <div class="flex wind-energy-title font-weight">
              <span>当日风电实时数据总览</span>
            </div>
            <div style="width: 100%">
              <ul class="data-overall">
                <li v-for="(v, k, i) in greenEnergyData" :key="i">
                  <p>{{ v }}</p>
                  <p>{{ k }}</p>
                </li>
              </ul>
              <div id="greenEnergyDataBar" v-on-echart-resize />
            </div>
          </div>
        </el-col>
        <el-col :span="17" class="pl-10">
          <div class="pro-energy">
            <div class="flex pro-energy-title font-weight">
              <span>发电量实时数据</span>
            </div>
            <div
              id="barChart"
              v-on-echart-resize
              element-loading-text="拼命加载中"
              element-loading-spinner="el-icon-loading"
              element-loading-background="rgba(3, 10, 33, 0.8)"
            />
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import { fetchPvDataToday, fetchEquipmentGreenEnergy, fetchPowerRealTimeData } from '@/api/dashboard'
import { MonitorTable } from '@/views/green/components'

export default {
  name: 'Overall',
  components: {
    MonitorTable
  },
  data() {
    return {
      statisticData: {},
      greenEnergyData: {},
      barData: [],
      overallEnergyData: {},
      saveEnergyData: {},
      current: 'Invert',
      pie: undefined,
      bar: undefined
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.pie = echarts.init(document.getElementById('pie'))
      this.bar = echarts.init(document.getElementById('barChart'))
      this.fetchPvDataToday()
      this.fetchEquipmentGreenEnergy()
      this.fetchBar()
    },
    changePie(type) {
      this.current = type
      this.fetchPie()
    },
    drawPie(data) {
      const keyMap = {
        DESCRIPTION: 'name',
        VALUE: 'value'
      }
      for (var i = 0; i < data.length; i++) {
        var obj = data[i]
        for (var key in obj) {
          var newKey = keyMap[key]
          if (newKey) {
            obj[key] ? (obj[newKey] = obj[key]) : (obj[newKey] = 0)
            delete obj[key]
          }
        }
      }
      const option = {
        tooltip: {
          trigger: 'item'
        },
        legend: {
          bottom: '0%',
          left: 'center',
          textStyle: {
            color: '#fff'
          }
        },
        series: [
          {
            name: '',
            center: ['50%', '40%'],
            type: 'pie',
            radius: ['40%', '60%'],
            avoidLabelOverlap: false,
            itemStyle: {
              borderRadius: 10,
              // borderColor: '#fff',
              borderWidth: 2
            },
            label: {
              color: '#fff',
              position: 'outside'
            },
            labelLine: {
              show: true,
              lineStyle: {
                color: '#fff'
              }
            },
            data
          }
        ]
      }
      option && this.pie.setOption(option)
      this.pie.hideLoading()
    },
    fetchBar() {
      this.bar.showLoading({
        text: '',
        maskColor: 'rgba(4, 13, 38, 0)'
      })
      fetchPowerRealTimeData().then((res) => {
        this.drawBar(res.data)
      })
    },
    drawBar(data) {
      const option = {
        grid: {
          left: '0%',
          right: '0%',
          top: '10%',
          bottom: '0%',
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        xAxis: {
          show: true,
          type: 'category',
          splitLine: {
            show: false
          },
          data: data[0].value.map((i) => i.time) || [],
          axisLabel: {
            show: true,
            textStyle: {
              color: '#fff'
            }
          }
        },
        yAxis: {
          axisLine: {
            show: true
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: '#fff'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed'
            }
          }
        },
        series: [
          {
            name: '光伏',
            type: 'bar',
            color: '#0016bb',
            data: data.filter((i) => i.type === '光伏')[0].value.map((i) => i.total) || []
          },
          {
            name: '风电',
            type: 'bar',
            color: '#187fb2',
            data: data.filter((i) => i.type === '风电')[0].value.map((i) => i.total) || []
          }
        ]
      }
      option && this.bar.setOption(option)
      this.bar.hideLoading()
    },
    fetchPie() {
      this.pie.showLoading({
        text: '',
        maskColor: 'rgba(4, 13, 38, 0)'
      })
      fetchEquipmentGreenEnergy({ postType: 'queryYield', type: this.current }).then((res) => {
        this.drawPie(res.data)
      })
    },
    fetchEquipmentGreenEnergy() {
      fetchEquipmentGreenEnergy({ postType: 'statisticData' }).then((res) => {
        this.greenEnergyData = res.data
      })
      this.fetchPie()
      fetchEquipmentGreenEnergy({ postType: 'queryOverviewWind' }).then((res) => {
        const arr = []
        for (const i of Object.keys(res.data)) {
          let obj = {}
          if (i === '光伏') {
            obj = {
              name: i,
              value: {
                '总发电量/kW·h': res.data[i]['总发电量/kwh'],
                '总并网运行时间/h': res.data[i]['总并网运行时间/h'],
                '二氧化碳减排量/吨': res.data[i]['二氧化碳减排量/吨'],
                '等效植树/棵': res.data[i]['等效植树/棵']
              }
            }
          } else {
            obj = {
              name: i,
              value: {
                '总电量/kW·h': res.data[i]['总电量/kwh'],
                '年发电量/kW·h': res.data[i]['年发电量/kwh'],
                '二氧化碳减排量/吨': res.data[i]['二氧化碳减排量/吨'],
                '等效植树/棵': res.data[i]['等效植树/棵']
              }
            }
          }
          arr.push(obj)
        }
        arr.sort((x, y) => {
          if (x.name === '光伏') {
            return -1
          } else {
            return 1
          }
        })
        this.overallEnergyData = arr
      })
      fetchEquipmentGreenEnergy({ postType: 'queryCost' }).then((res) => {
        this.saveEnergyData = res.data
      })
      fetchEquipmentGreenEnergy({ postType: 'typeData' }).then((res) => {
        const name = res.data.map((item) => item.DESCRIPTION)
        const value = res.data.map((item) => item.NUM)
        const max = res.data
          .map((item) => item.NUM)
          .sort(function(a, b) {
            return b - a
          })[0]
        const arr1 = this.generateArrary(value.length, Number(max))
        this.drawGreenEnergyDataBar(value, name, arr1)
      })
    },
    fetchPvDataToday() {
      fetchPvDataToday({ postType: 'statisticData' }).then((res) => {
        this.statisticData = res.data
      })
      fetchPvDataToday({ postType: 'typeData' }).then((res) => {
        const name = res.data.map((item) => item.DESCRIPTION)
        const value = res.data.map((item) => item.NUM)
        const max = res.data
          .map((item) => item.NUM)
          .sort(function(a, b) {
            return b - a
          })[0]
        const arr1 = this.generateArrary(value.length, Number(max))
        this.drawPvDataBar(value, name, arr1)
      })
    },
    generateArrary(length, max) {
      return Array.from({ length: length }, (item, index) => (item = max))
    },
    drawPvDataBar(value, name, arr1) {
      const option = {
        grid: {
          top: '10%',
          left: '0%',
          right: '0%',
          bottom: '0%',
          containLabel: true
        },
        // x轴
        xAxis: {
          type: 'value',
          splitLine: {
            show: false
          },
          min: 0,
          max: arr1[0],
          axisLabel: {
            show: true,
            // formatter: val => {
            //   const txt = Math.floor((Number(val) / 1000) * 100) / 100
            //   return (Number(val)
            // },
            textStyle: {
              color: '#75d1ff'
            }
          }
        },
        // y轴
        yAxis: [
          {
            // 坐标轴
            type: 'category',
            // 显示的左侧提示
            data: name.reverse() || [],
            // y轴的线
            axisLine: {
              // 设置为不显示
              show: false
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: '#ffffff'
              }
            },
            // y轴线上的标记刻度
            axisTick: {
              show: false
            }
          },
          {
            // 坐标轴
            type: 'category',
            show: true,
            axisTick: {
              show: false
            },
            axisLine: {
              // 设置为不显示
              show: false
            },
            axisLabel: {
              formatter: (val) => {
                const txt = Math.floor(Number(value[val]))
                return txt
              },
              // 右侧显示的数据样式
              textStyle: {
                // 字体大小
                fontSize: 13,
                // 字体颜色
                color: '#6dc4f1'
              }
            }
          }
        ],
        // 具体数据及样式
        series: [
          {
            // 这是显示条
            name: '条',
            // 设置为条状图
            type: 'bar',
            // 具体每一个的数据
            data: value.reverse() || [],
            // 单个的样式
            itemStyle: {
              // 设置颜色
              color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                { offset: 0, color: '#1d8ce6' },
                { offset: 0.5, color: '#1ac5f2' },
                { offset: 1, color: '#18fdfe' }
              ])
            },
            //
            barCategoryGap: '5%',
            // 柱状图的宽度
            barWidth: 10,
            // 样式
            label: {
              show: false,
              color: '#fff',
              position: 'right'
            },
            // 这是第一个
            yAxisIndex: 0
          },
          {
            // 设置柱状图的外框
            name: '框',
            // 设置为柱状
            type: 'bar',
            barCategoryGap: '5%',
            // 柱状图的宽度
            barWidth: 15,
            // 每一个的样式
            itemStyle: {
              // 颜色
              color: 'none',
              // 边框色
              borderColor: '#00C1DE',
              // border宽度
              borderWidth: 2
            },
            // 柱状图的长度
            data: arr1,
            // 第二个堆在第一个上
            yAxisIndex: 1
          }
        ]
      }
      const aliveDataBar = echarts.init(document.getElementById('aliveDataBar'))
      option && aliveDataBar.setOption(option)
    },
    drawGreenEnergyDataBar(value, name, arr1) {
      const option = {
        grid: {
          top: '0%',
          left: '0%',
          right: '0%',
          bottom: '0%',
          containLabel: true
        },
        // x轴
        xAxis: {
          type: 'value',
          splitLine: {
            show: false
          },
          min: 0,
          max: arr1[0],
          axisLabel: {
            show: true,
            // formatter: val => {
            //   const txt = Math.floor((Number(val) / 1000) * 100) / 100
            //   return (Number(val)
            // },
            textStyle: {
              color: '#75d1ff'
            }
          }
        },
        // y轴
        yAxis: [
          {
            // 坐标轴
            type: 'category',
            // 显示的左侧提示
            data: name.reverse() || [],
            // y轴的线
            axisLine: {
              // 设置为不显示
              show: false
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: '#ffffff'
              }
            },
            // y轴线上的标记刻度
            axisTick: {
              show: false
            }
          },
          {
            // 坐标轴
            type: 'category',
            show: true,
            axisTick: {
              show: false
            },
            axisLine: {
              // 设置为不显示
              show: false
            },
            axisLabel: {
              formatter: (val) => {
                const txt = Math.floor(Number(value[val]))
                return txt
              },
              // 右侧显示的数据样式
              textStyle: {
                // 字体大小
                fontSize: 13,
                // 字体颜色
                color: '#6dc4f1'
              }
            }
          }
        ],
        // 具体数据及样式
        series: [
          {
            // 这是显示条
            name: '条',
            // 设置为条状图
            type: 'bar',
            // 具体每一个的数据
            data: value.reverse() || [],
            // 单个的样式
            itemStyle: {
              // 设置颜色
              color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                { offset: 0, color: '#1d8ce6' },
                { offset: 0.5, color: '#1ac5f2' },
                { offset: 1, color: '#18fdfe' }
              ])
            },
            //
            barCategoryGap: '5%',
            // 柱状图的宽度
            barWidth: 10,
            // 样式
            label: {
              show: false,
              color: '#fff',
              position: 'right'
            },
            // 这是第一个
            yAxisIndex: 0
          },
          {
            // 设置柱状图的外框
            name: '框',
            // 设置为柱状
            type: 'bar',
            barCategoryGap: '5%',
            // 柱状图的宽度
            barWidth: 15,
            // 每一个的样式
            itemStyle: {
              // 颜色
              color: 'none',
              // 边框色
              borderColor: '#00C1DE',
              // border宽度
              borderWidth: 2
            },
            // 柱状图的长度
            data: arr1,
            // 第二个堆在第一个上
            yAxisIndex: 1
          }
        ]
      }
      const greenEnergyDataBar = echarts.init(document.getElementById('greenEnergyDataBar'))
      option && greenEnergyDataBar.setOption(option)
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep .el-radio__label {
  color: #fff;
}
#pie {
  height: 90%;
  width: 95%;
  margin: 0 auto;
}
#barChart {
  height: 85%;
  width: 95%;
  margin: 0 auto;
}
.save-item {
  color: #1ad5fd;
  .save-flex-wrap {
    display: flex;
    align-items: flex-end;
    font-size: 18px;
    justify-content: space-between;
  }
}
.today-energy-wrap-title {
  text-align: right;
  color: #1ad5fd;
  font-size: 16px;
  span {
    cursor: pointer;
    margin-right: 30px;
  }
  .current {
    border: 1px solid #30a0d8;
    color: #fff;
    background-color: rgba(30, 64, 96, 0.6);
    padding: 5px 20px;
    border-radius: 5px;
  }
}
.divided {
  width: 100%;
  height: 2px;
  background-color: #1ad5fd;
}
#aliveDataBar,
#greenEnergyDataBar {
  width: 90%;
  margin: 0 auto;
  height: 75%;
}
.data-overall {
  color: #1ad5fd;
  display: flex;
  width: 100%;
  height: 25%;
  justify-content: space-between;
  li {
    text-align: center;
    width: 25%;
    p:nth-child(1) {
      margin-bottom: 10px;
      font-size: 30px;
    }
    p:nth-child(2) {
      font-size: 12px;
    }
  }
}
.dashboard-middle {
  padding-top: 5rem;
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  height: 40%;
  background-image: url('~@/assets/img/index-overall.png');
  background-size: 100% 100%;
  > ul {
    display: flex;
    border: 1px solid #30a0d8;
    margin: 0 auto;
    width: 95%;
    color: #fff;
    background-color: rgba(11, 62, 98, 0.5);
    > li {
      width: 5%;
      background-color: #30a0d8;
      padding: 25px 10px;
      writing-mode: vertical-lr;
      // letter-spacing: 5px;
      text-align: center;
    }
    ul {
      display: flex;
      justify-content: space-around;
      width: 95%;
      align-items: center;
      .seperator {
        width: 1px;
        background-color: #30a0d8;
        height: 60%;
      }
      li {
        text-align: center;
        // border-right: 1px solid #30a0d8;
        div:nth-child(1) {
          font-size: 30px;
          margin-bottom: 5px;
          font-weight: bold;
          color: #1ad5fd;
        }
        div:nth-child(2) {
          font-size: 14px;
        }
      }
    }
  }
}
.real-energy,
.save-energy,
.today-energy {
  position: relative;
  display: flex;
  padding-top: 5rem;
  background-image: url('~@/assets/img/green_energy.png');
  background-size: 100% 100%;
  > div:nth-child(2) {
    width: 100%;
  }
}
.save-energy {
  background-image: url('~@/assets/img/save.png');
  .save-energy-title {
    width: 77% !important;
    height: 15% !important;
  }
}
.today-energy {
  background-image: url('~@/assets/img/today.png');
  .today-energy-title {
    width: 77% !important;
    height: 9% !important;
  }
}
.dashboard-container {
  height: 955px;
  background-image: url('~@/assets/img/overall.png');
  background-size: contain;
  .vital-energy {
    position: relative;
    display: flex;
    padding-top: 5rem;
    width: 100%;
    background-image: url('~@/assets/img/green_energy.png');
    background-size: 100% 100%;
  }
  .pro-energy {
    position: relative;
    display: flex;
    padding-top: 5rem;
    height: 100%;
    align-items: center;
    width: 100%;
    background-image: url('~@/assets/img/elec.png');
    background-size: 100% 100%;
    > div:nth-child(2) {
      width: 100%;
    }
    .pro-energy-title {
      height: 16%;
      width: 23%;
    }
  }
  .wind-energy {
    position: relative;
    display: flex;
    padding-top: 6rem;
    width: 100%;
    height: 100%;
    background-image: url('~@/assets/img/wind.png');
    background-size: 100% 100%;
    .wind-energy-title {
      height: 16%;
      width: 61%;
    }
  }
  .vital-energy-title,
  .pro-energy-title,
  .today-energy-title,
  .save-energy-title,
  .wind-energy-title {
    position: absolute;
    top: 0;
    width: 60%;
    height: 10%;
    color: #fff;
    background-image: url('~@/assets/img/green_title.png');
    background-size: 100% 100%;
    font-size: 15px;
  }
  .vital-energy-bigtitle {
    position: absolute;
    top: 0;
    width: 34%;
    height: 15%;
    color: #fff;
    background-image: url('~@/assets/img/green_title.png');
    background-size: 100% 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
  }
  .dashboard-right {
    overflow: hidden;
  }
  .dashboard-left > div,
  .dashboard-right > div {
    height: 48%;
  }
  .el-row {
    overflow: hidden;
  }
  .index-bottom {
    display: flex;
    padding-top: 2rem;
  }
  .el-row:nth-child(1) {
    width: 100%;
    height: 66%;
  }
  .el-row:nth-child(2) {
    width: 100%;
    height: 33%;
  }
}
</style>
