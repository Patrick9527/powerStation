<template>
  <div>
    <div class="mt-10 box-container pl-30 pr-30">
      <div class="flex box-title font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="" />
        <span>月度能耗成本表</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="" />
      </div>
      <div class="text-center electron-title">
        {{ query.year || new Date().getFullYear() }}年 {{ query.month || new Date().getMonth() + 1 }}月 月度能耗成本表
      </div>
      <el-row class="text-center pl-30 pr-30 mt-30">
        <el-date-picker
          v-model="query.year"
          :picker-options="startPickerOptions"
          type="year"
          placeholder="选择年"
          format="yyyy 年"
          value-format="yyyy"
          class="mr-40"
        />
        <el-date-picker
          v-model="query.month"
          format="MM 月 "
          value-format="MM"
          type="month"
          class="mr-35"
          placeholder="选择月份"
        />
        <span class="select-row-search" @click="fetchMonthlyCost()">查询</span>
        <span class="ml-20 select-row-search" @click="showImportModal = true">导入</span>
      </el-row>
      <div class="mt-30">
        <el-table
          v-loading="load"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(0,0,0,0)"
          :data="tableData"
          :cell-style="{ borderColor: '#30a0d8' }"
          :header-cell-style="{ borderColor: '#30a0d8' }"
        >
          <el-table-column align="center" prop="type" label="能源种类" />
          <el-table-column align="center" label="生产能源消耗量（万kWh)">
            <el-table-column align="center" prop="MEC_PRODUCE" label="本期" />
            <el-table-column align="center" prop="MEC_PRODUCE_LAST" label="同期" />
          </el-table-column>
          <el-table-column align="center" label="生产成本（万元）">
            <el-table-column align="center" prop="MEC_COST" label="本期" />
            <el-table-column align="center" prop="MEC_COST_LAST" label="同期" />
          </el-table-column>
          <el-table-column align="center" label="辅助能源消耗量">
            <el-table-column align="center" prop="MEC_ASSIST" label="本期" />
            <el-table-column align="center" prop="MEC_ASSIST_LAST" label="同期" />
          </el-table-column>
          <el-table-column align="center" label="辅助成本（万元）">
            <el-table-column align="center" prop="MEC_ASSIST_COST" label="本期" />
            <el-table-column align="center" prop="MEC_ASSIST_COST_LAST" label="同期" />
          </el-table-column>
          <el-table-column align="center" label="总能源消耗量">
            <el-table-column align="center" prop="MEC_TOTAL_ENERGY" label="本期" />
            <el-table-column align="center" prop="MEC_TOTAL_ENERGY_LAST" label="同期" />
          </el-table-column>
          <el-table-column align="center" label="总成本（万元）">
            <el-table-column align="center" prop="MEC_TOTAL_COST" label="本期" />
            <el-table-column align="center" prop="MEC_TOTAL_COST_LAST" label="同期" />
          </el-table-column>
        </el-table>
      </div>
    </div>
    <import-modal :visible="showImportModal" @close="refresh" />
  </div>
</template>

<script>
import { fetchMonthlyCost } from '@/api/cost'
import { deepCopy } from '@/utils/utils'
import importModal from '@/views/energy/components/importModal.vue'
import moment from 'moment'

export default {
  name: 'Electron',
  components: { importModal },
  data() {
    return {
      showImportModal: false,
      uploadUrl:
        process.env.NODE_ENV === 'development' ? '/power' : process.env.VUE_APP_BASE_API + '/sc.saveBase64.dox',
      startPickerOptions: {
        disabledDate(time) {
          return Number(time.getFullYear()) < 2017 || Number(time.getFullYear()) > Number(new Date().getFullYear())
        },
      },
      load: false,
      query: {
        month: '',
        endMonth: undefined,
        startMonth: undefined,
        year: undefined,
        startTime: undefined,
        endTime: undefined,
      },
      tableData: [],
    }
  },
  created() {
    this.fetchMonthlyCost()
  },
  methods: {
    refresh(type) {
      this.showImportModal = false
      if (type) this.fetchMonthlyCost()
    },
    download() {
      const query = deepCopy(this.query)
      if (!query.year) query.year = new Date().getFullYear()
      if (!query.startMonth) query.startMonth = '01'
      if (!query.endMonth) query.endMonth = new Date().getMonth() + 1
      query.startTime = query.year + '-' + query.startMonth
      query.endTime = query.year + '-' + query.endMonth
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = `/power/ajaxJsp/screen/ajaxEquipmentEnergyMonth.jsp?postType=download&endMonth=${query.endMonth}&endTime=${query.endTime}&startTime=${query.startTime}&startMonth=${query.startMonth}&year=${query.year}`)
        : (url =
            process.env.VUE_APP_BASE_API +
            `ajaxJsp/screen/ajaxEquipmentEnergyMonth.jsp?postType=download&endMonth=${query.endMonth}&endTime=${query.endTime}&startTime=${query.startTime}&startMonth=${query.startMonth}&year=${query.year}`)
      window.location.href = url
    },
    fetchMonthlyCost() {
      this.load = true
      const query = deepCopy(this.query)
      if (!query.year) query.year = new Date().getFullYear()
      if (!query.startMonth) query.startMonth = '01'
      if (!query.endMonth) query.endMonth = new Date().getMonth() + 1
      query.startTime = query.year + '-' + query.startMonth
      query.endTime = query.year + '-' + query.endMonth
      if (!query.month) {
        if (Number(moment().month()) < 10) {
          query.month = '0' + Number(moment().month() + 1)
        }
      }
      fetchMonthlyCost(query).then((res) => {
        this.tableData = res.data
        this.tableData.forEach((item) => {
          item.type = '电力(万KWH)'
        })
        this.load = false
      })
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~@/styles/cost/index.scss';
</style>
