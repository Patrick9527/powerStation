<template>
  <div>
    <div class="box-container mt-10 pl-30 pr-30">
      <div class="box-title flex font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="" />
        <span>月单耗指标</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="" />
      </div>
      <div class="text-center electron-title">
        {{ query.year || new Date().getFullYear() }}年 {{ query.month || new Date().getMonth() + 1 }}月 单耗指标分析表
      </div>
      <el-row class="pl-30 text-center pr-30 mt-30">
        <el-date-picker
          v-model="query.year"
          :picker-options="startPickerOptions"
          type="year"
          placeholder="选择年"
          format="yyyy 年"
          value-format="yyyy"
          class="mr-40"
        />
        <el-date-picker
          v-model="query.month"
          format="MM 月 "
          value-format="MM"
          type="month"
          class="mr-35"
          placeholder="选择月份"
        />
        <!-- <span class="select-row-search mr-20" @click="download">导出表格</span> -->
        <span class="select-row-search" @click="fetchMonthlyList()">查询</span>
      </el-row>
      <div class="mt-30">
        <el-table
          v-loading="load"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(0,0,0,0)"
          border
          :data="listData"
          :cell-style="{ borderColor: '#30a0d8' }"
          :header-cell-style="{ borderColor: '#30a0d8' }"
        >
          <el-table-column
            v-for="(item, index) in column"
            :key="index"
            :label="item.label"
            :prop="item.prop"
            align="center"
          />
        </el-table>
      </div>
    </div>
  </div>
</template>

<script>
import { fetchMonthlyList } from '@/api/cost'

export default {
  name: 'Electron',
  data() {
    return {
      load: false,
      time: '',
      query: {
        time: undefined,
        year: undefined,
        month: undefined,
      },
      startPickerOptions: {
        disabledDate(time) {
          return Number(time.getFullYear()) < 2017 || Number(time.getFullYear()) > Number(new Date().getFullYear())
        },
      },
      listData: [],
      column: [
        { prop: 'name', label: '指标分类' },
        { prop: 'unit', label: '单位' },
        { prop: 'current', label: '本期' },
        { prop: 'same', label: '同期' },
        { prop: 'increase', label: '单耗增减量' },
        { prop: 'decrease', label: '增减比' },
      ],
    }
  },
  created() {
    this.fetchMonthlyList()
  },
  methods: {
    download() {
      if (this.query.year && this.query.month) this.query.time = this.query.year + '-' + this.query.month
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? this.query.time
          ? (url = `/power/ajaxJsp/screen/ajaxEquipmentEnergyTypeMonth.jsp?postType=download&time=${this.query.time}`)
          : (url = `/power/ajaxJsp/screen/ajaxEquipmentEnergyTypeMonth.jsp?postType=download`)
        : this.query.time
        ? (url =
            process.env.VUE_APP_BASE_API +
            `ajaxJsp/screen/ajaxEquipmentEnergyTypeMonth.jsp?postType=download&time=${this.query.time}`)
        : (url = process.env.VUE_APP_BASE_API + `ajaxJsp/screen/ajaxEquipmentEnergyTypeMonth.jsp?postType=download`)
      window.location.href = url
    },
    fetchMonthlyList(time) {
      this.load = true
      if (this.query.year && this.query.month) this.query.time = this.query.year + '-' + this.query.month
      fetchMonthlyList({ time: this.query.time }).then((res) => {
        this.listData = res.data
        this.load = false
      })
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~@/styles/cost/index.scss';
</style>
