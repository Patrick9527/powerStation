<template>
  <div>
    <div class="box-container mt-10 pl-30 pr-30">
      <div class="box-title flex font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="" />
        <span>冷箱用电量和堆存量报表</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="" />
      </div>
      <div class="text-center electron-title">
        {{ query.year || new Date().getFullYear() }}年 {{ query.month || new Date().getMonth() + 1 }}月
        冷箱用电量和堆存量报表
      </div>
      <el-row class="pl-30 text-center pr-30 mt-30">
        <el-date-picker
          v-model="query.year"
          :picker-options="startPickerOptions"
          type="year"
          placeholder="选择年"
          format="yyyy 年"
          value-format="yyyy"
          class="mr-40"
        />
        <el-date-picker
          v-model="query.month"
          format="MM 月 "
          value-format="MM"
          class="mr-35"
          type="month"
          placeholder="选择日期"
        />
        <span class="select-row-search" @click="fetchStock()">查询</span>
      </el-row>
      <div class="mt-30">
        <el-table
          v-loading="load"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(0,0,0,0)"
          border
          :data="listData"
          :cell-style="{ borderColor: '#30a0d8' }"
          :header-cell-style="{ borderColor: '#30a0d8' }"
        >
          <el-table-column
            v-for="(item, index) in column"
            :key="index"
            :label="item.label"
            :prop="item.prop"
            align="center"
          />
        </el-table>
      </div>
    </div>
  </div>
</template>

<script>
import { fetchStock } from '@/api/cost'

export default {
  name: 'Stock',
  data() {
    return {
      load: false,
      listData: [],
      startPickerOptions: {
        disabledDate(time) {
          return Number(time.getFullYear()) < 2017 || Number(time.getFullYear()) > Number(new Date().getFullYear())
        }
      },
      query: {
        year: undefined,
        month: undefined
      },
      column: [
        { prop: 'TIMERANGE', label: '日期' },
        { prop: 'KW', label: '用电量KWH' },
        { prop: 'TEU', label: '堆存量TEU' },
        { prop: 'KW/TEU', label: '5天单耗 KW / TEU' }
      ]
    }
  },
  created() {
    this.fetchStock()
  },
  methods: {
    fetchStock() {
      this.load = true
      fetchStock(this.query).then(res => {
        this.listData = res.data
        this.load = false
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/cost/index.scss';
</style>
