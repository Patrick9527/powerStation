<template>
  <div>
    <div class="mt-10 box-container pl-30 pr-30">
      <div class="flex box-title font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="">
        <span>月度用电汇总表</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="">
      </div>
      <div class="text-center electron-title">
        {{ query.year || new Date().getFullYear() }}年QQCTN月度用电汇总表 (kW·h)
      </div>
      <el-row class="text-center pl-30 pr-30 mt-30">
        <el-date-picker
          v-model="query.year"
          :picker-options="startPickerOptions"
          type="year"
          placeholder="选择年"
          format="yyyy 年"
          value-format="yyyy"
          class="mr-40"
        />
        <el-date-picker
          v-model="query.month"
          format="MM 月 "
          value-format="MM"
          class="mr-35"
          type="month"
          placeholder="选择日期"
        />
        <span class="select-row-search" @click="fetchEnergyList()">查询</span>
      </el-row>
      <div class="mt-30">
        <el-table
          v-loading="load"
          height="550"
          :data="tableData"
          :cell-style="{ borderColor: '#30a0d8' }"
          :header-cell-style="{ borderColor: '#30a0d8' }"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(0,0,0,0)"
        >
          <el-table-column align="center" prop="TIME" label="月份" />
          <el-table-column align="center" prop="DT" label="时间段" />
          <el-table-column align="center" label="生产">
            <el-table-column align="center" prop="QC" label="桥吊" />
            <el-table-column align="center" prop="A" label="ASC" />
            <el-table-column align="center" prop="AGV" label="AGV" />
            <el-table-column align="center" prop="DC" label="堆场照明" />
            <el-table-column align="center" prop="produceTotal" label="生产合计" />
          </el-table-column>
          <el-table-column align="center" label="辅助生活">
            <el-table-column align="center" prop="LX" label="冷箱" />
            <el-table-column align="center" prop="JF" label="机房" />
            <el-table-column align="center" prop="assistedTotal" label="辅助生产合计" />
          </el-table-column>
          <el-table-column align="center" label="办公生活用电">
            <el-table-column align="center" prop="BG" label="辅助生活" />
            <el-table-column align="center" prop="ST" label="其他用电" />
          </el-table-column>
          <el-table-column align="center" prop="FZ" label="生活加辅助" />
          <el-table-column align="center" prop="total" label="总用电量" />
        </el-table>
        <pagination :page-size="5" :total="total" @refreshList="fetchEnergyList" @download="download" />
      </div>
    </div>
  </div>
</template>

<script>
import Pagination from '@/layout/components/pagination.vue'
import { fetchEnergyList } from '@/api/cost'

export default {
  name: 'Electron',
  components: { Pagination },
  data() {
    return {
      total: 0,
      startPickerOptions: {
        disabledDate(time) {
          return Number(time.getFullYear()) < 2017 || Number(time.getFullYear()) > Number(new Date().getFullYear())
        }
      },
      load: false,
      query: {
        startTime: undefined,
        endTime: undefined,
        year: undefined,
        month: undefined,
        pageNumber: 1,
        pageSize: 5
      },
      tableData: []
    }
  },
  created() {
    this.fetchEnergyList()
  },
  mounted() {},
  methods: {
    download() {
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = '/power/ajaxJsp/screen/ajaxEquipmentCompanyList.jsp?postType=download')
        : (url = process.env.VUE_APP_BASE_API + 'ajaxJsp/screen/ajaxEquipmentCompanyList.jsp?postType=download')
      window.location.href = url
    },
    fetchEnergyList(val) {
      this.load = true
      if (val) this.query.pageNumber = val
      if (this.query.year && this.query.month) {
        this.query.startTime = this.query.endTime = this.query.year + '-' + this.query.month
      }
      fetchEnergyList(this.query).then(res => {
        this.tableData = this.transformData(res.data.items)
        this.total = res.data.totalCount
        this.load = false
      })
    },
    transformData(data) {
      data.forEach(item => {
        item.produceTotal = (Number(item.QC) + Number(item.A) + Number(item.AGV) + Number(item.DC)).toFixed(2)
        item.assistedTotal = (Number(item.LX) + Number(item.JF)).toFixed(2)
        item.total = (
          Number(item.produceTotal) +
          Number(item.assistedTotal) +
          Number(item.FZ) +
          Number(item.BG) +
          Number(item.ST)
        ).toFixed(2)
      })
      return data
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/cost/index.scss';
</style>
