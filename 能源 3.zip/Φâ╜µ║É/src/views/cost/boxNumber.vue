<template>
  <div>
    <div class="mt-10 box-container pl-30 pr-30">
      <div class="flex box-title font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="">
        <span>堆存天数和对应箱量</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="">
      </div>
      <div class="text-center electron-title">
        {{ new Date().getFullYear() }}年 {{ new Date().getMonth() + 1 }}月 冷箱堆存天数和对应箱量（自然箱）统计表
      </div>
      <el-row class="text-center pl-30 pr-30 mt-30">
        <el-date-picker
          v-model="query.year"
          :picker-options="startPickerOptions"
          type="year"
          placeholder="选择年"
          format="yyyy 年"
          value-format="yyyy"
          class="mr-40"
        />
        <el-date-picker
          v-model="query.month"
          format="MM 月 "
          value-format="MM"
          class="mr-35"
          type="month"
          placeholder="选择日期"
        />
        <span class="select-row-search" @click="fetchBoxNumber()">查询</span>
      </el-row>
      <div class="mt-30">
        <el-table
          v-loading="load"
          show-summary
          :summary-method="getSummaries"
          :span-method="objectSpanMethod"
          max-height="620"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(0,0,0,0)"
          border
          :data="listData"
          :cell-style="{ borderColor: '#30a0d8' }"
          :header-cell-style="{ borderColor: '#30a0d8' }"
        >
          <el-table-column
            v-for="(item, index) in column"
            :key="index"
            :label="item.label"
            :prop="item.prop"
            align="center"
          />
        </el-table>
      </div>
    </div>
  </div>
</template>

<script>
import { fetchBoxNumber } from '@/api/cost'

export default {
  name: 'Stock',
  data() {
    return {
      startPickerOptions: {
        disabledDate(time) {
          return Number(time.getFullYear()) < 2017 || Number(time.getFullYear()) > Number(new Date().getFullYear())
        }
      },
      query: {
        year: undefined,
        month: undefined
      },
      load: false,
      listData: [],
      column: [
        { prop: 'ROWNUM', label: '序号' },
        { prop: 'DAY', label: '天数' },
        { prop: 'TOTAL', label: '箱量' },
        { prop: 'count', label: '合计' }
      ],
      sum: 0
    }
  },
  created() {
    this.fetchBoxNumber()
  },
  methods: {
    getSummaries(param) {
      console.log(param)
      const { columns } = param
      const sums = ['', '', '', '']
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = '合计'
          return
        }
        if (index === columns.length - 1) {
          sums[index] = this.sum
        }
      })

      return sums
    },
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 3) {
        if (row.DAY < 5) {
          return {
            rowspan: 6,
            colspan: 1
          }
        } else {
          return {
            rowspan: this.listData.length - 6,
            colspan: 1
          }
        }
      }
    },
    fetchBoxNumber() {
      this.load = true
      fetchBoxNumber(this.query).then((res) => {
        res.data.report.forEach((i) => {
          if (i.DAY < 6) {
            i.count = res.data.total0
          } else {
            i.count = res.data.total1
          }
        })
        this.sum = Number(res.data.total0) + Number(res.data.total1)
        this.listData = res.data.report
        this.load = false
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/cost/index.scss';
::v-deep .el-table__footer-wrapper {
  background-color: rgba(39, 129, 174, 0.8);
}
::v-deep .el-table__footer-wrapper tbody td.el-table__cell {
  color: #fff;
  border-color: #2781aecc;
  background-color: rgba(39, 129, 174, 0.8);
}
</style>
