<template>
  <div>
    <div class="box-container mt-10 pl-30 pr-30">
      <div class="box-title flex font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="" />
        <span>月度能耗表</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="" />
      </div>
      <div class="text-center electron-title">
        {{ query.year || new Date().getFullYear() }}年 {{ query.startMonth || '1' }} 月 ~
        {{ query.endMonth || new Date().getMonth() + 1 }} 月能耗表
      </div>
      <el-row class="pl-30 text-center pr-30 mt-30">
        <el-date-picker
          v-model="query.year"
          :picker-options="startPickerOptions"
          type="year"
          placeholder="选择年"
          format="yyyy 年"
          value-format="yyyy"
          class="mr-40"
        />
        <el-date-picker
          v-model="query.startMonth"
          format="MM 月 "
          value-format="MM"
          class="mr-35"
          type="month"
          placeholder="选择日期"
        />
        <span class="mr-35" style="font-size: 2rem">至</span>
        <el-date-picker
          v-model="query.endMonth"
          format="MM 月 "
          value-format="MM"
          class="mr-35"
          type="month"
          placeholder="选择日期"
        />
        <!-- <span class="select-row-search mr-20" @click="download">导出表格</span> -->
        <span class="select-row-search" @click="fetchEnergy">查询</span>
      </el-row>
      <div class="mt-30">
        <el-table
          v-loading="load"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(0,0,0,0)"
          :data="tableData"
          :cell-style="{ borderColor: '#30a0d8' }"
          :header-cell-style="{ borderColor: '#30a0d8' }"
        >
          <el-table-column align="center" prop="type" label="能源种类" />
          <el-table-column align="center" label="生产">
            <el-table-column align="center" prop="COST.NOWNUM" label="本期" />
            <el-table-column align="center" prop="COST.LASTNUM" label="同期" />
          </el-table-column>
          <el-table-column align="center" label="能耗增比">
            <el-table-column align="center" prop="COST.ZJL" label="增减量" />
            <el-table-column align="center" prop="COST.ZJB" label="增减比" />
          </el-table-column>
          <el-table-column align="center" label="成本(万元)">
            <el-table-column align="center" prop="PRODUCE.NOWNUM" label="本期" />
            <el-table-column align="center" prop="PRODUCE.LASTNUM" label="同期" />
          </el-table-column>
          <el-table-column align="center" label="成本增比">
            <el-table-column align="center" prop="PRODUCE.ZJL" label="增减量" />
            <el-table-column align="center" prop="PRODUCE.ZJB" label="增减比" />
          </el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>

<script>
import { fetchEnergy } from '@/api/cost'
import { deepCopy } from '@/utils/utils'
import moment from 'moment'

export default {
  name: 'Electron',
  data() {
    return {
      startPickerOptions: {
        disabledDate(time) {
          return Number(time.getFullYear()) < 2017 || Number(time.getFullYear()) > Number(new Date().getFullYear())
        },
      },
      load: false,
      query: {
        endMonth: undefined,
        startMonth: undefined,
        year: undefined,
        startTime: undefined,
        endTime: undefined,
      },
      tableData: [],
    }
  },
  created() {
    this.fetchEnergy()
  },
  methods: {
    download() {
      const query = deepCopy(this.query)
      if (!query.year) query.year = new Date().getFullYear()
      if (!query.startMonth) query.startMonth = '01'
      if (!query.endMonth) query.endMonth = new Date().getMonth() + 1
      query.startTime = query.year + '-' + query.startMonth
      if (Number(query.endMonth < 10)) {
        query.endTime = query.year + '-' + '0' + query.endMonth
      } else {
        query.endTime = query.year + '-' + query.endMonth
      }
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = `/power/ajaxJsp/screen/ajaxEquipmentEnergyMonth.jsp?postType=download&endMonth=${query.endMonth}&endTime=${query.endTime}&startTime=${query.startTime}&startMonth=${query.startMonth}&year=${query.year}`)
        : (url =
            process.env.VUE_APP_BASE_API +
            `ajaxJsp/screen/ajaxEquipmentEnergyMonth.jsp?postType=download&endMonth=${query.endMonth}&endTime=${query.endTime}&startTime=${query.startTime}&startMonth=${query.startMonth}&year=${query.year}`)
      window.location.href = url
    },
    fetchEnergy() {
      this.load = true
      const query = deepCopy(this.query)
      if (!query.year) query.year = new Date().getFullYear()
      if (!query.startMonth) query.startMonth = '01'
      if (!query.endMonth) query.endMonth = new Date().getMonth() + 1
      query.startTime = query.year + '-' + query.startMonth
      if (Number(query.endMonth < 10)) {
        query.endTime = query.year + '-' + '0' + query.endMonth
      } else {
        query.endTime = query.year + '-' + query.endMonth
      }
      fetchEnergy(query).then((res) => {
        this.tableData = [res.data]
        this.tableData.forEach((item) => {
          item.type = '电力(万KWH)'
        })
        this.load = false
      })
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~@/styles/cost/index.scss';
</style>
