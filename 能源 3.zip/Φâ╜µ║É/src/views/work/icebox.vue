<template>
  <div>
    <div class="box-container mt-10">
      <div class="box-title flex font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="" />
        <span>{{ $route.meta.title }}</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="" />
      </div>
      <work-search />
    </div>
  </div>
</template>

<script>
import WorkSearch from '@/components/Work/searchBar.vue'

export default {
  name: 'IceBoxWork',
  components: { WorkSearch }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/work/index.scss';
.box-container {
  height: 1000px;
}
</style>
