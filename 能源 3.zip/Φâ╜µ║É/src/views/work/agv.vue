<template>
  <div>
    <div class="mt-10 box-container">
      <div class="flex box-title font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="">
        <span>AGV作业</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="">
      </div>
      <el-row class="operate-bar">
        <div class="" style="width: 100%">
          <span>设备列表:</span>
          <el-select v-model="query.type" style="width: 10%" placeholder="请选择" @change="fetchDropList">
            <el-option v-for="item in option1" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
          <el-select v-model="query.boxType" class="mr-30" style="width: 10%" placeholder="请选择">
            <el-option v-for="item in option3" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
          <el-date-picker
            v-model="query.startTime"
            :format="format"
            :value-format="valueFormat"
            style="width: 25%"
            type="month"
            class="mr-20"
            :picker-options="timeChange"
            placeholder="选择年月"
          />
          <el-date-picker
            v-model="query.endTime"
            :format="format"
            :value-format="valueFormat"
            style="width: 25%"
            :picker-options="timeChange"
            type="month"
            placeholder="选择年月"
          />
          <div class="mr-20 select-row-search" @click="showTable">查看表格</div>
          <div class="select-row-search" @click="search">查询</div>
        </div>
      </el-row>
      <el-row style="height: 450px; margin-top: 180px" class="mt-40 pl-30 pr-30">
        <el-col :span="24" style="height: 100%">
          <div
            id="equipmentLine"
            ref="equipmentLine"
            v-loading="load"
            v-on-echart-resize
            element-loading-text="拼命加载中"
            element-loading-spinner="el-icon-loading"
            element-loading-background="rgba(3, 10, 33, 0.8)"
          />
        </el-col>
      </el-row>
      <!-- <el-row style="height: 360px" class="mt-20 pl-30 pr-30">
        <el-col :span="24" style="height: 100%">
          <div
            id="iceBar"
            ref="iceBar"
            v-loading="load"
            v-on-echart-resize
            element-loading-text="拼命加载中"
            element-loading-spinner="el-icon-loading"
            element-loading-background="rgba(3, 10, 33, 0.8)"
          />
        </el-col>
      </el-row> -->
    </div>
    <list-table
      :column="column"
      :sum="sum"
      :table-visible="tableVisible"
      :total="total"
      :table-data="tableData"
      @close="close"
      @download="download"
    />
  </div>
</template>

<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import { fetchDropList, fetchIceBoxStatistics } from '@/api/analysis'
import { fetchBridge } from '@/api/work'
import { deepCopy } from '@/utils/utils'
import moment from 'moment'
import ListTable from '@/components/ListTable.vue'

export default {
  name: 'BridgeWork',
  components: { ListTable },
  data() {
    return {
      bar: undefined,
      total: 0,
      sum: ['合计', '', 0],
      tableData: [],
      tableVisible: false,
      load: false,
      timeChange: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      format: 'yyyy 年 MM 月',
      valueFormat: 'yyyy-MM',
      option3: [
        {
          value: 'Natural',
          label: '自然箱'
        },
        {
          value: 'Standard',
          label: '标准箱'
        }
      ],
      option1: [
        {
          value: 'AGV',
          label: '自动导引车AGV'
        }
      ],
      option2: [],
      value: '',
      line: undefined,
      column: [],
      query: {
        type: 'AGV',
        postType: 'query',
        startTime: moment().year(moment().year() - 1).format('YYYY-MM'),
        endTime: moment().format('YYYY-MM'),
        boxType: 'Standard',
        danwei: 'KWH'
      }
    }
  },
  mounted() {
    this.line = echarts.init(document.getElementById('equipmentLine'))
    this.fetchDropList()
  },
  destroyed() {
    if (this.line) this.line.dispose()
    if (this.bar) this.bar.dispose()
  },
  methods: {
    transformParameters() {
      const query = deepCopy(this.query)
      if (!query.startTime) query.startTime = moment().subtract(1, 'months').format('YYYY-MM')
      if (!query.endTime) query.endTime = moment().format('YYYY-MM')
      return query
    },
    download() {
      const query = this.transformParameters()
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = `/power/ajaxJsp/screen/ajaxEquipmentCompanyStatistics.jsp?postType=download&danwei=${query.danwei}&startTime=${query.startTime}&endTime=${query.endTime}&boxType=${query.boxType}`)
        : (url =
            process.env.VUE_APP_BASE_API +
            `ajaxJsp/screen/ajaxEquipmentCompanyStatistics.jsp?postType=download&danwei=${query.danwei}&startTime=${query.startTime}&endTime=${query.endTime}&boxType=${query.boxType}`)
      window.location.href = url
    },
    close() {
      this.tableVisible = false
    },
    showTable() {
      this.tableVisible = true
    },
    changeFormat(val) {
      switch (val) {
        case 'year':
          this.valueFormat = 'yyyy'
          this.format = 'yyyy 年'
          break
        case 'month':
          this.valueFormat = 'yyyy-MM'
          this.format = 'yyyy 年 MM 月'
          break
        case 'week':
          this.valueFormat = 'yyyy-MM-dd'
          this.format = 'yyyy 年 MM 月 dd 日'
          break
        case 'day':
          this.valueFormat = 'yyyy-MM-dd'
          this.format = 'yyyy 年 MM 月 dd 日'
          break
        case 'hour':
          this.valueFormat = 'yyyy-MM-dd HH'
          this.format = 'yyyy 年 MM 月 dd 日 HH 时'
          break
      }
    },
    search() {
      this.fetchBridge()
    },
    fetchDropList(val) {
      fetchDropList({ eqName: val || 'AGV' }).then((res) => {
        this.option2 = res.data
        this.fetchBridge()
      })
    },
    fetchIceBoxStatistics() {
      const query = this.transformParameters()
      fetchIceBoxStatistics(query).then((res) => {
        this.drawBar(res.data)
      })
    },
    fetchBridge() {
      this.load = true
      const query = this.transformParameters()
      fetchBridge(query).then((res) => {
        if (res.data.length === 0) {
          this.$message({
            message: '暂无数据',
            type: 'warning'
          })
          this.load = false
        } else {
          this.tableData = res.data
          this.transformData(res.data)
        }
      })
    },
    drawBar(data) {
      const option = {
        grid: {
          left: '0%',
          right: '0%',
          top: '10%',
          bottom: '5%',
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        xAxis: {
          show: true,
          type: 'category',
          splitLine: {
            show: false
          },
          data: data.map((item) => item.TYPE),
          axisLabel: {
            show: true,
            textStyle: {
              color: '#fff'
            }
          }
        },
        yAxis: {
          axisLine: {
            show: true
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: '#fff'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed'
            }
          }
        },
        series: [
          {
            name: '自然箱数量',
            type: 'bar',
            data: data.map((item) => item.TOTAL)
          }
        ]
      }
      this.bar = echarts.init(document.getElementById('iceBar'))
      option && this.bar.setOption(option)
      this.load = false
    },
    transformData(data) {
      const series = []
      let time = []
      data.forEach((item) => {
        time = item.value.map((ele) => ele.TIME)
        series.push({
          name: item.name,
          type: 'line',
          data: item.value.map((ele) => ele.TOTAL)
        })
      })
      data.forEach((i) => {
        i.value.forEach((x) => {
          x.name = i.name
        })
      })
      const newArr = []
      for (const i in data) {
        newArr.push({
          name: data[i].name
        })
      }
      data.forEach((x) => {
        for (let i = 0; i < x.value.length; i++) {
          const obj = x.value[i]
          const newKey = x.value[i].TIME
          obj[newKey] = obj.TOTAL
          for (const y of newArr) {
            if (y.name === obj.name) {
              y[newKey] = obj.TOTAL
            }
          }
        }
      })
      this.tableData = newArr
      const scope = data[0].value.map((x) => x.TIME)
      const column = [{ prop: 'name', label: '设备编码', fixed: true }]
      // 把时间筛选出来 为column赋值
      for (const i of scope) {
        column.push({
          prop: i,
          label: i
        })
      }
      this.column = column
      if (this.sum[2] !== 0) this.sum = ['合计', '', 0]
      this.tableData.forEach((i) => {
        this.sum[2] += Number(i.TOTAL)
      })
      this.total = this.tableData.length
      if (this.line) this.line.clear()
      this.drawLine(series, time)
    },
    drawLine(series, time) {
      const option = {
        legend: {
          type: 'scroll',
          textStyle: {
            color: '#fff',
            fontSize: 16
          }
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: '#6a7985'
            }
          },
          formatter: (params) => {
            let str = ''
            params.forEach((i, index) => {
              if (index !== 0 && (index + 1) % 3 === 0) {
                str = str + i.marker + i.seriesName + ' ' + i.value + '<br>'
              } else {
                str = str + i.marker + `<span style='margin-right:10px;'>${i.seriesName} ${i.value}</span>`
              }
            })
            return str
          }
        },
        grid: {
          top: '10%',
          left: '0%',
          right: '0%',
          bottom: '0%',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            axisLabel: {
              show: true,
              textStyle: {
                color: '#fff',
                fontSize: '14'
              }
            },
            data: time
          }
        ],
        yAxis: [
          {
            type: 'value',
            splitLine: {
              lineStyle: {
                color: '#1d2c47'
              }
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: '#17bae0',
                fontSize: '16',
                fontWeight: 'bold'
              }
            }
          }
        ],
        series: series
      }
      this.line = echarts.init(document.getElementById('equipmentLine'))
      option && this.line.setOption(option)
      this.load = false
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/work/index.scss';
@import '~@/styles/work/searchBar.scss';
</style>
