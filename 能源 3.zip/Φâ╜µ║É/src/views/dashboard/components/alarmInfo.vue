<template>
  <div class="alarm-info-two">
    <div class="alarm-info-smalltitle font-weight">
      <img class="mr-15" src="@/assets/img/index_left.png" alt="" />
      <span>报警信息</span>
      <img class="ml-15" src="@/assets/img/index_right.png" alt="" />
    </div>
    <div class="switch-button">
      <span
        class="mr-5 text-center cursor-pointer"
        :style="{
          backgroundImage:
            alarmCurrent === 'DAY'
              ? 'url(' + require('@/assets/img/index_selected.png') + ')'
              : 'url(' + require('@/assets/img/index_select.png') + ')'
        }"
        @click="changeTab('DAY')"
      >
        今日
      </span>
      <span
        class="text-center cursor-pointer"
        :style="{
          backgroundImage:
            alarmCurrent === 'MONTH'
              ? 'url(' + require('@/assets/img/index_selected.png') + ')'
              : 'url(' + require('@/assets/img/index_select.png') + ')'
        }"
        @click="changeTab('MONTH')"
      >
        本月
      </span>
    </div>
    <vue-seamless-scroll :data="alarm" class="seamless-warp" :class-option="classOption">
      <div class="alert-info-box-roll">
        <div
          v-for="(item, index) in alarm"
          :key="index"
          class="alarm-info-box-rollin cursor-pointer"
          @click="goDetail(item)"
        >
          {{ index + 1 }}.{{ item.TYPE }} {{ item.KW + 'KW' }} 临近阈值{{ item.NUM + '%' }}
        </div>
        <div v-if="alarm.length === 0" class="text-center" style="color:#fff;font-size:2rem;margin-top:80px;">
          暂无报警信息
        </div>
      </div>
    </vue-seamless-scroll>
  </div>
</template>

<script>
import { fetchAlarmInfo } from '@/api/dashboard'
import vueSeamlessScroll from 'vue-seamless-scroll'

export default {
  name: 'AlarmInfo',
  components: {
    vueSeamlessScroll
  },
  data() {
    return {
      classOption: {
        step: 0.1, // 数值越大速度滚动越快
        limitMoveNum: 7, // 开始无缝滚动的数据量 this.dataList.length
        hoverStop: true, // 是否开启鼠标悬停stop
        direction: 1, // 0向下 1向上 2向左 3向右
        openWatch: true, // 开启数据实时监控刷新dom
        singleHeight: 0, // 单步运动停止的高度(默认值0是无缝不停止的滚动) direction => 0/1
        singleWidth: 0, // 单步运动停止的宽度(默认值0是无缝不停止的滚动) direction => 2/3
        waitTime: 1000 // 单步运动停止的时间(默认值1000ms)
      },
      alarmCurrent: 'DAY',
      alarm: []
    }
  },
  created() {
    this.fetchAlarmInfo()
  },
  methods: {
    goDetail(data) {
      this.$router.push({
        path: '/alarm/alarmInfo',
        query: {
          id: data.SEQ
        }
      })
    },
    fetchAlarmInfo() {
      fetchAlarmInfo({ time: this.alarmCurrent, type: 'ALARM' }).then(res => {
        this.alarm = res.data
      })
    },
    changeTab(key) {
      this.alarmCurrent = key
      this.fetchAlarmInfo()
    }
  }
}
</script>

<style lang="scss" scoped>
.alarm-info-two {
  position: relative;
  display: flex;
  padding-top: 5rem;
  background-image: url('~@/assets/img/index_info.png');
  background-size: 100% 100%;
  .seamless-warp {
    height: 100%;
    width: 100%;
    overflow: hidden;
  }
  .alarm-info-smalltitle {
    position: absolute;
    top: 0;
    width: 70%;
    height: 12%;
    color: #fff;
    background-image: url('~@/assets/img/index_title.png');
    background-size: 100% 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
  }
  .alert-info-box-roll {
    height: 90%;
    // height: 300px;
    // width: 100%;
    overflow-y: scroll;
    margin: 1rem 1rem;
    padding: 0.5rem 1rem;
  }
  .alert-info-box-roll::-webkit-scrollbar {
    width: 0.2rem;
  }
  .alert-info-box-roll::-webkit-scrollbar-track {
    background-color: #353d53;
  }
  .alert-info-box-roll::-webkit-scrollbar-thumb {
    background-color: #1ad5fd;
  }
  .alarm-info-box-rollin {
    height: 3rem;
    width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    border: 1px solid #b27e44;
    margin-bottom: 0.9rem;
    background-color: rgba($color: #b27e44, $alpha: 0.1);
    text-align: center;
    color: #fff;
    font-size: 1.6rem;
    line-height: 3rem;
  }
  .alarm-info-box-rollin {
    border: 1px solid rgb(202, 2, 21);
    background-color: rgba($color: rgb(202, 2, 21), $alpha: 0.1);
  }
}
</style>
