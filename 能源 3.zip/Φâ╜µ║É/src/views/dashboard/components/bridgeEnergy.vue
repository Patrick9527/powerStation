<template>
  <div class="pt-20 text-right pl-15 pr-35 bottom-box">
    <div class="flex bottom-title font-weight">
      <img class="mr-15" src="@/assets/img/index_left.png" alt="">
      <span>设备能耗排名-岸桥</span>
      <img class="ml-15" src="@/assets/img/index_right.png" alt="">
    </div>
    <span class="rank-unit">单位: kW·h </span>
    <el-radio-group v-model="Type" @change="changeChart">
      <el-radio label="A">总能耗</el-radio>
      <!-- <el-radio label="D">单吨</el-radio>
      <el-radio label="B">单箱</el-radio> -->
    </el-radio-group>
    <div id="bridgeEnergy" ref="bridgeEnergy" v-on-echart-resize />
  </div>
</template>

<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import { fetchEquipmentEnergy } from '@/api/dashboard'

export default {
  name: 'BridgeEnergy',
  data() {
    return {
      Type: 'A',
      bridgeEnergy: undefined,
      timer: null,
      data: [],
      option: []
    }
  },
  mounted() {
    this.bridgeEnergy = echarts.init(document.getElementById('bridgeEnergy'))
    this.fetchEquipmentEnergy()
  },
  created() {},
  destroyed() {
    clearInterval(this.timer)
  },
  methods: {
    moveOut() {
      this.timer = setInterval(() => {
        // 每次向后滚动一个，最后一个从头开始。
        if (this.option.dataZoom[0].endValue === 0) {
          this.option.dataZoom[0].endValue = this.data.length - 5
          this.option.dataZoom[0].startValue = this.data.length - 1
        } else {
          this.option.dataZoom[0].endValue = this.option.dataZoom[0].endValue - 1
          this.option.dataZoom[0].startValue = this.option.dataZoom[0].startValue - 1
        }
        this.option && this.bridgeEnergy.setOption(this.option)
      }, 2000)
    },
    moveIn() {
      clearInterval(this.timer)
    },
    changeChart(val) {
      if (this.timer) clearInterval(this.timer)
      this.fetchEquipmentEnergy(val)
    },
    fetchEquipmentEnergy(val) {
      this.bridgeEnergy.showLoading({
        maskColor: 'rgba(4, 13, 38, 1)'
      })
      fetchEquipmentEnergy({ machine: 'QC', Type: val }).then(res => {
        this.data = res.data
        // const value = res.data.map(item => item.R)
        // const max = res.data
        //   .map(item => item.R)
        //   .sort(function(a, b) {
        //     return b - a
        //   })[0]
        // const y = Number(max).toFixed(0).length - 1
        // const floatNumber = Math.pow(10, y - 1)
        // const arr1 = this.generateArrary(value.length, Number(max) + floatNumber)
        // this.drawBridgeEnergy(res.data, arr1)
        this.drawBridgeEnergy(res.data)
      })
    },
    generateArrary(length, max) {
      return Array.from({ length: length }, (item, index) => (item = max))
    },
    drawBridgeEnergy(data, arr) {
      console.log(data)
      this.option = {
        // 图表头部提示
        legend: {
          // 提示内容，要和series中name保持一致
          data: ['条', '框'],
          // 是否显示（true显示/false不显示）
          show: false
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: '#6a7985'
            }
          }
        },
        // 网格也就是整个图表
        grid: {
          // 距离左边的距离
          left: '0%',
          // 距离右边的距离
          right: '10%',
          // 距离底部的距离
          bottom: '6%',
          top: '0',
          containLabel: true
        },
        // x轴
        xAxis: {
          // 不显示x轴
          show: false
        },
        // y轴
        yAxis: {
          // 坐标轴
          type: 'category',
          // 显示的左侧提示
          axisLabel: {
            show: true,
            verticalAlign: 'middle',
            color: '#fff',
            margin: 10,
            fontSize: 12
          },
          data: data.map(item => item.TYPE).reverse(),
          // y轴的线
          axisLine: {
            // 设置为不显示
            show: false
          },
          // y轴线上的标记刻度
          axisTick: {
            // 设置为不显示
            show: false
          }
        },
        dataZoom: [
          {
            type: 'slider',
            show: true,
            filterMode: 'empty',
            disabled: false,
            yAxisIndex: 0,
            right: '5%',
            width: 10,
            startValue: data.length - 1,
            endValue: data.length - 5,
            handleSize: '0', // 滑动条的 左右2个滑动小块的大小
            handleIcon:
              'path://M306.1,413c0,2.2-1.8,4-4,4h-59.8c-2.2,0-4-1.8-4-4V200.8c0-2.2,1.8-4,4-4h59.8c2.2,0,4,1.8,4,4V413z',
            textStyle: {
              color: '#3C62C0'
            },
            fillerColor: '#3C62C0', // 拖动条的颜色
            borderColor: 'none',
            backgroundColor: 'rgba(60, 98, 192, 0.302)',
            showDetail: false // 即拖拽时候是否显示详细数值信息 默认true
          }
        ],
        // 具体数据及样式
        series: [
          {
            type: 'bar',
            // 具体每一个的数据
            data: data.map(item => item.R).reverse(),
            // 单个的样式
            itemStyle: {
              color: '#75d1ff'
            },
            label: {
              show: true,
              position: 'right',
              color: '#A6B6C6',
              fontSize: 12
            }
          }
        ]
      }
      // this.timer = setInterval(() => {
      //   // 每次向后滚动一个，最后一个从头开始。
      //   if (this.option.dataZoom[0].endValue === 0) {
      //     this.option.dataZoom[0].endValue = data.length - 5
      //     this.option.dataZoom[0].startValue = data.length - 1
      //   } else {
      //     this.option.dataZoom[0].endValue = this.option.dataZoom[0].endValue - 1
      //     this.option.dataZoom[0].startValue = this.option.dataZoom[0].startValue - 1
      //   }
      //   this.option && this.bridgeEnergy.setOption(this.option)
      //   this.bridgeEnergy.hideLoading()
      //   // this.bridgeEnergy.on('datazoom', params => {
      //   //   if (params) {
      //   //     console.log(params)
      //   //     let index = data.length - 1 - String(Number(params.end).toFixed(0)).substr(0, 1) - 2
      //   //     if (index > data.length || params.end === 100) index = 0
      //   //     if (params.start === 0) index = data.length - 1
      //   //     console.log(index)
      //   //     console.log(data[index])
      //   //     this.option.dataZoom[0].start = params.start
      //   //     this.option.dataZoom[0].end = params.end
      //   //   }
      //   // })
      // }, 2000)
      this.option && this.bridgeEnergy.setOption(this.option)
      this.bridgeEnergy.hideLoading()
    }
  }
}
</script>

<style lang="scss" scoped>
#bridgeEnergy {
  position: absolute;
  height: calc(100% - 2rem);
  width: 100%;
}
.rank-unit {
  position: absolute;
  color: #fff;
  top: -20px;
  right: 40px;
  font-size: 16px;
}
</style>
