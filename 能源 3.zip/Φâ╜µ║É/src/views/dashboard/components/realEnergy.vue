<template>
  <div id="realEnergyChart" ref="realEnergyChart" v-on-echart-resize />
</template>

<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import { fetchRealEnergy } from '@/api/dashboard'

export default {
  name: 'RealEnergy',
  data() {
    return {
      realEnergy: undefined
    }
  },
  mounted() {
    this.realEnergy = echarts.init(document.getElementById('realEnergyChart'))
    this.fetchRealEnergy()
  },
  created() {},
  methods: {
    fetchRealEnergy() {
      fetchRealEnergy().then(res => {
        const name = res.data.map(item => item.TYPE)
        const value = res.data.map(item => item.R)
        const max = res.data
          .map(item => item.R)
          .sort(function(a, b) {
            return b - a
          })[0]
        const arr1 = this.generateArrary(value.length, Number(max))
        this.drawRealEnergy(value, name, arr1)
      })
    },
    generateArrary(length, max) {
      return Array.from({ length: length }, (item, index) => (item = max))
    },
    drawRealEnergy(value, name, arr1) {
      console.log(value)
      const option = {
        grid: {
          top: '0%',
          left: '0%',
          right: '2%',
          bottom: '0%',
          containLabel: true
        },
        // x轴
        xAxis: {
          type: 'value',
          splitLine: {
            show: false
          },
          min: 0,
          max: arr1[0],
          axisLabel: {
            show: true,
            // formatter: val => {
            //   const txt = Math.floor((Number(val) / 1000) * 100) / 100
            //   return (Number(val)
            // },
            textStyle: {
              color: '#75d1ff'
            }
          }
        },
        // y轴
        yAxis: [
          {
            // 坐标轴
            type: 'category',
            // 显示的左侧提示
            data: name.reverse() || [],
            // y轴的线
            axisLine: {
              // 设置为不显示
              show: false
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: '#ffffff'
              }
            },
            // y轴线上的标记刻度
            axisTick: {
              show: false
            }
          },
          {
            // 坐标轴
            type: 'category',
            show: true,
            axisTick: {
              show: false
            },
            axisLine: {
              // 设置为不显示
              show: false
            },
            axisLabel: {
              formatter: val => {
                const txt = Math.floor(Number(value[val]))
                return txt
              },
              // 右侧显示的数据样式
              textStyle: {
                // 字体大小
                fontSize: 13,
                // 字体颜色
                color: '#6dc4f1'
              }
            }
          }
        ],
        // 具体数据及样式
        series: [
          {
            // 这是显示条
            name: '条',
            // 设置为条状图
            type: 'bar',
            // 具体每一个的数据
            data: value.reverse() || [],
            // 单个的样式
            itemStyle: {
              // 设置颜色
              color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                { offset: 0, color: '#1d8ce6' },
                { offset: 0.5, color: '#1ac5f2' },
                { offset: 1, color: '#18fdfe' }
              ])
            },
            //
            barCategoryGap: '5%',
            // 柱状图的宽度
            barWidth: 10,
            // 样式
            label: {
              show: false,
              color: '#fff',
              position: 'right'
            },
            // 这是第一个
            yAxisIndex: 0
          },
          {
            // 设置柱状图的外框
            name: '框',
            // 设置为柱状
            type: 'bar',
            barCategoryGap: '5%',
            // 柱状图的宽度
            barWidth: 15,
            // 每一个的样式
            itemStyle: {
              // 颜色
              color: 'none',
              // 边框色
              borderColor: '#00C1DE',
              // border宽度
              borderWidth: 2
            },
            // 柱状图的长度
            data: arr1,
            // 第二个堆在第一个上
            yAxisIndex: 1
          }
        ]
      }
      option && this.realEnergy.setOption(option)
    }
  }
}
</script>

<style lang="scss" scoped>
#realEnergyChart {
  width: 100%;
  height: 100%;
}
</style>
