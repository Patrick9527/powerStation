<template>
  <div>
    <div class="box-container mt-10">
      <div class="box-title flex font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="" />
        <span>AGV成本分析</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="" />
      </div>
      <el-row class="operate-bar">
        <div class="mr-30">
          <span>设备列表:</span>
          <el-select v-model="query.type" style="width: 18%" placeholder="请选择" @change="fetchDropList">
            <el-option v-for="item in option1" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
          <el-select
            v-model="query.machine"
            multiple
            filterable
            style="width: 65%"
            placeholder="请选择"
            @change="changeMachine"
          >
            <el-option label="全部设备" value="" />
            <el-option v-for="item in option2" :key="item" :label="item" :value="item" />
          </el-select>
        </div>
        <el-select v-model="query.boxType" class="mr-30" style="width: 8%" placeholder="请选择">
          <el-option v-for="item in option3" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-radio-group v-model="query.circle">
          <el-radio label="year">年</el-radio>
          <el-radio label="month">月</el-radio>
          <el-radio label="week">周</el-radio>
          <el-radio label="day">日</el-radio>
          <el-radio label="hour">小时</el-radio>
        </el-radio-group>
      </el-row>
      <el-row class="mt-20 operate-bar-line2" :style="query.machine.length > 8 ? 'marginTop:40px' : ''">
        <div class="mr-30">
          <span />
          <el-date-picker
            v-model="query.startTime"
            :format="format"
            :value-format="valueFormat"
            style="width: 50%"
            type="datetime"
            class="mr-20"
            :picker-options="timeChange"
            placeholder="选择日期时间"
          />
          <el-date-picker
            v-model="query.endTime"
            :format="format"
            :value-format="valueFormat"
            style="width: 50%"
            :picker-options="timeChange"
            type="datetime"
            placeholder="选择日期时间"
          />
        </div>
        <div class="select-row-search mr-20" @click="showTable">查看表格</div>
        <div class="select-row-search" @click="search">查询</div>
      </el-row>
      <el-row style="height: 640px" class="mt-40 pl-30 pr-30">
        <el-col :span="12" style="height: 100%">
          <div
            id="equipmentLine"
            ref="equipmentLine"
            v-on-echart-resize
            v-loading="load"
            element-loading-text="拼命加载中"
            element-loading-spinner="el-icon-loading"
            element-loading-background="rgba(3, 10, 33, 0.8)"
          />
        </el-col>
        <el-col :span="12" style="height: 100%">
          <div
            id="pieChart"
            ref="pieChart"
            v-on-echart-resize
            v-loading="load"
            element-loading-text="拼命加载中"
            element-loading-spinner="el-icon-loading"
            element-loading-background="rgba(3, 10, 33, 0.8)"
          />
        </el-col>
      </el-row>
    </div>
    <list-table
      :column="column"
      :sum="sums"
      type="成本"
      :table-visible="tableVisible"
      :total="total"
      :table-data="tableData"
      @close="close"
      @download="download"
    />
  </div>
</template>

<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import { fetchBridge, fetchDropList, fetchZb } from '@/api/analysis'
import { deepCopy } from '@/utils/utils'
import moment from 'moment'
import ListTable from '@/components/ListTable.vue'

export default {
  name: 'BridgeWork',
  components: { ListTable },
  data() {
    return {
      column: [],
      total: 0,
      pie: undefined,
      sums: ['合计', '', 0],
      tableData: [],
      tableVisible: false,
      load: false,
      timeChange: {
        disabledDate(time) {
          return time.getTime() < Date.now() - 3600 * 1000 * 24 * 183 || time.getTime() > Date.now()
        },
      },
      format: 'yyyy 年 MM 月 dd 日 HH 时',
      valueFormat: 'yyyy-MM-dd HH',
      option3: [
        {
          value: 'Natural',
          label: '自然箱',
        },
        {
          value: 'Standard',
          label: '标准箱',
        },
      ],
      option1: [
        {
          value: 'AGV',
          label: '自动导引车AGV',
        },
      ],
      option2: [],
      value: '',
      line: undefined,
      query: {
        type: 'AGV',
        postType: 'query',
        machine: '',
        startTime: moment().format('YYYY-MM') + '-' + '01' + ' ' + '00',
        endTime: moment().format('YYYY-MM-DD') + ' ' + '00',
        boxType: 'Natural',
        danwei: 'KWH',
        circle: 'day',
        i: 'AGV',
      },
    }
  },
  computed: {
    radio() {
      return this.query.circle
    },
  },
  watch: {
    radio: {
      handler: 'changeFormat',
    },
  },
  destroyed() {
    if (this.line) this.line.dispose()
  },
  mounted() {
    this.pie = echarts.init(document.getElementById('pieChart'))
    this.line = echarts.init(document.getElementById('equipmentLine'))
    this.fetchDropList()
  },
  methods: {
    drawPie(data) {
      const option = {
        tooltip: {
          trigger: 'item',
        },
        series: [
          {
            name: '费用占比',
            type: 'pie',
            radius: '50%',
            label: {
              color: '#fff',
              fontSize: '15',
              formatter: function (params) {
                if (params.name === '支出费用') {
                  return '当前查询设' + '\n\n' + '备支出费用占比' + '{one|' + '\n\n' + params.percent + '%' + ' }'
                } else {
                  return '其余查询设' + '\n\n' + '备支出费用占比' + '{two|' + '\n\n' + params.percent + '%' + ' }'
                }
              },
              rich: {
                one: {
                  color: '#3db5f0',
                  fontSize: 20,
                  fontWeight: 'bold',
                },
                two: {
                  fontSize: 20,
                  fontWeight: 'bold',
                  color: '#fead51',
                },
              },
              align: 'left',
            },
            labelLine: {
              length2: 20,
            },
            center: ['50%', '50%'],
            data: [
              { value: Number(data.current), name: '支出费用', itemStyle: { color: '#3db5f0' } },
              { value: Number(data.total), name: '总费用', itemStyle: { color: '#fead51' } },
            ],
          },
        ],
      }
      this.pie = echarts.init(document.getElementById('pieChart'))
      option && this.pie.setOption(option)
      this.load = false
    },
    fetchZb() {
      this.load = true
      const query = this.transformParameters()
      fetchZb(query).then((res) => {
        this.drawPie(res.data)
      })
    },
    download() {
      const query = this.transformParameters()
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = `/power/ajaxJsp/screen/ajaxEquipmentOneEnergy.jsp?postType=download&danwei=${query.danwei}&startTime=${query.startTime}&endTime=${query.endTime}&machine=${query.machine}&type=${query.type}&type=${query.type}&boxType=${query.boxType}&circle=${query.circle}`)
        : (url =
            process.env.VUE_APP_BASE_API +
            `ajaxJsp/screen/ajaxEquipmentOneEnergy.jsp?postType=download&danwei=${query.danwei}&startTime=${query.startTime}&endTime=${query.endTime}&machine=${query.machine}&type=${query.type}&type=${query.type}&boxType=${query.boxType}&circle=${query.circle}`)
      window.location.href = url
    },
    transformParameters() {
      const query = deepCopy(this.query)
      if (!query.startTime) query.startTime = moment().format('YYYY-MM') + '-' + '01'
      if (!query.endTime) query.endTime = moment().format('YYYY-MM-DD')
      if (!query.machine || query.machine.length === 0) {
        query.machine = ''
      } else {
        query.machine = query.machine.join()
      }
      return query
    },
    close() {
      this.tableVisible = false
    },
    showTable() {
      this.tableVisible = true
    },
    changeMachine(val) {
      if (val[val.length - 1] === '') {
        this.query.machine = ['']
      } else {
        const index = val.indexOf('')
        if (index !== -1) this.query.machine.splice(index, 1)
      }
    },
    changeFormat(val) {
      switch (val) {
        case 'year':
          this.valueFormat = 'yyyy'
          this.format = 'yyyy 年'
          break
        case 'month':
          this.valueFormat = 'yyyy-MM'
          this.format = 'yyyy 年 MM 月'
          break
        case 'week':
          this.valueFormat = 'yyyy-MM-dd'
          this.format = 'yyyy 年 MM 月 dd 日'
          break
        case 'day':
          this.valueFormat = 'yyyy-MM-dd'
          this.format = 'yyyy 年 MM 月 dd 日'
          break
        case 'hour':
          this.valueFormat = 'yyyy-MM-dd HH'
          this.format = 'yyyy 年 MM 月 dd 日 HH 时'
          break
      }
    },
    search() {
      this.fetchBridge()
    },
    fetchDropList(val) {
      fetchDropList({ eqName: val || 'AGV' }).then((res) => {
        this.option2 = res.data
        const temp = deepCopy(this.option2)
        this.query.machine = temp.splice(0, 5)
        this.fetchBridge()
        this.fetchZb()
      })
    },
    fetchBridge() {
      this.load = true
      const query = this.transformParameters()
      fetchBridge(query).then((res) => {
        if (res.data.length === 0) {
          this.$message({
            message: '暂无数据',
            type: 'warning',
          })
          this.load = false
        } else {
          this.tableData = res.data
          this.transformData(res.data)
        }
      })
    },
    transformData(data) {
      const series = []
      let time = []
      data.forEach((item) => {
        time = item.value.map((ele) => ele.TIME)
        series.push({
          name: item.name,
          type: 'line',
          data: item.value.map((ele) => ele.TOTAL),
        })
      })
      data.forEach((i) => {
        i.value.forEach((x) => {
          x.name = i.name
        })
      })
      const newArr = []
      for (const i in data) {
        newArr.push({
          name: data[i].name,
        })
      }
      data.forEach((x) => {
        for (let i = 0; i < x.value.length; i++) {
          const obj = x.value[i]
          const newKey = x.value[i].TIME
          obj[newKey] = obj.TOTAL
          for (const y of newArr) {
            if (y.name === obj.name) {
              y[newKey] = obj.TOTAL
            }
          }
        }
      })
      this.tableData = newArr
      const scope = data[0].value.map((x) => x.TIME)
      const column = [{ prop: 'name', label: '设备编码', fixed: true }]
      // 把时间筛选出来 为column赋值
      for (const i of scope) {
        column.push({
          prop: i,
          label: i,
        })
      }
      this.column = column
      if (this.line) this.line.clear()
      this.drawLine(series, time)
    },
    drawLine(series, time) {
      const option = {
        legend: {
          type: 'scroll',
          textStyle: {
            color: '#fff',
            fontSize: 16,
          },
          // itemGap: 75
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: '#6a7985',
            },
          },
          formatter: (params) => {
            let str = ''
            params.forEach((i, index) => {
              if (index !== 0 && (index + 1) % 3 === 0) {
                str = str + i.marker + i.seriesName + ' ' + i.value + '<br>'
              } else {
                str = str + i.marker + `<span style='margin-right:10px;'>${i.seriesName} ${i.value}</span>`
              }
            })
            return str
          },
        },
        grid: {
          top: '10%',
          left: '0%',
          right: '0%',
          bottom: '0%',
          containLabel: true,
        },
        xAxis: [
          {
            type: 'category',
            axisLabel: {
              show: true,
              textStyle: {
                color: '#fff',
                fontSize: '14',
              },
            },
            data: time,
          },
        ],
        yAxis: [
          {
            type: 'value',
            splitLine: {
              lineStyle: {
                color: '#1d2c47',
              },
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: '#17bae0',
                fontSize: '16',
                fontWeight: 'bold',
              },
            },
          },
        ],
        series: series,
      }
      this.line = echarts.init(document.getElementById('equipmentLine'))
      option && this.line.setOption(option)
      this.load = false
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~@/styles/work/index.scss';
@import '~@/styles/work/searchBar.scss';
</style>
