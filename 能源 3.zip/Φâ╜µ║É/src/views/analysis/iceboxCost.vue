<template>
  <div>
    <div class="box-container mt-10" style="height:965px;">
      <div class="box-title flex font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="">
        <span>冷箱成本分析</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="">
      </div>
      <el-row class="operate-bar">
        <div class="mr-30">
          <span>设备列表:</span>
          <el-select v-model="query.type" style="width:15%;" placeholder="请选择" @change="fetchDropList">
            <el-option v-for="item in option1" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
          <el-select
            v-model="query.machine"
            multiple
            filterable
            style="width:65%;"
            placeholder="请选择"
            @change="changeMachine"
          >
            <el-option label="全部设备" value="" />
            <el-option v-for="item in option2" :key="item" :label="item" :value="item" />
          </el-select>
        </div>
        <el-select v-model="query.boxType" class="mr-30" style="width:8%;" placeholder="请选择">
          <el-option v-for="item in option3" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
        <el-radio-group v-model="query.circle">
          <el-radio label="year">年</el-radio>
          <el-radio label="month">月</el-radio>
          <el-radio label="week">周</el-radio>
          <el-radio label="day">日</el-radio>
          <el-radio label="hour">小时</el-radio>
        </el-radio-group>
      </el-row>
      <el-row class="mt-20 operate-bar-line2" :style="query.machine.length > 8 ? 'marginTop:40px' : ''">
        <div class="mr-30">
          <span />
          <el-date-picker
            v-model="query.startTime"
            :format="format"
            :value-format="valueFormat"
            style="width:50%;"
            type="datetime"
            class="mr-20"
            :picker-options="timeChange"
            placeholder="选择日期时间"
          />
          <el-date-picker
            v-model="query.endTime"
            :format="format"
            :value-format="valueFormat"
            style="width:50%;"
            :picker-options="timeChange"
            type="datetime"
            placeholder="选择日期时间"
          />
        </div>
        <div class="select-row-search mr-20" @click="showTable">查看表格</div>
        <div class="select-row-search" @click="search">查询</div>
      </el-row>
      <div style="width:100%;padding: 0 90px 0 70px;">
        <ul class="tips-bar mt-20">
          <li>
            <span>平均在场时间(小时)</span>
            <div class="text-center">
              <span v-for="(item, index) in tips.AVG_INSIDE" :key="index" class="tips-characters">{{ item }}</span>
              <span v-if="!tips.AVG_INSIDE">暂无</span>
            </div>
          </li>
          <li>
            <span>大温差冷箱个数</span>
            <div class="text-center">
              <span v-for="(item, index) in tips.LARGE_DIFF" :key="index" class="tips-characters">{{ item }}</span>
              <span v-if="!tips.LARGE_DIFF">暂无</span>
            </div>
          </li>
          <li>
            <span>标准温差冷箱个数</span>
            <div class="text-center">
              <span v-for="(item, index) in tips.SMALL_DIFF" :key="index" class="tips-characters">{{ item }}</span>
              <span v-if="!tips.SMALL_DIFF">暂无</span>
            </div>
          </li>
        </ul>
      </div>
      <el-row style="height:640px;" class="mt-40 pl-30 pr-30">
        <el-col :span="18" style="height:100%;">
          <div
            id="equipmentLine"
            ref="equipmentLine"
            v-on-echart-resize
            v-loading="load"
            element-loading-text="拼命加载中"
            element-loading-spinner="el-icon-loading"
            element-loading-background="rgba(3, 10, 33, 0.8)"
          />
        </el-col>
        <el-col :span="6" class="energy-progress pl-50">
          <div class="energy-progress-inner">
            <span class="energy-progress-inner-sum">峰电量百分比</span>
            <el-progress
              :stroke-width="10"
              :width="180"
              class="mt-30 mb-30"
              type="circle"
              :percentage="0 || peak.percentage"
            />
            <div class="energy-progress-inner-bottom">
              <div class="text-center">
                <div>峰电量</div>
                <div>{{ peak.PEAK || '0' }}</div>
              </div>
              <div class="text-center">
                <div>总电量</div>
                <div>{{ peak.TOTAL || '0' }}</div>
              </div>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
    <list-table
      :sum="sums"
      :column="column"
      type="成本"
      :table-visible="tableVisible"
      :total="total"
      :table-data="tableData"
      @close="close"
    />
  </div>
</template>

<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import { fetchBridge, fetchDropList, fetchTips, fetchPeak } from '@/api/analysis'
import { deepCopy } from '@/utils/utils'
import moment from 'moment'
import ListTable from '@/components/ListTable.vue'

export default {
  name: 'BridgeWork',
  components: { ListTable },
  data() {
    return {
      total: 0,
      sums: ['合计', '', 0],
      tableData: [],
      tableVisible: false,
      load: false,
      timeChange: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      format: 'yyyy 年 MM 月 dd 日 HH 时',
      valueFormat: 'yyyy-MM-dd HH',
      peak: {},
      option3: [
        {
          value: 'Natural',
          label: '自然箱'
        },
        {
          value: 'Standard',
          label: '标准箱'
        }
      ],
      option1: [
        {
          value: 'YARD',
          label: '堆场'
        }
      ],
      option2: [],
      value: '',
      line: undefined,
      tips: {},
      query: {
        type: 'YARD',
        postType: 'query',
        machine: '',
        startTime: moment().format('YYYY-MM') + '-' + '01' + ' ' + '00',
        endTime: moment().format('YYYY-MM-DD') + ' ' + '00',
        boxType: 'Natural',
        danwei: 'KWH',
        circle: 'day'
      },
      column: []
    }
  },
  computed: {
    radio() {
      return this.query.circle
    }
  },
  watch: {
    radio: {
      handler: 'changeFormat'
    }
  },
  mounted() {
    this.line = echarts.init(document.getElementById('equipmentLine'))
    this.fetchDropList()
  },
  destroyed() {
    if (this.line) this.line.dispose()
  },
  methods: {
    close() {
      this.tableVisible = false
    },
    showTable() {
      this.tableVisible = true
    },
    changeFormat(val) {
      switch (val) {
        case 'year':
          this.valueFormat = 'yyyy'
          this.format = 'yyyy 年'
          break
        case 'month':
          this.valueFormat = 'yyyy-MM'
          this.format = 'yyyy 年 MM 月'
          break
        case 'week':
          this.valueFormat = 'yyyy-MM-dd'
          this.format = 'yyyy 年 MM 月 dd 日'
          break
        case 'day':
          this.valueFormat = 'yyyy-MM-dd'
          this.format = 'yyyy 年 MM 月 dd 日'
          break
        case 'hour':
          this.valueFormat = 'yyyy-MM-dd HH'
          this.format = 'yyyy 年 MM 月 dd 日 HH 时'
          break
      }
    },
    search() {
      this.fetchBridge()
    },
    fetchDropList(val) {
      fetchDropList({ eqName: val || 'YARD' }).then(res => {
        this.option2 = res.data
        const temp = deepCopy(this.option2)
        this.query.machine = temp.splice(0, 5)
        this.fetchBridge()
      })
    },
    changeMachine(val) {
      if (val[val.length - 1] === '') {
        this.query.machine = ['']
      } else {
        const index = val.indexOf('')
        if (index !== -1) this.query.machine.splice(index, 1)
      }
    },
    fetchBridge() {
      this.load = true
      const query = deepCopy(this.query)
      if (!query.startTime) query.startTime = moment().format('YYYY-MM') + '-' + '01'
      if (!query.endTime) query.endTime = moment().format('YYYY-MM-DD')
      if (!query.machine || query.machine.length === 0) {
        query.machine = ''
      } else {
        query.machine = query.machine.join()
      }
      fetchTips(query).then(res => {
        this.tips = res.data
      })
      fetchPeak(query).then(res => {
        this.peak = res.data
        this.peak.percentage = Math.floor((res.data.PEAK / res.data.TOTAL) * 100)
      })
      fetchBridge(query).then(res => {
        if (res.data.length === 0) {
          this.$message({
            message: '暂无数据',
            type: 'warning'
          })
          this.load = false
        } else {
          this.tableData = res.data
          this.transformData(res.data)
        }
      })
    },
    transformData(data) {
      const series = []
      let time = []
      data.forEach(item => {
        time = item.value.map(ele => ele.TIME)
        series.push({
          name: item.name,
          type: 'line',
          data: item.value.map(ele => ele.TOTAL)
        })
      })
      data.forEach(i => {
        i.value.forEach(x => {
          x.name = i.name
        })
      })
      const newArr = []
      for (const i in data) {
        newArr.push({
          name: data[i].name
        })
      }
      data.forEach(x => {
        for (let i = 0; i < x.value.length; i++) {
          const obj = x.value[i]
          const newKey = x.value[i].TIME
          obj[newKey] = obj.TOTAL
          for (const y of newArr) {
            if (y.name === obj.name) {
              y[newKey] = obj.TOTAL
            }
          }
        }
      })
      this.tableData = newArr
      const scope = data[0].value.map(x => x.TIME)
      const column = [{ prop: 'name', label: '设备编码', fixed: true }]
      // 把时间筛选出来 为column赋值
      for (const i of scope) {
        column.push({
          prop: i,
          label: i
        })
      }
      this.column = column
      this.total = this.tableData.length
      if (this.line) this.line.clear()
      this.drawLine(series, time)
    },
    drawLine(series, time) {
      const option = {
        legend: {
          type: 'scroll',
          textStyle: {
            color: '#fff',
            fontSize: 16
          }
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: '#6a7985'
            }
          }
        },
        grid: {
          top: '5%',
          left: '0%',
          right: '0%',
          bottom: '0%',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            axisLabel: {
              show: true,
              textStyle: {
                color: '#fff',
                fontSize: '14'
              }
            },
            data: time
          }
        ],
        yAxis: [
          {
            type: 'value',
            splitLine: {
              lineStyle: {
                color: '#1d2c47'
              }
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: '#17bae0',
                fontSize: '16',
                fontWeight: 'bold'
              }
            }
          }
        ],
        series: series
      }
      this.line = echarts.init(document.getElementById('equipmentLine'))
      option && this.line.setOption(option)
      this.load = false
    }
  }
}
</script>

<style lang="scss" scoped>
.energy-progress {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  .energy-progress-inner {
    height: 70%;
    width: 80%;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px 15px;
    border: 1px solid #16b3d8;
    .energy-progress-inner-bottom {
      width: 100%;
      height: 30%;
      display: flex;
      > div {
        font-size: 2rem;
        width: 50%;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: space-around;
      }
      .text-center > div:nth-child(2) {
        color: #16b3d8;
        font-size: 26px;
        word-break: break-all;
      }
      > div:nth-child(1) {
        border-right: 1px solid #fff;
      }
    }
  }
  .energy-progress-inner-sum {
    background: linear-gradient(to right, #3153b9, #041336);
    color: #fff;
    display: inline-block;
    height: 30px;
    line-height: 30px;
    text-align: center;
    font-size: 1.6rem;
    width: 100%;
  }
}

.tips-bar {
  display: flex;
  margin-right: 30px;
  width: 60%;
  justify-content: space-between;
  .tips-characters {
    background: linear-gradient(to bottom, #facd14, #e18321);
    display: inline-block;
    width: 25px;
    text-align: center;
    margin-right: 5px;
    padding: 5px;
  }
  li {
    display: flex;
    align-items: center;
    justify-content: space-around;
    flex-direction: column;
    width: 30%;
    height: 80px;
    background-color: rgba(4, 190, 239, 0.4);
    font-size: 1.8rem;
    div {
      font-size: 2.8rem;
      font-weight: bold;
    }
  }
}
::v-deep .el-progress__text {
  color: #fff;
  font-size: 3rem !important;
}
@import '~@/styles/work/index.scss';
@import '~@/styles/work/searchBar.scss';
</style>
