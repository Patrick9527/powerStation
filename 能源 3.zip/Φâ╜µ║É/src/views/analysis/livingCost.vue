<template>
  <div>
    <div class="box-container mt-10">
      <inner />
    </div>
  </div>
</template>

<script>
import Inner from '@/components/Analysis/innerContent.vue'

export default {
  name: 'LivingCost',
  components: { Inner },
  data() {
    return {}
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/work/index.scss';
</style>
