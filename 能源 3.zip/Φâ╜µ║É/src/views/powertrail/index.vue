<template>
  <div class="wrapper">
    <div class="dashboard-container">
      <el-row class="mb-15" style="margin-left: 0; margin-right: 0" type="flex" justify="space-between">
        <el-col :span="7" class="mr-15 dashboard-left" :style="{ '--height': height }">
          <div class="brick_count mb-10">
            <!-- <div class="flex vital-energy-title font-weight">
              <img class="mr-15" src="@/assets/img/index_left.png" alt="">
              <span>发电地砖总数</span>
              <img class="ml-15" src="@/assets/img/index_right.png" alt="">
            </div> -->
            <real-energy />
          </div>
          <div class="vital-energy mb-10">
            <div class="flex vital-energy-title font-weight">
              <img class="mr-15" src="@/assets/img/index_left.png" alt="">
              <span>踩踏数</span>
              <img class="ml-15" src="@/assets/img/index_right.png" alt="">
            </div>
          </div>
          <div class="vital-energy">
            <div class="flex vital-energy-title font-weight">
              <img class="mr-15" src="@/assets/img/index_left.png" alt="">
              <span>今日空气质量状况</span>
              <img class="ml-15" src="@/assets/img/index_right.png" alt="">
            </div>
          </div>
        </el-col>
        <el-col id="" :span="10" class="mr-15">
          <div id="middle" class="dashboard-middle">
            <div class="vital-energy-bigtitle font-weight">
              <img class="mr-15" src="@/assets/img/index_left.png" alt="">
              <span>能耗分布及占比</span>
              <img class="ml-15" src="@/assets/img/index_right.png" alt="">
            </div>
          </div>
        </el-col>
        <el-col :span="7" class="dashboard-right" :style="{ '--height': height }">
          <div class="brick_count mb-10">
            <!-- <div class="flex vital-energy-title font-weight">
              <img class="mr-15" src="@/assets/img/index_left.png" alt="">
              <span>发电地砖总数</span>
              <img class="ml-15" src="@/assets/img/index_right.png" alt="">
            </div> -->
            <real-energy />
          </div>
          <div class="vital-energy mb-10">
            <div class="flex vital-energy-title font-weight">
              <img class="mr-15" src="@/assets/img/index_left.png" alt="">
              <span>踩踏数</span>
              <img class="ml-15" src="@/assets/img/index_right.png" alt="">
            </div>
          </div>
          <div class="vital-energy">
            <div class="flex vital-energy-title font-weight">
              <img class="mr-15" src="@/assets/img/index_left.png" alt="">
              <span>今日空气质量状况</span>
              <img class="ml-15" src="@/assets/img/index_right.png" alt="">
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import { RealEnergy, EarlyAlarm, AlarmInfo } from './components'
import { fetchVitalEnergy, fetchEnergyStatistics, fetchEnergyDistribution } from '@/api/dashboard'

export default {
  name: 'Dashboard',
  components: {
    RealEnergy,
    EarlyAlarm,
    AlarmInfo
    // BridgeEnergy,
    // TrackEnergy,
    // AgvEnergy,
    // BoxEnergy
  },
  data() {
    return {
      height: 0,
      vitalEnergy: undefined,
      energyDistribution: undefined,
      vitalCurrent: 'B',
      distributionCurrent: '装卸生产',
      energyStatistics: {
        NowBox: undefined,
        NowEnergy: undefined,
        NowType: undefined
      },
      distributionData: undefined,
      showData: []
    }
  },
  mounted() {
    const that = this
    that.height = document.getElementById('middle').clientHeight + 'px'
    window.addEventListener('resize', () => {
      that.height = document.getElementById('middle').clientHeight + 'px'
    })
    that.vitalEnergy = echarts.init(document.getElementById('vitalEnergy'))
    that.energyDistribution = echarts.init(document.getElementById('energyDistribution'))
    that.fetchVitalEnergy()
  },
  created() {
    this.fetchEnergyStatistics()
    this.fetchEnergyDistribution()
  },
  methods: {
    changeData(data) {
      this.distributionCurrent = data
      this.showData = this.distributionData[this.distributionCurrent]
      this.fetchEnergyDistribution()
    },
    fetchEnergyDistribution() {
      fetchEnergyDistribution().then((res) => {
        this.transformData(res.data)
        this.distributionData = res.data
        this.showData = res.data[this.distributionCurrent]
        this.drawEnergyDistribution()
      })
    },
    transformData(data) {
      for (const i in data) {
        data[i].forEach((item) => {
          const keyMap = {
            R: 'value',
            TYPE: 'name'
          }
          for (var key in item) {
            var newKey = keyMap[key]
            if (newKey) {
              item[newKey] = item[key]
              delete item[key]
            }
          }
          switch (item.TYPE) {
            case 'AGV':
              item.name = 'AGV'
              break
            case 'ASC':
              item.name = '轨道吊'
              break
            case 'QC':
              item.name = '岸桥'
              break
            case 'DC':
              item.name = '堆场'
              break
            case 'ZXALL':
              item.name = '装卸生产'
              break
            case 'ICON':
              item.name = '冷箱'
              break
            case 'JF':
              item.name = '机房'
              break
            case 'FZSC':
              item.name = '辅助生产'
              break
            case 'OTHERFZ':
              item.name = '监控配电箱'
              break
            case 'LIVING':
              item.name = '办公生活用电'
              break
            case 'ST':
              item.name = '食堂'
              break
            case 'OTHERCS':
              item.name = '办公生活'
              break
            default:
              return this.width
          }
        })
      }
    },
    fetchEnergyStatistics() {
      fetchEnergyStatistics().then((res) => {
        this.energyStatistics = res.data
      })
    },
    fetchVitalEnergy() {
      fetchVitalEnergy({ machine: this.vitalCurrent }).then((res) => {
        res.data.forEach((item) => {
          switch (item.TYPE) {
            case 'ASC':
              item.name = '轨道吊'
              break
            case 'QC':
              item.name = '岸桥'
              break
            case 'ICON':
              item.name = '冷箱'
              break
            case 'AGV':
              item.name = 'AGV'
              break
            case 'DC':
              item.name = '堆场照明'
              break
            default:
              return res.data
          }
        })
        this.drawVitalEnergy(res.data)
      })
    },
    changeTab(key) {
      this.vitalCurrent = key
      this.fetchVitalEnergy()
    },
    drawEnergyDistribution() {
      console.log(this.showData)
      const option = {
        legend: {
          top: '0%',
          y: 'center',
          left: 'center',
          icon: 'rect',
          itemWidth: 15, // 设置图例宽度
          itemHeight: 5,
          // itemGap: 30,
          textStyle: {
            color: '#fff',
            fontSize: 16
          }
        },
        series: [
          {
            type: 'pie',
            label: {
              formatter: '{b}: {d}%',
              // formatter: function(params) {
              //   if (params.name === '轨道吊') {
              //     return params.name + '{three|' + '\n\n' + params.percent + '%' + ' }'
              //   } else if (params.name === '食堂' || params.name === '机房' || params.name === 'AGV') {
              //     return params.name + '{two|' + '\n\n' + params.percent + '%' + '}'
              //   } else if (params.name === '岸桥' || params.name === '冷箱' || params.name === '办公生活') {
              //     return params.name + '{one|' + '\n\n' + params.percent + '%' + '}'
              //   } else {
              //     return params.name + '{four|' + '\n\n' + params.percent + '%' + '}'
              //   }
              // },
              // rich: {
              //   one: {
              //     color: '#fead51',
              //     fontSize: 18,
              //     fontWeight: 'bold'
              //   },
              //   two: {
              //     fontSize: 18,
              //     fontWeight: 'bold',
              //     color: '#d15edd'
              //   },
              //   three: { color: '#18fdfe', fontSize: 18, fontWeight: 'bold' },
              //   four: { color: '#0091ff', fontSize: 18, fontWeight: 'bold' }
              // },
              color: '#18fdfe',
              align: 'left',
              fontSize: 18
            },
            labelLine: {
              // length2: 150
            },
            itemStyle: {
              borderRadius: 10,
              borderColor: 'transparent'
            },
            center: ['50%', '60%'],
            radius: ['30%', '50%'],
            // color: ['#d15edd', '#fead51', '#18fdfe', '#0091ff'],
            data: this.showData
          }
        ]
      }
      option && this.energyDistribution.setOption(option)
    },
    drawVitalEnergy(data) {
      const option = {
        grid: {
          top: '10%',
          left: '0%',
          right: '0%',
          bottom: '2%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: data.map((item) => item.TYPE),
          axisLabel: {
            show: true,
            textStyle: {
              color: '#23a3cb',
              fontSize: 12
            },
            formatter: (val) => {
              let txt = val
              if (data.map((item) => item.TYPE).length > 4) {
                if (val.length > 3 && val.length < 5) {
                  txt = val.substr(0, 2) + '\n' + val.substr(2, 2)
                } else if (val.length > 5 && val.length < 8) {
                  txt = val.substr(0, 2) + '\n' + val.substr(2, 2) + '\n' + val.substr(4, val.length)
                } else {
                  txt = val.substr(0, 4) + '\n' + '……'
                }
              } else {
                return txt
              }
              return txt
            }
          }
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: false
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: '#23a3cb'
            }
          }
        },
        series: [
          {
            data: data.map((item) => item.R),
            type: 'bar',
            barWidth: 20,
            itemStyle: {
              color: function(params) {
                var colorList = ['#fead51', '#18fdfe']
                return colorList[params.dataIndex % 2]
              }
            },
            label: {
              normal: {
                show: true,
                color: '#fff',
                position: 'top',
                fontSize: 14
              }
            }
          }
        ]
      }
      option && this.vitalEnergy.setOption(option)
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep .el-radio__label {
  color: #fff;
}
.dashboard-middle {
  // display: flex;
  padding-top: 5rem;
  // background-image: url('~@/assets/img/energy_distribution.png');
  background-image: url('~@/assets/img/vital_energy.png');
  background-size: 100% 100%;
  > ul:nth-child(4) {
    width: 100%;
    height: 20%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 5rem;
    li {
      width: 30%;
      border: 1px solid #1ad5fd;
      color: #fff;
      height: 70%;
      background-color: transparent;
      font-size: 2rem;
    }
  }
  > ul:nth-child(2) {
    display: flex;
    justify-content: space-between;
    width: 100%;
    height: 15%;
    padding: 0 3rem;
    color: #fff;
    li {
      height: 100%;
      div {
        display: flex;
        align-items: center;
        justify-content: center;
      }
      > div:nth-child(1) {
        height: 50%;
        border: 1px solid #0091ff;
        color: #0091ff;
        font-size: 2.2rem;
      }
      > div:nth-child(2) {
        height: 50%;
        background-color: #0091ff;
        color: #fff;
        font-size: 1.6rem;
      }
    }
  }
}
::v-deep .switch-button {
  position: absolute;
  top: 5%;
  right: 2%;
  color: #fff;
  font-size: 1.4rem;
  span {
    display: inline-block;
    width: 5.9rem;
    height: 2.5rem;
    line-height: 2.5rem;
    background-image: url('~@/assets/img/index_select.png');
    background-size: 100% 100%;
  }
}
.dashboard-container {
  // height: 955px;
  height: 100%;
  // margin: 0 auto;
  .unit {
    position: absolute;
    color: #fff;
    top: 20px;
    right: 40px;
    font-size: 16px;
  }
  .vital-energy {
    position: relative;
    display: flex;
    height: calc(40% - 15px) !important;
    padding-top: 5rem;
    background-image: url('~@/assets/img/vital_energy.png');
    background-size: 100% 100%;
    ul {
      display: flex;
      flex-direction: column;
      justify-content: space-around;
      width: 45%;
      padding: 0 1rem;
      font-size: 1.2rem;
      li {
        width: 100%;
        height: 30%;
        margin-bottom: 1rem;
        div {
          display: flex;
          align-items: center;
          justify-content: center;
        }
      }
      li:nth-child(1) {
        > div:nth-child(1) {
          height: 55%;
          border: 1px solid #23a3cb;
          color: #23a3cb;
          font-size: 2rem;
        }
        > div:nth-child(2) {
          height: 45%;
          background-color: #23a3cb;
          color: #fff;
        }
      }
      li:nth-child(2) {
        > div:nth-child(1) {
          height: 55%;
          border: 1px solid #2caa75;
          color: #2caa75;
          font-size: 2rem;
        }
        > div:nth-child(2) {
          height: 45%;
          background-color: #2caa75;
          color: #fff;
        }
      }
      li:nth-child(3) {
        > div:nth-child(1) {
          height: 55%;
          border: 1px solid #ea672c;
          color: #ea672c;
          font-size: 2rem;
        }
        > div:nth-child(2) {
          height: 45%;
          background-color: #ea672c;
          color: #fff;
        }
      }
    }
  }
  #energyDistribution {
    width: 100%;
    height: 55%;
  }
  #vitalEnergy {
    width: 55%;
    height: 100%;
  }
  .vital-energy-title {
    position: absolute;
    top: 0;
    width: 55%;
    height: 12%;
    color: #fff;
    background-image: url('~@/assets/img/index_title.png');
    background-size: 100% 100%;
    font-size: 15px;
  }
  ::v-deep .bottom-title,
  ::v-deep .bottom-titletwo,
  ::v-deep .bottom-titlethree,
  ::v-deep .bottom-titlefour {
    position: absolute;
    top: -3.2rem;
    left: 0.12rem;
    width: 66.8%;
    height: 15%;
    color: #fff;
    background-image: url('~@/assets/img/index_title.png');
    background-size: 100% 100%;
    font-size: 15px;
  }

  .vital-energy-bigtitle {
    position: absolute;
    top: 0;
    width: 55%;
    height: 12%;
    color: #fff;
    background-image: url('~@/assets/img/index_title.png');
    background-size: 100% 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
  }
  .real-energy-title {
    width: 56%;
    height: 12%;
    box-shadow: #1f3c5c 0px 0px 18px inset;
    background-color: #040d26;
    color: #fff;
    font-size: 1.8rem;
    text-align: center;
  }
  .dashboard-middle {
    position: relative;
    height: 60%;
    width: 100%
  }
  .dashboard-right {
    // overflow: hidden;
  }
  .dashboard-left > div,
  .dashboard-right > div {
    height: calc(calc(var(--height) - 15px) / 2);
    // height: calc(calc(100% - 15px) / 2);
  }
  .brick_count {
  position: relative;
  height: calc(25% - 15px) !important;
  display: flex;
  padding-top: 5rem;
  background-image: url('~@/assets/img/vital_energy.png');
  background-size: 100% 100%;
}
  .el-row {
    // overflow: hidden;
  }
  .index-bottom {
    display: flex;
    padding-top: 5rem;
    background-image: url('~@/assets/img/index_bottom.png');
    background-size: 100% 100%;
  }
  ::v-deep .bottom-box {
    position: relative;
    width: 25%;
    height: 100%;
  }
  .el-row:nth-child(1) {
    width: 100%;
    height: 98%;
  }
  // .el-row:nth-child(2) {
  //   width: 100%;
  //   height: 33%;
  // }
}
</style>
