<template>
  <div>

  </div>
</template>

<script>

export default {
  name: 'RealEnergy',
  data() {
    return {
      realEnergy: undefined
    }
  },
  mounted() {
  },
  created() {},
  methods: {

  }
}
</script>

<style lang="scss" scoped>

</style>
