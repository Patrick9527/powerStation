<template>
  <div>
    <div class="box-container mt-10 pl-30 pr-30">
      <div class="box-title flex font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="" />
        <span>能源回馈</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="" />
      </div>
      <div class="text-center electron-title">2021年QQCTN月度用电汇总表 (KWH)</div>
      <el-row class="pl-30 pr-30 mt-30" type="flex" justify="center">
        <el-date-picker
          v-model="query.startTime"
          :format="format"
          :value-format="valueFormat"
          :picker-options="timeChange"
          class="mr-35"
          type="month"
          placeholder="选择月份"
        />
        <el-date-picker
          v-model="query.endTime"
          :format="format"
          :value-format="valueFormat"
          :picker-options="timeChange"
          class="mr-35"
          type="month"
          placeholder="选择月份"
        />
        <span class="select-row-search mr-20" @click="download">导出表格</span>
        <span class="select-row-search" @click="fetchFeedBack">查询</span>
      </el-row>
      <el-row class="mt-30" type="flex" justify="center">
        <div class="flex-between">
          <el-radio-group v-model="query.cycle">
            <el-radio label="year">年</el-radio>
            <el-radio label="month">月</el-radio>
          </el-radio-group>
        </div>
      </el-row>
      <div
        v-loading="load"
        class="mt-30 table-row"
        element-loading-text="拼命加载中"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(3, 10, 33, 0.8)"
      >
        <div v-if="list.length !== 0">
          <ul class="feedback-table-header">
            <li />
            <li>ASC</li>
            <li>STS</li>
            <li>总(ASC+STS)</li>
            <li>回馈</li>
            <li>上报总</li>
            <li>回馈系数</li>
          </ul>
          <ul v-for="(item, index) in list" :key="index" class="feedback-table-content">
            <li class="feedback-table-content-seperate">
              <span>{{ item.TIME }}</span>
              <span>回馈后</span>
            </li>
            <li class="feedback-table-content-seperate">
              <span>{{ item.ASC }}</span>
              <span>{{ item.ASC_WITHOUT_FEEDBACK }}</span>
            </li>
            <li class="feedback-table-content-seperate">
              <span>{{ item.STS }}</span>
              <span>{{ item.STS_WITHOUT_FEEDBACK }}</span>
            </li>
            <li class="text-center">{{ item.SUM }}</li>
            <li class="text-center">{{ item.SUM_FEEDBACK }}</li>
            <li class="text-center">{{ item.SUM_REPORTED }}</li>
            <li class="text-center">{{ item.RATE_FEEDBACK }}</li>
          </ul>
        </div>
        <div v-else class="empty-block">暂无数据</div>
      </div>
    </div>
  </div>
</template>

<script>
import { fetchFeedBack } from '@/api/feedback'
import moment from 'moment'

export default {
  name: 'Feedback',
  data() {
    return {
      load: false,
      timeChange: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        },
      },
      format: 'yyyy 年 MM 月',
      valueFormat: 'yyyy-MM',
      query: {
        startTime: moment().format('YYYY-MM'),
        endTime: moment().format('YYYY-MM'),
        cycle: 'month',
      },
      list: [],
    }
  },
  created() {
    this.load = true
    this.fetchFeedBack()
  },
  methods: {
    download() {
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = `/power/ajaxJsp/screen/ajaxEquipmentEnergyFeedback.jsp?postType=download&cycle=${this.query.cycle}&endTime=${this.query.endTime}&startTime=${this.query.startTime}`)
        : (url =
            process.env.VUE_APP_BASE_API +
            `ajaxJsp/screen/ajaxEquipmentEnergyFeedback.jsp?postType=download&cycle=${this.query.cycle}&endTime=${this.query.endTime}&startTime=${this.query.startTime}`)
      window.location.href = url
    },
    fetchFeedBack() {
      fetchFeedBack(this.query).then((res) => {
        this.list = res.data
        this.load = false
      })
    },
    arraySpanMethod1({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 3 || rowIndex === 4 || rowIndex === 5) {
        return [1, 2]
      }
    },
    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      if (row.name === '总(ASC+STS)' || row.name === '回馈' || row.name === '上报总') {
        if (columnIndex === 0) {
          return false
        } else {
          return [1, 2]
        }
      }
    },
  },
}
</script>

<style lang="scss" scoped>
::v-deep .el-radio {
  color: #fff;
}
.table-row::-webkit-scrollbar {
  height: 5px;
}
.empty-block {
  height: 300px;
  text-align: center;
  line-height: 300px;
  font-size: 2rem;
  border: 1px solid #3fcaff;
}
.table-row {
  padding-bottom: 10px;
  max-width: 100%;
  white-space: nowrap;
  width: 100%;
  overflow-x: auto;
  ul {
    display: inline-block;
  }
}
.table-row::-webkit-scrollbar-track {
  background: #353f55;
}
.table-row::-webkit-scrollbar-thumb {
  background: #1f5ea4;
}
.table-row::-webkit-scrollbar-corner {
  background: #179a16;
}
.feedback-table-header {
  width: 12%;
  li {
    height: 50px;
    line-height: 30px;
    padding: 10px 30px;
    width: 100%;
    font-size: 1.6rem;
    text-align: left;
    border: 1px solid #3fcaff;
    border-bottom: none;
  }
  li:last-child {
    border-bottom: 1px solid #3fcaff;
  }
}
.feedback-table-content {
  width: 20%;
  .feedback-table-content-seperate {
    padding: 0px;
    line-height: 50px;
    span {
      width: 50%;
      height: 100%;
      display: inline-block;
      text-align: center;
    }
    > span:nth-child(1) {
      border-right: 1px solid #3fcaff;
    }
  }
  li {
    height: 50px;
    line-height: 30px;
    padding: 10px 30px;
    width: 100%;
    font-size: 1.6rem;
    text-align: left;
    border: 1px solid #3fcaff;
    border-bottom: none;
    border-left: none;
  }
  li:last-child {
    border-bottom: 1px solid #3fcaff;
  }
}
@import '~@/styles/cost/index.scss';
</style>
