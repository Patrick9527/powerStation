<template>
  <div style="height: 100%; width: 100%" class="mt-50">
    <div class="energy-comparison">
      <el-select v-if="$route.name === 'ZHSC' || $route.name === 'AD'" v-model="query.startTime" style="width: 15%" class="mr-40" placeholder="请选择">
        <el-option v-for="item in years" :key="item" :label="item" :value="item" />
      </el-select>
      <el-select v-else v-model="query.year" style="width: 15%" class="mr-40" placeholder="请选择">
        <el-option v-for="item in years" :key="item" :label="item" :value="item" />
      </el-select>
      <el-select v-if="$route.name === 'ZHSC' || $route.name === 'AD'" v-model="query.endTime" style="width: 15%" class="mr-40" placeholder="请选择">
        <el-option v-for="item in startYears" :key="item" :label="item" :value="item" />
      </el-select>
      <div class="energy-comparison-button mr-50" @click="comparison">
        {{ $route.meta.title.includes('辅助生产电耗') ? '能耗对比' : '单箱能耗对比' }}
      </div>
      <span class="mr-20 last" />
      <span class="mr-50">{{ $route.name === 'ZHSC' || $route.name === 'AD' ? query.startTime : '当前' }}</span>
      <span class="mr-20 current" />
      <span>{{ $route.name === 'ZHSC' || $route.name === 'AD' ? query.endTime : query.year }}</span>
    </div>
    <div
      id="barChart"
      ref="barChart"
      v-loading="load"
      v-on-echart-resize
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(3, 10, 33, 0.8)"
    />
  </div>
</template>
<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import { generateArray } from '@/utils/utils'
import { fetchBarChart } from '@/api/energy'

export default {
  name: 'EnergyBarChart',
  data() {
    return {
      load: false,
      years: [],
      endYears: [],
      bar: undefined,
      query: {
        startTime: new Date().getFullYear() - 1,
        endTime: new Date().getFullYear(),
        machine: this.$route.name,
        year: new Date().getFullYear() - 1
      }
    }
  },
  mounted() {
    this.bar = echarts.init(document.getElementById('barChart'))
    this.comparison()
  },
  created() {
    if (this.$route.name === 'ZHSC' || this.$route.name === 'AD') {
      this.years = generateArray(2021, new Date().getFullYear() - 1)
      this.startYears = generateArray(2021, new Date().getFullYear())
    } else {
      this.years = generateArray(2017, new Date().getFullYear() - 1)
    }
  },
  methods: {
    comparison() {
      fetchBarChart(this.query).then((res) => {
        this.load = true
        this.drawBar(res.data)
        if (res.data.lastYear && res.data.lastYear.length !== 0 && res.data.nowYear && res.data.nowYear.length !== 0) {
          this.drawBar(res.data)
        } else {
          this.load = false
        }
      })
    },
    drawBar(data) {
      const option = {
        grid: {
          left: '0%',
          right: '0%',
          top: '10%',
          bottom: '5%',
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        xAxis: {
          show: true,
          type: 'category',
          splitLine: {
            show: false
          },
          // data.lastYear.map(item => item.TIME) ||
          data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
          axisLabel: {
            show: true,
            textStyle: {
              color: '#fff'
            }
          }
        },
        yAxis: {
          axisLine: {
            show: true
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: '#fff'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed'
            }
          }
        },
        series: [
          {
            name: this.query.year,
            type: 'bar',
            color: '#0016bb',
            data: data.lastYear.map((item) => item.KWH) || []
          },
          {
            name: new Date().getFullYear(),
            type: 'bar',
            color: '#187fb2',
            data: data.nowYear.map((item) => item.KWH) || []
          }
        ]
      }
      this.bar = echarts.init(document.getElementById('barChart'))
      option && this.bar.setOption(option)
      this.load = false
    }
  }
}
</script>
<style lang="scss" scoped>
#barChart {
  height: 85%;
  width: 100%;
}
::v-deep .el-input__inner {
  background-color: #1b2742;
  border: 1px solid #7c818f;
  border-radius: 0;
  color: #a4a7b1;
}
.energy-comparison {
  display: flex;
  align-items: center;
  .energy-comparison-button {
    width: 165px;
    height: 40px;
    background-color: #3399ff;
    line-height: 40px;
    text-align: center;
    font-size: 1.8rem;
    cursor: pointer;
  }
  span {
    font-size: 2rem;
  }
  .current,
  .last {
    display: inline-block;
    height: 20px;
    width: 20px;
  }
  .current {
    background-color: #187fb2;
  }
  .last {
    background-color: #0016bb;
  }
}
</style>
