<template>
  <el-dialog :close-on-click-modal="false" width="30%" title="" :visible="visible" @close="cancel">
    <div slot="title" class="dialog-title">
      <span>导入表格</span>
    </div>
    <div class="mt-10 mb-10">
      第一步:
      <a href="" target="__blank" class="ml-20 mr-20">点击下载</a>
      模板范例
    </div>
    <div class="mt-30">
      第二步：
      <el-upload
        :action="uploadUrl"
        :show-file-list="false"
        accept=".xlsx, .xls"
        style="display: inline-block"
        :multiple="false"
        :on-success="upload"
      >
        <el-button class="select-row-search" type="primary">上传表格</el-button>
      </el-upload>
    </div>
  </el-dialog>
</template>
<script>
export default {
  name: 'ImportModal',
  props: {
    visible: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      uploadUrl:
        process.env.NODE_ENV === 'development'
          ? '/power/ajaxJsp/maintain/ajaxEnergyMonthCostLoadExcel.jsp'
          : process.env.VUE_APP_BASE_API + 'ajaxJsp/maintain/ajaxEnergyMonthCostLoadExcel.jsp',
    }
  },
  created() {},
  methods: {
    upload(response) {
      console.log(response)
      if (response.success === 'true') {
        this.$message({
          message: response.tip,
          type: 'success',
        })
        this.$emit('close', 'refresh')
      }
    },
    cancel() {
      this.$emit('close')
    },
  },
}
</script>
<style lang="scss" scoped>
::v-deep .el-dialog {
  border: 1px solid #3399ff;
  color: #fff;
  background: none;
  .el-dialog__body {
    color: #fff;
    background-color: rgba(0, 1, 4, 0.5);
  }
  .el-dialog__header {
    border-bottom: 1px solid #3399ff;
    background-color: rgba(26, 78, 130, 0.9);
  }
  .el-form-item__label {
    color: #efefef;
  }
  .el-input__inner {
    background-color: rgba(26, 28, 32, 0.7);
    border: 1px solid #7c818f;
    border-radius: 0;
    color: #a4a7b1;
  }
  .el-button {
    border-radius: 0;
  }
  .dialog-title {
    color: #fff;
    font-size: 1.6rem;
    > span:nth-child(2) {
      color: red;
    }
  }
}
</style>
