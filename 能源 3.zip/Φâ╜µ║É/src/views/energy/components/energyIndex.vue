<template>
  <el-row class="pl-30">
    <el-row type="flex" justify="space-between">
      <el-col :span="17" class="pr-25 flex-column">
        <div class="select-row mb-35">
          <span>能源类型:</span>
          <div class="flex-between">
            <el-select
              ref="select"
              v-model="query.energyType"
              multiple
              filterable
              style="width: 75%"
              class="mr-40"
              placeholder="请选择能源类型"
            >
              <el-option
                v-for="(item, index) in energyType"
                :key="index"
                :disabled="item.disabled"
                :label="item.LIBTITLE"
                :value="item.LIBKEY"
              />
            </el-select>
            <!-- <el-select v-model="query.unit" style="width: 15%" placeholder="单吨 / 单箱">
              <el-option v-for="item in switchArray" :key="item.value" :label="item.label" :value="item.value" />
            </el-select> -->
          </div>
        </div>
        <div class="mb-35 select-row">
          <span class="text-hidden" />
          <div class="flex-between">
            <el-date-picker
              v-model="query.startTime"
              style="width: 45%"
              type="datetime"
              class="mr-20"
              :format="format"
              :value-format="valueFormat"
              :picker-options="timeChange"
              placeholder="选择日期时间"
            />
            <el-date-picker
              v-model="query.endTime"
              :format="format"
              :value-format="valueFormat"
              style="width: 45%"
              :picker-options="timeChange"
              type="datetime"
              placeholder="选择日期时间"
            />
          </div>
        </div>
        <div class="select-row">
          <span class="text-hidden" />
          <div class="flex-between">
            <div class="select-row-search" @click="fetchBridgeLine">查询</div>
            <div class="operate-btn-row">
              <!-- <span class="mr-20" @click="showTable">查看折线图表格</span> -->
              <span @click="showReprot">报表查询</span>
            </div>
          </div>
        </div>
      </el-col>
      <el-col :span="7" style="height: 100%">
        <div class="whole-energy" style="height: 100%; padding-bottom: 10px">
          <span class="mt-10 mb-10"> {{ title }} </span>
          <span v-for="(item, idx) of sum" :key="idx">
            {{ item.NAME }}
            <span class="ml-10 mr-10">
              {{ item.TOTAL || '暂无' }}
            </span>
            <span v-show="item.NAME === '电能'">万 kW·h</span>
            <span v-show="item.NAME === '水'">吨</span>
            <span v-show="item.NAME === '氢气' || item.NAME === 'LNG'">kg</span>
            <span v-show="item.NAME === '汽油' || item.NAME === '柴油'">L</span>
          </span>
        </div>
      </el-col>
    </el-row>
    <el-col :span="17">
      <el-row style="height: 58%">
        <div
          id="equipmentLine"
          ref="equipmentLine"
          v-loading="load"
          v-on-echart-resize
          style="height: 50rem"
          class="pt-20"
          element-loading-text="拼命加载中"
          element-loading-spinner="el-icon-loading"
          element-loading-background="rgba(3, 10, 33, 0.8)"
        />
      </el-row>
    </el-col>
    <el-col :span="7">
      <div id="pieChart" ref="pieChart" v-on-echart-resize class="mt-50" />
    </el-col>
    <list-table
      type="能耗"
      :sum="sums"
      :table-visible="tableVisible"
      :total="total"
      :table-data="tableData"
      :column="column"
      @download="download"
      @close="close"
    />
  </el-row>
</template>

<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import { deepCopy } from '@/utils/utils'
import moment from 'moment'
import { fetchAllEnergy, fetchBridgeLine, fetchPieData } from '@/api/energy'
import ListTable from '@/components/ListTable.vue'
import { fetchEnergyTypeSelect } from '@/api/energy'
import { storage, findTitle } from '@/utils/utils'

export default {
  components: { ListTable },
  props: {
    showType: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      title: '',
      column: [],
      total: 0,
      sums: ['合计', '', 0],
      tableData: [],
      tableVisible: false,
      load: false,
      energyType: [],
      line: undefined,
      pie: undefined,
      switchArray: [
        { value: 'D', label: '单吨' },
        { value: 'B', label: '单箱' },
        { value: 'A', label: '全部' },
      ],
      sum: {},
      format: 'yyyy 年 MM 月 dd 日 HH 时',
      valueFormat: 'yyyy-MM-dd HH',
      timeChange: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        },
      },
      query: {
        type: this.$route.name,
        postType: 'query',
        machine: this.$route.name,
        startTime:
          moment()
            .year(moment().year() - 1)
            .endOf('year')
            .format('YYYY-MM') +
          '-' +
          '01' +
          ' ' +
          '00',
        endTime:
          moment()
            .year(moment().year() - 1)
            .endOf('year')
            .format('YYYY-MM') +
          '-' +
          '31' +
          ' ' +
          +'23',
        unit: 'A',
        energyType: [],
      },
    }
  },
  mounted() {
    this.title = findTitle(storage.get('energyMenu'), this.$route.path)
    this.line = echarts.init(document.getElementById('equipmentLine'))
    this.pie = echarts.init(document.getElementById('pieChart'))
  },
  created() {
    this.fetchEnergyTypeSelect()
  },
  destroyed() {
    if (this.line) this.line.dispose()
  },
  methods: {
    fetchEnergyTypeSelect() {
      fetchEnergyTypeSelect().then((res) => {
        this.energyType = res.data.items
        this.energyType.forEach((i) => {
          i.disabled = false
          if (this.$route.name === 'QTNYXH') {
            if (i.LIBTITLE === '电能') {
              i.disabled = true
            }
          }
          if (!i.disabled) this.query.energyType.push(i.LIBKEY)
          // if (this.$route.name === 'SCZHNH') {
          //   if (i.LIBTITLE === 'LNG' || i.LIBTITLE === '氢气') {
          //     i.disabled = true
          //   }
          // }
        })
        this.fetchBridgeLine()
      })
    },
    download() {
      const query = this.transformParameters()
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = `/power/ajaxJsp/screen/ajaxEquipmentEnergy.jsp?postType=download&startTime=${
            query.startTime
          }&energyType=${query.energyType.join(',')}&endTime=${query.endTime}&feedback=${query.feedback}&machine=${
            query.machine
          }&type=${query.type}&unit=${query.unit}`)
        : (url =
            process.env.VUE_APP_BASE_API +
            `ajaxJsp/screen/ajaxEquipmentEnergy.jsp?postType=download&startTime=${
              query.startTime
            }&energyType=${query.energyType.join(',')}&endTime=${query.endTime}&feedback=${query.feedback}&machine=${
              query.machine
            }&type=${query.type}&unit=${query.unit}`)
      window.location.href = url
    },
    close() {
      this.tableVisible = false
    },
    showTable() {
      this.tableVisible = true
    },
    showReprot() {
      this.$emit('showReprotDialog', true)
    },
    transformParameters() {
      const query = deepCopy(this.query)
      if (!query.startTime) query.startTime = moment().format('YYYY-MM') + '-' + '01'
      if (!query.endTime) query.endTime = moment().format('YYYY-MM-DD')
      console.log(query.energyType.findIndex((i) => i === 'Q'))
      if (query.energyType.findIndex((i) => i === 'Q') && this.$route.name === 'SCZHNH') {
        query.energyType.splice(
          query.energyType.findIndex((i) => i === 'Q'),
          1
        )
      }
      if (query.energyType.findIndex((i) => i === 'L') && this.$route.name === 'SCZHNH') {
        query.energyType.splice(
          query.energyType.findIndex((i) => i === 'L'),
          1
        )
      }
      if (query.energyType) query.energyType = query.energyType.join(',')
      return query
    },
    fetchBridgeLine() {
      this.load = true
      const query = this.transformParameters()
      fetchAllEnergy(query).then((res) => {
        this.sum = res.data
      })
      fetchPieData(query).then((res) => {
        this.drawPie(res.data)
      })
      fetchBridgeLine(query).then((res) => {
        if (res.data.length === 0) {
          this.$message({
            message: '暂无数据',
            type: 'warning',
          })
          this.load = false
        } else {
          this.tableData = res.data
          this.transformData(res.data)
        }
      })
    },
    transformData(data) {
      const series = []
      let time = []
      data.forEach((item) => {
        time = item.value.map((ele) => ele.TIME)
        series.push({
          name: item.name,
          type: 'line',
          data: item.value.map((ele) => ele.TOTAL),
        })
      })
      data.forEach((i) => {
        i.value.forEach((x) => {
          x.name = i.name
        })
      })
      // const arr = [].concat(...data.map(item => item.value))
      const newArr = []
      for (const i in data) {
        newArr.push({
          name: data[i].name,
        })
      }
      data.forEach((x) => {
        for (let i = 0; i < x.value.length; i++) {
          const obj = x.value[i]
          const newKey = x.value[i].TIME
          obj[newKey] = obj.TOTAL
          for (const y of newArr) {
            if (y.name === obj.name) {
              y[newKey] = obj.TOTAL
            }
          }
        }
      })
      this.tableData = newArr
      const scope = data[0].value.map((x) => x.TIME)
      const column = [{ prop: 'name', label: '设备编码', fixed: true }]
      // 把时间筛选出来 为column赋值
      for (const i of scope) {
        column.push({
          prop: i,
          label: i,
        })
      }
      this.column = column
      // if (this.sums[2] !== 0) this.sums = ['合计', '', 0]
      // this.tableData.forEach(i => {
      //   this.sums[2] += Number(i.TOTAL)
      // })
      // this.sums[2] = Math.floor(this.sums[2] * 100) / 100
      this.total = this.tableData.length
      if (this.line) this.line.clear()
      this.drawLine(series, time)
    },
    drawLine(series, time) {
      console.log(series)
      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: '#6a7985',
            },
          },
          formatter: (params) => {
            let str = ''
            params.forEach((i, index) => {
              if (index !== 0 && (index + 1) % 3 === 0) {
                str = str + i.marker + i.seriesName + ' ' + i.value + '<br>'
              } else {
                str = str + i.marker + `<span style='margin-right:10px;'>${i.seriesName} ${i.value}</span>`
              }
            })
            return str
          },
        },
        legend: {
          type: 'scroll',
          textStyle: {
            color: '#fff',
            fontSize: 16,
          },
        },
        grid: {
          top: '15%',
          left: '0%',
          right: '3%',
          bottom: '0%',
          containLabel: true,
        },
        xAxis: [
          {
            type: 'category',
            axisLabel: {
              show: true,
              textStyle: {
                color: '#fff',
              },
            },
            data: time,
          },
        ],
        yAxis: [
          {
            type: 'value',
            axisLabel: {
              show: true,
              textStyle: {
                color: '#17bae0',
              },
            },
          },
        ],
        series: series,
      }
      this.line = echarts.init(document.getElementById('equipmentLine'))
      option && this.line.setOption(option)
      this.load = false
    },
    drawPie(data) {
      const option = {
        tooltip: {
          trigger: 'item',
        },
        series: [
          {
            name: '能耗占比',
            type: 'pie',
            radius: '50%',
            label: {
              color: '#fff',
              fontSize: '15',
              formatter: function (params) {
                if (params.name === '当前查询设备KWH占比') {
                  return '当前查询设' + '\n\n' + '备KWH占比' + '{one|' + '\n\n' + params.value + '%' + ' }'
                } else {
                  return '其余查询设' + '\n\n' + '备KWH占比' + '{two|' + '\n\n' + params.value + '%' + ' }'
                }
              },
              rich: {
                one: {
                  color: '#3db5f0',
                  fontSize: 20,
                  fontWeight: 'bold',
                },
                two: {
                  fontSize: 20,
                  fontWeight: 'bold',
                  color: '#fead51',
                },
              },
              align: 'left',
            },
            labelLine: {
              length2: 20,
            },
            center: ['50%', '60%'],
            data: [
              { value: Number(data), name: '当前查询设备KWH占比', itemStyle: { color: '#3db5f0' } },
              { value: (100 - Number(data)).toFixed(2), name: '其余查询设备KWH占比', itemStyle: { color: '#fead51' } },
            ],
          },
        ],
      }
      this.pie = echarts.init(document.getElementById('pieChart'))
      option && this.pie.setOption(option)
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~@/styles/energy/searchBar.scss';
.operate-btn-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  span {
    width: auto;
    display: inline-block;
    padding-bottom: 10px;
    border-bottom: 1px solid #3091f3;
    color: #3091f3;
    cursor: pointer;
    font-size: 1.6rem;
  }
}
</style>
