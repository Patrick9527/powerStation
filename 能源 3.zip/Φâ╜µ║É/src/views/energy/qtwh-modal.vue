<template>
  <el-dialog :close-on-click-modal="false" width="30%" title="提示" :visible="visible" @close="cancel">
    <div slot="title" class="dialog-title">
      <span> {{ title }}分类( </span>
      <span> * </span>
      <span>表示必填或必选)</span>
    </div>
    <el-form ref="form" :model="form" label-width="auto">
      <el-form-item label="能源类别" prop="ENERGYTYPE" :rules="[{ required: true, message: '能源类别不能为空' }]">
        <el-select v-model="form.ENERGYTYPE" placeholder="请选择能源类别" style="width: 100%">
          <el-option
            v-for="(item, index) in energyType"
            :key="index"
            :disabled="item.disabled"
            :label="item.LIBTITLE"
            :value="item.LIBKEY"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="过程环节" prop="PROCESS">
        <el-select v-model="form.PROCESS" placeholder="请选择过程环节" style="width: 100%">
          <el-option v-for="(item, index) in processType" :key="index" :label="item.LIBTITLE" :value="item.LIBKEY" />
        </el-select>
      </el-form-item>
      <el-form-item label="类型" prop="TYPE">
        <el-select v-model="form.TYPE" placeholder="请选择类型" style="width: 100%">
          <el-option v-for="(item, index) in type" :key="index" :label="item.LIBTITLE" :value="item.LIBKEY" />
        </el-select>
      </el-form-item>
      <el-form-item label="当月用电量" prop="EQ" :rules="[{ required: true, message: '用电量不能为空' }]">
        <el-input v-model="form.EQ" />
      </el-form-item>
      <el-form-item label="总金额" prop="EC" :rules="[{ required: true, message: '总金额不能为空' }]">
        <el-input v-model="form.EC" type="number" />
      </el-form-item>
      <!-- <el-form-item label="电费" prop="EC" :rules="[{ required: true, message: '电费不能为空' }]">
        <el-input v-model="form.EC" />
      </el-form-item> -->
      <el-form-item label="年份" prop="year" :rules="[{ required: true, message: '年份不能为空' }]">
        <el-date-picker
          v-model="form.year"
          type="year"
          placeholder="选择年"
          format="yyyy 年"
          value-format="yyyy"
          style="width: 100%"
          class="mr-20"
          :picker-options="startPickerOptions"
          @change="fetchMonth"
        />
      </el-form-item>
      <el-form-item label="月份" prop="monthId" :rules="[{ required: true, message: '月份不能为空' }]">
        <el-select v-model="form.monthId" placeholder="请选择分项名称" style="width: 100%">
          <el-option v-for="(item, index) in month" :key="item.ID" :label="item.TITLE" :value="item.ID">
            <span>
              {{ index + 1 }} 月 ( {{ item.FROMDATE.substr(0, 10) }} 0时 ~ {{ item.TODATE.substr(0, 10) }} 24时)
            </span>
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button style="width: 200px" type="primary" @click="onSubmit">提交</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>
<script>
import { fetchItems, fetchMonth } from '@/api/fee'
import { updateOtherEnergyCharge, fetchEnergyTypeSelect, fetchEnergyProcessSelect, fetchTypeSelect } from '@/api/energy'
export default {
  name: 'AlarmModal',
  props: {
    visible: {
      type: Boolean,
      default: false,
    },
    select: {
      type: Object,
      default() {
        return {}
      },
    },
  },
  data() {
    return {
      energyType: [],
      processType: [],
      type: [],
      title: '新增',
      startPickerOptions: {
        disabledDate(time) {
          return Number(time.getFullYear()) < 2017 || Number(time.getFullYear()) > Number(new Date().getFullYear())
        },
      },
      form: {
        ENERGYTYPE: '',
        year: '2021',
        ITEMID: '',
        PROCESS: '',
        EQ: '',
        EC: '',
        TYPE: '',
        monthId: '',
        FROMDATE: '',
        TODATE: '',
      },
      month: [],
      option: [],
    }
  },
  watch: {
    select(val) {
      val.ID ? (this.title = '编辑') : (this.title = '新增')
      if (val.ID) {
        Object.assign(this.form, val)
        this.form.year = val.TITLE.substr(0, 4)
        this.fetchMonth()
      } else {
        this.form = {
          ENERGYTYPE: '',
          year: '2021',
          ITEMID: '',
          PROCESS: '',
          EQ: '',
          EC: '',
          TYPE: '',
          monthId: '',
          FROMDATE: '',
          TODATE: '',
        }
      }
    },
  },
  created() {
    this.fetchItems()
    this.fetchMonth()
    this.fetchEnergyTypeSelect()
    this.fetchTypeSelect()
    this.fetchEnergyProcessSelect()
  },
  methods: {
    fetchTypeSelect() {
      fetchTypeSelect().then((res) => {
        this.type = res.data.items
      })
    },
    fetchEnergyProcessSelect() {
      fetchEnergyProcessSelect().then((res) => {
        this.processType = res.data.items
      })
    },
    fetchEnergyTypeSelect() {
      fetchEnergyTypeSelect().then((res) => {
        res.data.items.forEach((i) => {
          i.disabled = false
          if (i.LIBTITLE.includes('电能')) {
            i.disabled = true
          }
        })
        this.energyType = res.data.items
      })
    },
    fetchMonth() {
      fetchMonth({ year: this.form.year || '2021' }).then((res) => {
        this.month = res.data
      })
    },
    fetchItems() {
      fetchItems().then((res) => {
        this.option = res.data
      })
    },
    cancel(val) {
      Object.assign(this.form, {
        year: '2021',
        ITEMID: '',
        EQ: '',
        EC: '',
        ID: '',
        MONTHID: '',
      })
      val ? this.$emit('close', val) : this.$emit('close')
    },
    onSubmit() {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          if (this.form.monthId) {
            this.form.FROMDATE = this.month.find((i) => i.ID === this.form.monthId).FROMDATE
            this.form.TODATE = this.month.find((i) => i.ID === this.form.monthId).TODATE
          }
          this.form.EQ = Number(this.form.EQ)
          this.form.EC = Number(this.form.EC)
          console.log(this.form)
          updateOtherEnergyCharge(this.form).then((res) => {
            res.code === '200' ? this.done(res.message, 'success') : this.done(res.message, 'error')
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    done(val, type) {
      this.$message({
        message: val,
        type: type,
      })
      type === 'success' ? this.cancel('refresh') : this.cancel()
    },
  },
}
</script>
<style lang="scss" scoped>
::v-deep .el-dialog {
  border: 1px solid #3399ff;
  color: #fff;
  background: none;
  .el-dialog__body {
    color: #fff;
    background-color: rgba(0, 1, 4, 0.5);
  }
  .el-dialog__header {
    border-bottom: 1px solid #3399ff;
    background-color: rgba(26, 78, 130, 0.9);
  }
  .el-form-item__label {
    color: #efefef;
  }
  .el-input__inner {
    background-color: rgba(26, 28, 32, 0.7);
    border: 1px solid #7c818f;
    border-radius: 0;
    color: #a4a7b1;
  }
  .el-button {
    border-radius: 0;
  }
  .dialog-title {
    color: #fff;
    font-size: 1.6rem;
    > span:nth-child(2) {
      color: red;
    }
  }
}
</style>
