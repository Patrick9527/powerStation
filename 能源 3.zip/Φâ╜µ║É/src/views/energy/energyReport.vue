<template>
  <el-dialog :visible="visible" fullscreen @close="close">
    <div slot="title" class="dialog-title">
      <span> 设备列表: </span>
      <el-select v-model="query.machine" style="width: 15%" placeholder="请选择" class="mr-40">
        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
      </el-select>
      <el-date-picker
        v-model="query.startTime"
        :picker-options="startPickerOptions"
        type="year"
        placeholder="选择年"
        format="yyyy 年"
        value-format="yyyy"
        class="mr-40"
      />
      <!-- <el-checkbox v-model="query.feedback"> 扣除回馈 </el-checkbox> -->
      <span class="ml-20 cursor-pointer search" @click="search()">查询</span>
    </div>
    <el-table
      v-el-table-infinite-scroll="load"
      v-loading="loading"
      height="400"
      element-loading-text="拼命加载中"
      element-loading-background="rgba(0,0,0,0)"
      show-summary
      :summary-method="getSummaries"
      :data="list"
      :row-style="getRowClass"
      :header-cell-style="getHeaderClass"
    >
      <el-table-column
        v-for="(item, index) in column"
        :key="index"
        :label="item.label"
        :prop="item.prop"
        :width="item.width"
        align="center"
      />
    </el-table>
    <el-row class="mt-20 text-center">
      <span class="ml-10 export" @click="download">一键导出</span>
    </el-row>
    <!-- <pagination :total="total" @refreshList="fetchEnergyReport" @download="download" /> -->
  </el-dialog>
</template>

<script>
// import pagination from '@/layout/components/pagination.vue'
import { fetchEnergyReport } from '@/api/energy'
import { deepCopy } from '@/utils/utils'
import elTableInfiniteScroll from 'el-table-infinite-scroll'

export default {
  name: 'EnergyReport',
  // components: { pagination },
  directives: {
    'el-table-infinite-scroll': elTableInfiniteScroll,
  },
  props: {
    visible: {
      type: Boolean,
      default() {
        return false
      },
    },
  },
  data() {
    return {
      total: 0,
      loading: false,
      startPickerOptions: {
        disabledDate(time) {
          return Number(time.getFullYear()) < 2017 || Number(time.getFullYear()) > Number(new Date().getFullYear())
        },
      },
      query: {
        // feedback: true,
        endTime: '',
        startTime: '',
        machine: '',
        pageNumber: 1,
      },
      options: [
        {
          value: 'QC',
          label: '岸桥',
        },
        {
          value: 'ASC',
          label: '轨道吊',
        },
        {
          value: 'AGV',
          label: 'AGV',
        },
        {
          value: 'BGSH',
          label: '辅助生产',
        },
        {
          value: 'QTNH',
          label: '附属生产',
        },
        {
          value: 'ZHSC',
          label: '装卸生产',
        },
      ],
      list: [],
      column: [
        { prop: 'EQNAME', label: '设备编码 kW·h', width: 200 },
        { prop: '2021-01', label: '1月' },
        { prop: '2021-02', label: '2月' },
        { prop: '2021-03', label: '3月' },
        { prop: '2021-04', label: '4月' },
        { prop: '2021-05', label: '5月' },
        { prop: '2021-06', label: '6月' },
        { prop: '2021-07', label: '7月' },
        { prop: '2021-08', label: '8月' },
        { prop: '2021-09', label: '9月' },
        { prop: '2021-10', label: '10月' },
        { prop: '2021-11', label: '11月' },
        { prop: '2021-12', label: '12月' },
        { prop: 'TOTAL', label: '合计' },
      ],
      year: new Date().getFullYear(),
      needInitialization: false,
    }
  },
  watch: {
    visible(val) {},
  },
  created() {
    this.transformData()
    this.fetchEnergyReport()
  },
  mounted() {},
  methods: {
    getSummaries(param) {
      const { columns, data } = param
      const sums = []
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = '合计'
          return
        }
        const values = data.map((item) => Number(item[column.property]))
        if (!values.every((value) => isNaN(value))) {
          sums[index] = values.reduce((prev, curr) => {
            const value = Number(curr)
            if (!isNaN(value)) {
              return Math.round(prev + curr)
            } else {
              return Math.round(prev)
            }
          }, 0)
          sums[index]
        }
      })
      return sums
    },
    load() {
      if (this.list.length < this.total && !this.needInitialization) {
        this.query.pageNumber++
        this.fetchEnergyReport()
      } else {
        return false
      }
    },
    search() {
      this.needInitialization = true
      if (this.list && this.list.length > 0) this.list = []
      this.fetchEnergyReport()
    },
    download() {
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = '/power/ajaxJsp/screen/ajaxEquipmentCompanyEnergyList.jsp?postType=download')
        : (url = process.env.VUE_APP_BASE_API + 'ajaxJsp/screen/ajaxEquipmentCompanyEnergyList.jsp?postType=download')
      window.location.href = url
    },
    fetchEnergyReport(val) {
      this.loading = true
      if (val) this.query.pageNumber = val
      const query = deepCopy(this.query)
      // query.feedback ? (query.feedback = 1) : (query.feedback = 0)
      fetchEnergyReport(query).then((res) => {
        this.transformData(query.startTime)
        res.data.items.forEach((i) => {
          this.list.push(i)
        })
        this.total = res.data.totalCount
        this.loading = false
        this.needInitialization = false
      })
    },
    transformData(val) {
      if (val) this.year = val
      this.column.forEach((x, i) => {
        if (i !== 0 && i !== this.column.length - 1) {
          Number(i) < 10 ? (x.prop = `${this.year}-0${i}`) : (x.prop = `${this.year}-${i}`)
        }
      })
    },
    getHeaderClass() {
      return {
        background: '#010306',
        color: '#fff',
      }
    },
    getRowClass({ row, column, rowIndex, columnIndex }) {
      if (rowIndex % 2 === 0) {
        return {
          background: 'rgba(25,25,25,.4)',
          color: '#fff',
        }
      } else {
        return {
          background: 'rgba(12,49,63,.4)',
          color: '#fff',
        }
      }
    },
    close() {
      this.$emit('close')
    },
  },
}
</script>

<style lang="scss" scoped>
@import '~@/styles/pagination.scss';

::v-deep .el-dialog {
  background: rgba(10, 19, 23, 0.8);
  color: #fff;
  padding: 50px 60px 45px 60px;
  .el-checkbox__label {
    color: #fff;
  }
  .el-table--enable-row-hover .el-table__body tr:hover > td {
    background-color: transparent !important;
  }
  .el-table::before {
    height: 0px;
  }
  /* 表格内背景颜色 */
  .el-table th,
  .el-table tr,
  .el-table,
  .el-table td {
    border: 0;
    background-color: transparent;
  }
  .el-table__footer-wrapper {
    background-color: rgba(39, 129, 174, 0.8);
    td {
      color: #fff;
    }
  }
  .el-checkbox__inner {
    border: 2px solid #407997;
    background-color: rgba(21, 61, 57, 0.7);
    border-radius: 0;
  }
  .el-table {
    color: #fff;
  }
  .el-table__header-wrapper {
    border: 1px solid #30a0d8;
  }
  .el-table td,
  .el-table th.is-leaf {
    border-bottom: none;
  }
}
::v-deep .el-dialog__headerbtn {
  font-size: 30px;
  border-radius: 50%;
  height: 40px;
  width: 40px;
  background-color: #5493f1;
  .el-dialog__close {
    color: #fff;
  }
}
.dialog-title {
  display: flex;
  align-items: center;
  > span:nth-child(1) {
    font-size: 2.6rem;
    margin-right: 15px;
  }
  .search {
    height: 40px;
    width: 120px;
    background-color: #3399ff;
    line-height: 40px;
    text-align: center;
    font-size: 1.6rem;
  }
}
</style>
