<template>
  <div>
    <div class="mt-10 box-container pl-30 pr-30">
      <div class="flex box-title font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="" />
        <span>其他能源维护</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="" />
      </div>
      <div class="search-bar">
        <el-date-picker
          v-model="year"
          type="year"
          placeholder="选择年"
          format="yyyy 年"
          value-format="yyyy"
          class="mr-20"
          :picker-options="startPickerOptions"
          @change="fetchMonth"
        />
        <el-select v-model="query.monthId" class="mr-20" placeholder="选择月份">
          <el-option v-for="(item, index) in month" :key="item.ID" :label="item.TITLE" :value="item.ID">
            <span>
              {{ index + 1 }} 月 ( {{ item.FROMDATE.substr(0, 10) }} 0时 ~ {{ item.TODATE.substr(0, 10) }} 24时)
            </span>
          </el-option>
        </el-select>
        <el-button type="primary" @click="fetchOtherEnergyCharge()"> 查询 </el-button>
        <el-button type="primary" @click="showImportModal = true"> 导入 </el-button>
      </div>
      <div class="create-button">
        <el-button type="primary" @click="create"> 新增 </el-button>
      </div>
      <div class="alarm-table">
        <el-table
          v-loading="load"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(0,0,0,0)"
          :data="list"
          :row-style="getRowClass"
          :header-cell-style="getHeaderClass"
        >
          <el-table-column
            v-for="(item, index) in column"
            :key="index"
            :label="item.label"
            :prop="item.prop"
            align="center"
          >
            <template slot-scope="scope">
              <slot v-if="item.slot" :name="scope.column.property" :row="scope.row" :$index="scope.$index">
                <div v-if="scope.column.label === '操作'">
                  <el-button type="primary" @click="edit(scope.row)"> 编辑 </el-button>
                  <el-popconfirm title="确定删除吗？" class="ml-10" @confirm="remove(scope.row.ID)">
                    <el-button slot="reference" type="danger">删除</el-button>
                  </el-popconfirm>
                </div>
                <el-switch v-else v-model="scope.row.status" />
              </slot>
              <span v-else>{{ scope.row[scope.column.property] || '暂无' }}</span>
            </template>
          </el-table-column>
        </el-table>
        <pagination :total="total" @download="download" @refreshList="fetchOtherEnergyCharge" />
      </div>
    </div>
    <modal :visible="showModal" :select="select" @close="close" />
    <import-modal :visible="showImportModal" @close="refresh" />
  </div>
</template>

<script>
import pagination from '@/layout/components/pagination.vue'
import Modal from './qtwh-modal.vue'
import importModal from './components/importModal.vue'
import { fetchMonth } from '@/api/fee'
import { fetchOtherEnergyCharge, removeOtherEnergyCharge } from '@/api/energy'

export default {
  name: 'Alarm',
  components: { pagination, Modal, importModal },
  data() {
    return {
      showImportModal: false,
      list: [],
      load: false,
      total: 0,
      startPickerOptions: {
        disabledDate(time) {
          return Number(time.getFullYear()) < 2017 || Number(time.getFullYear()) > Number(new Date().getFullYear())
        },
      },
      column: [
        { prop: 'TITLE', label: '时间' },
        { prop: 'ENERGYTYPE', label: '能源类别' },
        { prop: 'TYPE', label: '码头设施' },
        { prop: 'PROCESS', label: '过程环节' },
        { prop: 'EQ', label: '当月用量' },
        { prop: 'EC', label: '总金额' },
        { prop: 'action', label: '操作', slot: true },
      ],
      query: {
        monthId: undefined,
        pageNumber: 1,
      },
      month: [],
      year: '2021',
      select: {},
      showModal: false,
    }
  },
  created() {
    this.fetchOtherEnergyCharge()
    this.fetchMonth()
  },
  methods: {
    refresh(type) {
      this.showImportModal = false
      if (type) this.fetchOtherEnergyCharge()
    },
    fetchMonth() {
      fetchMonth({ year: this.year || '2021' }).then((res) => {
        this.month = res.data
      })
    },
    download() {
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = `/power/ajaxJsp/maintain/ajaxOtherEnergyCharge.jsp?isExport=true&postType=query&monthId=${this.query.monthId}`)
        : (url =
            process.env.VUE_APP_BASE_API +
            `ajaxJsp/maintain/ajaxOtherEnergyCharge.jsp?isExport=true&postType=query&monthId=${this.query.monthId}`)
      window.location.href = url
    },
    remove(id) {
      if (id) {
        removeOtherEnergyCharge({ ID: id }).then((res) => {
          res.code === '200' ? this.done(res.message, 'success') : this.done(res.message, 'error')
        })
      }
    },
    done(val, type) {
      this.$message({
        message: val,
        type: type,
      })
      if (type === 'success') this.fetchOtherEnergyCharge()
    },
    create() {
      this.select = {}
      this.showModal = true
    },
    fetchOtherEnergyCharge(val) {
      this.load = true
      if (val) this.query.pageNumber = val
      fetchOtherEnergyCharge(this.query).then((res) => {
        this.list = res.data.items
        this.total = res.data.totalCount
        this.load = false
      })
    },
    close(val) {
      this.select = {}
      console.log(this.select)
      if (val) this.fetchOtherEnergyCharge()
      this.showModal = false
    },
    edit(data) {
      this.showModal = true
      this.select = data
    },
    getHeaderClass() {
      return {
        background: '#071b39',
        color: '#fff',
      }
    },
    getRowClass({ row, column, rowIndex, columnIndex }) {
      if (rowIndex % 2 === 0) {
        return {
          background: '#03102d',
          color: '#fff',
        }
      } else {
        return {
          background: '#0c2e52',
          color: '#fff',
        }
      }
    },
  },
}
</script>

<style lang="scss" scoped>
::v-deep .el-input__inner {
  background-color: #1b2742;
  border: 1px solid #7c818f;
  border-radius: 0;
  color: #a4a7b1;
}

.box-container {
  position: relative;
  height: 830px;
  padding-top: 5rem;
  color: #fff;
  background-image: url('~@/assets/img/report_bg.png');
  background-size: 100% 100%;
  // margin: 20px 30px;
  .create-button {
    position: absolute;
    right: 2%;
    top: 2rem;
  }
  .search-bar {
    position: absolute;
    top: 2rem;
    right: 10%;
  }
  ::v-deep .alarm-table {
    padding-top: 40px;
    .el-table--enable-row-hover .el-table__body tr:hover > td {
      background-color: transparent !important;
    }
    .el-table::before {
      height: 0px;
    }
    .el-button {
      border-radius: 0;
    }
    /* 表格内背景颜色 */
    .el-table th,
    .el-table tr,
    .el-table,
    .el-table td {
      border: 0;
      background-color: transparent;
    }
    .el-table__footer-wrapper {
      background-color: rgba(39, 129, 174, 0.8);
      td {
        color: #fff;
      }
    }
    .el-checkbox__inner {
      border: 2px solid #407997;
      background-color: rgba(21, 61, 57, 0.7);
      border-radius: 0;
    }
    .el-table {
      color: #fff;
    }
    .el-table__header-wrapper {
      border: 1px solid #30a0d8;
    }
    .el-table td,
    .el-table th.is-leaf {
      border-bottom: none;
    }
  }
  .box-title {
    position: absolute;
    top: 0;
    left: 0px;
    width: 16.7%;
    height: 4%;
    color: #fff;
    background-image: url('~@/assets/img/index_title.png');
    background-size: 100% 100%;
    font-size: 15px;
  }
}
</style>
