<template>
  <div>
    <div class="mt-10 box-container">
      <div class="flex box-title font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="">
        <span>{{ title }}</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="">
      </div>
      <el-row style="height: 50%" class="pl-40 pr-40">
        <el-row type="flex" justify="space-between">
          <div class="operate-bar">
            <span class="mr-20">堆场:</span>
            <el-select
              v-model="query.machine"
              multiple
              filterable
              class="mr-35"
              style="width: 75%"
              placeholder="请选择堆场"
              @change="changeMachine"
            >
              <el-option label="全部设备" value="" />
              <el-option v-for="item in machineOption" :key="item" :label="item" :value="item" />
            </el-select>
          </div>
          <div class="start-time">
            <span class="mr-20">开始日期:</span>
            <el-date-picker
              v-model="query.startTime"
              :format="format"
              :value-format="valueFormat"
              :picker-options="timeChange"
              style="width: 70%"
              type="datetime"
              placeholder="选择开始日期"
            />
          </div>
          <div class="text-right end-time">
            <span class="mr-20">结束日期:</span>
            <el-date-picker
              v-model="query.endTime"
              :format="format"
              :value-format="valueFormat"
              :picker-options="timeChange"
              style="width: 70%"
              type="datetime"
              placeholder="选择结束日期"
            />
          </div>
        </el-row>
        <el-row class="mt-20 mb-20" type="flex" align="middle">
          <el-radio-group v-model="query.cycle">
            <el-radio label="year">年</el-radio>
            <el-radio label="month">月</el-radio>
            <el-radio label="week">周</el-radio>
            <el-radio label="day">日</el-radio>
            <el-radio label="hour">小时</el-radio>
          </el-radio-group>
          <div>
            <span class="operate-bar-search " @click="showReprot = true">报表查询</span>
            <!-- <span class="operate-bar-search " @click="tableVisible = true">查看折线图表格</span> -->
            <!-- <span class="operate-bar-search " @click="download">导出折线图表格</span> -->
            <span class="operate-bar-search" @click="fetchIceBox">查询</span>
          </div>
        </el-row>
        <div
          id="line"
          v-loading="loadLine"
          v-on-echart-resize
          element-loading-text="拼命加载中"
          element-loading-spinner="el-icon-loading"
          element-loading-background="rgba(3, 10, 33, 0.8)"
        />
        <div
          id="circle"
          ref="circle"
          v-loading="load"
          v-on-echart-resize
          class="ml-20"
          element-loading-text="拼命加载中"
          element-loading-spinner="el-icon-loading"
          element-loading-background="rgba(3, 10, 33, 0.8)"
        />
      </el-row>
      <!-- <el-row style="height: 45%" class="pl-30 pr-30">
        <energy-bar-chart />
      </el-row> -->
    </div>
    <list-table
      :show-summary="false"
      type="能耗"
      :table-visible="tableVisible"
      :table-data="tableData"
      :column="column"
      :total="total"
      @close="close"
      @download="download"
    />
    <energy-report :visible="showReprot" @close="showReprot = false" />
  </div>
</template>

<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import EnergyBarChart from './energyBarChart.vue'
import { fetchDropList } from '@/api/analysis'
import { fetchBridgeLine, fetchIceLine, fetchTableReport } from '@/api/energy'
import { deepCopy } from '@/utils/utils'
import EnergyReport from './components/energyReport.vue'
import moment from 'moment'
import ListTable from '@/components/ListTable.vue'
import { storage, findTitle } from '@/utils/utils'

export default {
  name: 'Icebox',
  components: {
    EnergyReport,
    ListTable,
    EnergyBarChart
  },
  data() {
    return {
      load: false,
      title: '',
      showReprot: false,
      machineOption: [],
      timeChange: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      total: 0,
      format: 'yyyy 年 MM 月 dd 日 HH 时',
      valueFormat: 'yyyy-MM-dd HH',
      circle: undefined,
      query: {
        type: 'YARD',
        machine: '',
        startTime: moment().format('YYYY-MM') + '-' + '01' + ' ' + '00',
        endTime: moment().format('YYYY-MM-DD') + ' ' + '00',
        dt: 'hour',
        cycle: 'day'
      },
      loadLine: false,
      line: undefined,
      tableData: [],
      column: [],
      timeRange: [],
      tableVisible: false
    }
  },
  mounted() {
    this.title = findTitle(storage.get('energyMenu'), this.$route.path)
    this.fetchDropList()
    this.circle = echarts.init(document.getElementById('circle'))
    this.line = echarts.init(document.getElementById('line'))
  },
  destroyed() {
    if (this.line) this.line.dispose()
  },
  methods: {
    download() {
      const query = deepCopy(this.query)
      if (!query.startTime) query.startTime = moment().format('YYYY-MM') + '-' + '01' + ' ' + '00'
      if (!query.endTime) query.endTime = moment().format('YYYY-MM-DD') + ' ' + '00'
      if (!query.machine || query.machine.length === 0) {
        query.machine = ''
      } else {
        query.machine = query.machine.join()
      }
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = `/power/ajaxJsp/screen/ajaxEquipmentColdBoxRateStatistics.jsp?postType=download&cycle=${query.cycle}&endTime=${query.endTime}&startTime=${query.startTime}&machine=${query.machine}`)
        : (url =
            process.env.VUE_APP_BASE_API +
            `ajaxJsp/screen/ajaxEquipmentColdBoxRateStatistics.jsp?postType=download&cycle=${query.cycle}&endTime=${query.endTime}&startTime=${query.startTime}&machine=${query.machine}`)
      window.location.href = url
    },
    close() {
      this.tableVisible = false
    },
    changeMachine(val) {
      if (val[val.length - 1] === '') {
        this.query.machine = ['']
      } else {
        const index = val.indexOf('')
        if (index !== -1) this.query.machine.splice(index, 1)
      }
    },
    fetchIceBox() {
      this.load = true
      this.loadLine = true
      const query = deepCopy(this.query)
      if (!query.startTime) query.startTime = moment().format('YYYY-MM') + '-' + '01' + ' ' + '00'
      if (!query.endTime) query.endTime = moment().format('YYYY-MM-DD') + ' ' + '00'
      if (!query.machine || query.machine.length === 0) {
        query.machine = ''
      } else {
        query.machine = query.machine.join()
      }
      fetchBridgeLine(query).then((res) => {
        if (res.data.length === 0) {
          this.$message({
            message: '暂无数据',
            type: 'warning'
          })
          this.load = false
        } else {
          this.drawCircle(res.data)
        }
      })
      fetchIceLine({
        machine: query.machine,
        startTime: query.startTime,
        endTime: query.endTime,
        cycle: query.cycle
      }).then((res) => {
        if (res.data.length === 0) {
          this.$message({
            message: '暂无数据',
            type: 'warning'
          })
          this.loadLine = false
        } else {
          this.tableData = res.data
          this.transformData(res.data)
          fetchTableReport({
            machine: query.machine,
            startTime: query.startTime,
            endTime: query.endTime,
            cycle: query.cycle
          }).then((res) => {
            if (res.data.length !== 0) {
              const column = [{ prop: 'CODE', label: '设备编码', fixed: true }]
              // 把时间筛选出来 为column赋值
              for (const i of this.time) {
                column.push({
                  prop: i,
                  label: i
                })
              }
              this.column = column
              this.tableData = res.data
              this.total = this.tableData.length
              console.log(this.column)
              console.log(this.tableData)
            }
          })
        }
      })
    },
    fetchDropList() {
      fetchDropList({ eqName: 'YARD' }).then((res) => {
        this.machineOption = res.data
        const temp = deepCopy(this.machineOption)
        this.query.machine = temp.splice(0, 5)
        this.fetchIceBox()
      })
    },
    transformData(data) {
      const series = []
      let time = []
      data.forEach((item) => {
        time = item.value.map((ele) => ele.TIME)
        switch (item.name) {
          case 'PEAK':
            item.name = '峰值'
            break
          case 'SMOOTH':
            item.name = '平值'
            break
          case 'TOP':
            item.name = '尖值'
            break
          case 'VALLEY':
            item.name = '谷值'
            break
        }
        series.push({
          name: item.name,
          type: 'line',
          data: item.value.map((ele) => ele.COST)
        })
      })
      this.time = time
      if (this.line) this.line.clear()
      this.drawLine(series, time)
    },
    drawLine(series, time) {
      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: '#6a7985'
            }
          },
          formatter: (params) => {
            let str = ''
            params.forEach((i, index) => {
              if (index !== 0 && (index + 1) % 3 === 0) {
                str = str + i.marker + i.seriesName + ' ' + i.value + '<br>'
              } else {
                str = str + i.marker + `<span style='margin-right:10px;'>${i.seriesName} ${i.value}</span>`
              }
            })
            return str
          }
        },
        legend: {
          textStyle: {
            color: '#fff',
            fontSize: 16
          }
        },
        grid: {
          top: '10%',
          left: '0%',
          right: '0%',
          bottom: '0%',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            axisLabel: {
              show: true,
              textStyle: {
                color: '#fff'
              }
            },
            data: time
          }
        ],
        yAxis: [
          {
            type: 'value',
            axisLabel: {
              show: true,
              textStyle: {
                color: '#17bae0'
              }
            }
          }
        ],
        series: series
      }
      this.line = echarts.init(document.getElementById('line'))
      option && this.line.setOption(option)
      this.loadLine = false
    },
    drawCircle(data) {
      const keyMap = {
        NAME: 'name',
        VALUE: 'value'
      }
      for (var i = 0; i < data.length; i++) {
        var obj = data[i]
        for (var key in obj) {
          var newKey = keyMap[key]
          if (newKey) {
            obj[newKey] = obj[key]
            delete obj[key]
          }
        }
      }
      const option = {
        legend: {
          orient: 'vertical',
          left: '15%',
          y: '10%',
          icon: 'react',
          itemGap: 20,
          textStyle: {
            color: '#fff',
            fontSize: 16
          }
        },
        series: [
          {
            name: 'pie',
            type: 'pie',
            radius: '65%',
            center: ['60%', '55%'],
            label: {
              normal: {
                formatter: '{b}' + '\n' + ' {c}',
                textStyle: {
                  fontSize: 20, // 改变标示文字的大小
                  color: '#a9c4cb'
                }
              }
            },
            data: data
          }
        ]
      }
      this.circle = echarts.init(document.getElementById('circle'))
      option && this.circle.setOption(option)
      this.load = false
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep .el-input__inner {
  background-color: #1b2742;
  border: 1px solid #7c818f;
  border-radius: 0;
  color: #a4a7b1;
}
.box-container {
  position: relative;
  height: 1200px;
  padding-top: 6rem;
  color: #fff;
  background-image: url('~@/assets/img/icebox.png');
  background-size: 100% 100%;
  background-repeat: no-repeat;

  #circle,
  #line {
    display: inline-block;
    width: 48%;
    // margin-top: 50px;
    height: 80%;
  }
  #bar {
    height: 80%;
    width: 90%;
  }
  .box-title {
    position: absolute;
    left: 0px;
    top: 0;
    width: 16.8%;
    height: 3.5%;
    color: #fff;
    background-image: url('~@/assets/img/index_title.png');
    background-size: 100% 100%;
    font-size: 15px;
  }
  .operate-bar-search {
    height: 40px;
    width: 130px;
    display: inline-block;
    background-color: #3399ff;
    color: #fff;
    text-align: center;
    line-height: 40px;
    font-size: 1.8rem;
    margin-left: 5.5rem;
    cursor: pointer;
  }
  .operate-bar-search:nth-child(1),
  .operate-bar-search:nth-child(2) {
    width: 150px;
  }
  .operate-bar {
    font-size: 2rem;
    width: 35%;
  }
  .end-time,
  .start-time {
    width: 30%;
    font-size: 2rem;
  }
}
::v-deep .el-radio__label {
  color: #fff;
}
</style>
