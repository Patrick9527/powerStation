<template>
  <div>
    <div class="mt-10 bridge-container pl-30 pr-30">
      <div class="flex bridge-title font-weight">
        <img class="mr-15" src="@/assets/img/index_left.png" alt="">
        <span>{{ title }}</span>
        <img class="ml-15" src="@/assets/img/index_right.png" alt="">
      </div>
      <energy-search @showReprotDialog="showReprotDialog" />
      <!-- <el-row style="height:600px;" class="pl-30">
        <energy-bar-chart />
      </el-row> -->
      <energy-report :visible="showReprot" @close="close" />
    </div>
  </div>
</template>

<script>
import EnergyBarChart from './energyBarChart.vue'
import EnergyReport from './energyReport.vue'
import EnergySearch from '@/components/Energy/index.vue'
import { storage, findTitle } from '@/utils/utils'

export default {
  name: 'Bridge',
  components: {
    EnergyBarChart,
    EnergyReport,
    EnergySearch
  },
  data() {
    return {
      showReprot: false,
      title: ''

    }
  },
  mounted() {
    this.title = findTitle(storage.get('energyMenu'), this.$route.path)
  },
  methods: {
    close() {
      this.showReprot = false
    },
    showReprotDialog(val) {
      this.showReprot = val
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/energy/bridge.scss';
.bridge-container #equipmentLine {
  height: 53rem;
}
</style>
