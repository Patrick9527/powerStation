import router from './router'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import getPageTitle from '@/utils/get-page-title'
import { fetchMenu } from '@/api/user'
import { storage, recursion } from '@/utils/utils'
import store from './store'

NProgress.configure({ showSpinner: false })

const whiteList = ['/login']

router.beforeEach(async(to, from, next) => {
  NProgress.start()
  NProgress.done()
  document.title = getPageTitle(to.meta.title)

  const hasMenu = storage.get('energyMenu')
  if (hasMenu && hasMenu.length !== 0) {
    if (to.path === '/login') {
      next({ path: '/' })
      NProgress.done()
    } else {
      // const permissionPath = fetchPermissionPath(storage.get('energyMenu'))
      // const isPermission = permissionPath.indexOf(to.path)
      // isPermission === -1 && to.path !== '/dashboard' ? next(from.path) : next()
      next()
      // if (from.name === null || from.name === undefined) {
    }
  } else {
    console.log(to.path)
    console.log(document.cookie)
    if (whiteList.indexOf(to.path) !== -1) {
      next()
    } else if (document.cookie.includes('JSESSIONID')) {
      // 如果有cookie && 菜单数据 重新获取
      fetchMenu({ type: 'front' }).then((res) => {
        const online = recursion(res.MENU)
        const date = new Date().valueOf()
        storage.set('energyMenu', online, date)
        store.commit('user/SET_MENU', online)
        next()
      })
    } else {
      next(`/login?redirect=${to.path}`)
      NProgress.done()
    }
  }
})

router.afterEach(() => {
  NProgress.done()
})
