import request from '@/utils/request'

export function fetchRealEnergy(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyTop.jsp?postType=query',
    method: 'get',
    data
  })
}

export function fetchVitalEnergy(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyAVE.jsp?postType=query',
    method: 'post',
    data
  })
}

export function fetchEquipmentEnergy(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyType.jsp?postType=query',
    method: 'post',
    data
  })
}

export function fetchEnergyDistribution(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyZbfx.jsp?postType=query',
    method: 'post',
    data
  })
}

export function fetchAlarmInfo(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyAlarm.jsp?postType=query',
    method: 'post',
    data
  })
}

export function editAlarm(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyAlarm.jsp?postType=update',
    method: 'post',
    data
  })
}

export function fetchEnergyStatistics(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentNowDay.jsp?postType=query',
    method: 'post',
    data
  })
}

export function fetchPvDataToday(data) {
  return request({
    url: '/ajaxJsp/screen/GreenEnergy/ajaxPvDataToday.jsp',
    method: 'post',
    data
  })
}

export function fetchGridArkMonitor(data) {
  return request({
    url: '/ajaxJsp/screen/GreenEnergy/ajaxGridArkMonitor.jsp?postType=query',
    method: 'post',
    data
  })
}

export function fetchEquipmentGreenEnergy(data) {
  return request({
    url: '/ajaxJsp/screen/GreenEnergy/ajaxEquipmentGreenEnergy.jsp',
    method: 'post',
    data
  })
}
export function fetchPowerRealTimeData(data) {
  return request({
    url: '/ajaxJsp/screen/GreenEnergy/ajaxPowerRealTimeData.jsp?postType=query',
    method: 'post',
    data
  })
}

export function fetchWindMenu(data) {
  return request({
    url: '/ajaxJsp/screen/GreenEnergy/ajaxWindEnergyMonitor.jsp',
    method: 'post',
    data
  })
}

export function fetchLightMenu(data) {
  return request({
    url: '/ajaxJsp/screen/GreenEnergy/ajaxLightEnergyMonitor.jsp',
    method: 'post',
    data
  })
}
