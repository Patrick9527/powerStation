import request from '@/utils/request'

export function fetchAlarm(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyWarning.jsp?postType=query',
    method: 'post',
    data
  })
}

export function editAlarm(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyWarning.jsp',
    method: 'post',
    data
  })
}

export function fetchSuggest(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentWarningSuggestVal.jsp?postType=query',
    method: 'post',
    data
  })
}
