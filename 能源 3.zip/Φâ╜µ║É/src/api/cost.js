import request from '@/utils/request'

export function fetchMonthlyList(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentEnergyTypeMonth.jsp?postType=query',
    method: 'post',
    data,
  })
}

export function fetchEnergyList(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyList.jsp?postType=query',
    method: 'post',
    data,
  })
}

export function fetchEnergy(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentEnergyMonth.jsp?postType=query',
    method: 'post',
    data,
  })
}

export function fetchStock(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentColdBoxKTReport.jsp?postType=query',
    method: 'post',
    data,
  })
}

export function fetchBoxNumber(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentColdBoxAmountReport.jsp?postType=query',
    method: 'post',
    data,
  })
}

export function fetchBoxTemp(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentColdBoxTempDiffReport.jsp?postType=query',
    method: 'post',
    data,
  })
}
export function fetchMonthlyCost(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentEnergyMonthCost.jsp?postType=query',
    method: 'post',
    data,
  })
}
