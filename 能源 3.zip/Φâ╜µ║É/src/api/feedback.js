import request from '@/utils/request'

export function fetchFeedBack(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentEnergyFeedback.jsp?postType=query',
    method: 'post',
    data
  })
}
