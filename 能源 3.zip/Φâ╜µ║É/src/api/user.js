import request from '@/utils/request'

export function login(data) {
  return request({
    url: 'loginCheck.dox',
    method: 'post',
    data
  })
}

export function fetchMenu(data) {
  return request({
    url: 'ajaxJsp/system/ajaxLoadEnergyMenuTree.jsp',
    method: 'post',
    data
  })
}
