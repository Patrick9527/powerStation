import request from '@/utils/request'

export function fetchEnergyLine(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxajaxEquipmentEnergy.jsp?postType=query',
    method: 'get',
    data
  })
}

export function fetchEnergyReport(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyEnergyList.jsp?postType=query',
    method: 'get',
    data
  })
}

export function fetchEnergyBarChart(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentEnergyLastYear.jsp?postType=query',
    method: 'get',
    data
  })
}

export function fetchAllEnergy(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxJsp/screen/ajaxEquipmentEnergySum.jsp?postType=query',
    method: 'get',
    data
  })
}
