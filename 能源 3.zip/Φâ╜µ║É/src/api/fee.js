import request from '@/utils/request'

export function fetchFee(data) {
  return request({
    url: 'ajaxJsp/maintain/ajaxPowerCharge.jsp?postType=query',
    method: 'post',
    data
  })
}

export function fetchMonth(data) {
  return request({
    url: 'ajaxJsp/maintain/ajaxOrderMonth.jsp?postType=query',
    method: 'post',
    data
  })
}

export function removeFee(data) {
  return request({
    url: 'ajaxJsp/maintain/ajaxPowerCharge.jsp?postType=delete',
    method: 'post',
    data
  })
}

export function fetchItems(data) {
  return request({
    url: 'ajaxJsp/maintain/ajaxCompanyItem.jsp?postType=query',
    method: 'post',
    data
  })
}

export function editFee(data) {
  return request({
    url: 'ajaxJsp/maintain/ajaxPowerCharge.jsp?postType=update',
    method: 'post',
    data
  })
}
