import request from '@/utils/request'

export function fetchBridge(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentOneEnergy.jsp',
    method: 'post',
    data
  })
}

export function fetchDropList(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxAllEqCodePlus.jsp?postType=query',
    method: 'post',
    data
  })
}

export function fetchTips(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentColdBoxStatistics.jsp?postType=query',
    method: 'post',
    data
  })
}

export function fetchPeak(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentPeakPower.jsp?postType=query',
    method: 'post',
    data
  })
}

export function fetchZb(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCostZb.jsp?postType=query',
    method: 'post',
    data
  })
}

export function fetchIceBoxStatistics(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentNaturalBoxStatistics.jsp?postType=query',
    method: 'post',
    data
  })
}
