import request from '@/utils/request'

export function fetchEnergyReport(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyEnergyList.jsp?postType=query',
    method: 'post',
    data,
  })
}

export function fetchAllEnergy(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentEnergySum.jsp?postType=query',
    method: 'post',
    data,
  })
}

export function fetchBarChart(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentEnergyLastYear.jsp?postType=query',
    method: 'post',
    data,
  })
}

export function fetchBridgeLine(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentEnergy.jsp?postType=query',
    method: 'post',
    data,
  })
}

export function fetchPieData(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentEnergyZb.jsp?postType=query',
    method: 'post',
    data,
  })
}

export function fetchIceLine(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentColdBoxRateStatistics.jsp?postType=query',
    method: 'post',
    data,
  })
}

export function fetchTableReport(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentColdBoxRateStatistics.jsp?postType=report',
    method: 'post',
    data,
  })
}
export function fetchOtherEnergyCharge(data) {
  return request({
    url: 'ajaxJsp/maintain/ajaxOtherEnergyCharge.jsp?postType=query',
    method: 'post',
    data,
  })
}
export function removeOtherEnergyCharge(data) {
  return request({
    url: 'ajaxJsp/maintain/ajaxOtherEnergyCharge.jsp?postType=delete',
    method: 'post',
    data,
  })
}
export function updateOtherEnergyCharge(data) {
  return request({
    url: 'ajaxJsp/maintain/ajaxOtherEnergyCharge.jsp?postType=update',
    method: 'post',
    data,
  })
}
export function fetchEnergyTypeSelect(data) {
  return request({
    url: 'ajaxJsp/maintain/ajaxOtherEnergyCharge.jsp?postType=energyType',
    method: 'post',
    data,
  })
}
export function fetchEnergyProcessSelect(data) {
  return request({
    url: 'ajaxJsp/maintain/ajaxOtherEnergyCharge.jsp?postType=process',
    method: 'post',
    data,
  })
}
export function fetchTypeSelect(data) {
  return request({
    url: 'ajaxJsp/maintain/ajaxOtherEnergyCharge.jsp?postType=type',
    method: 'post',
    data,
  })
}
