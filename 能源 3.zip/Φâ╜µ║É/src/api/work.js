import request from '@/utils/request'

export function fetchBridge(data) {
  return request({
    url: 'ajaxJsp/screen/ajaxEquipmentCompanyStatistics.jsp?postType=query',
    method: 'post',
    data
  })
}
