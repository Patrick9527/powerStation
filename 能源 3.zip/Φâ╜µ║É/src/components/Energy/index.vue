<template>
  <el-row class="pl-30">
    <el-row type="flex" justify="space-between">
      <el-col :span="17" class="pr-25 flex-column">
        <div class="select-row mb-35">
          <span>{{ !showType ? '设备列表' : '能源类型' }}:</span>
          <div class="flex-between">
            <el-select
              v-if="!showType"
              ref="select"
              v-model="query.machine"
              multiple
              filterable
              style="width: 75%"
              class="mr-40"
              placeholder="请选择设备"
              @change="changeMachine"
            >
              <el-option label="全部设备" value="" />
              <div v-if="$route.name !== 'AGV'">
                <el-option v-for="(item, index) in machineOption" :key="index" :label="item" :value="item" />
              </div>
            </el-select>
            <el-select
              v-else
              ref="select"
              v-model="query.machine"
              multiple
              filterable
              style="width: 75%"
              class="mr-40"
              placeholder="请选择能源类型"
              @change="changeMachine"
            >
              <el-option
                v-for="(item, index) in energyType"
                :key="index"
                :disabled="item.disabled"
                :label="item.LIBTITLE"
                :value="item.LIBKEY"
              />
            </el-select>
            <el-select
              v-show="$route.name !== 'AD' && $route.name !== 'ZHSC'"
              v-model="query.unit"
              style="width: 15%"
              placeholder="单吨 / 单箱"
            >
              <el-option v-for="item in switchArray" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </div>
        </div>
        <div class="mb-35 select-row">
          <span class="text-hidden" />
          <div class="flex-between">
            <el-date-picker
              v-model="query.startTime"
              style="width: 45%"
              type="datetime"
              class="mr-20"
              :format="format"
              :value-format="valueFormat"
              :picker-options="timeChange"
              placeholder="选择日期时间"
            />
            <el-date-picker
              v-model="query.endTime"
              :format="format"
              :value-format="valueFormat"
              style="width: 45%"
              :picker-options="timeChange"
              type="datetime"
              placeholder="选择日期时间"
            />
          </div>
        </div>
        <div class="select-row">
          <span class="text-hidden" />
          <div class="flex-between">
            <div class="flex-between">
              <el-radio-group v-model="query.dt">
                <el-radio label="year">年</el-radio>
                <el-radio label="month">月</el-radio>
                <el-radio label="week">周</el-radio>
                <el-radio label="day">日</el-radio>
                <el-radio v-show="$route.name !== 'AD'" label="hour">小时</el-radio>
              </el-radio-group>
            </div>
            <!-- <el-checkbox
              v-show="$route.path === '/energy/bridge' || $route.path === '/energy/crane'"
              v-model="query.feedback"
            >
              扣除回馈
            </el-checkbox> -->
            <div class="select-row-search ml-30" @click="fetchBridgeLine">查询</div>
          </div>
        </div>
      </el-col>
      <el-col :span="7" style="height: 100%">
        <div class="whole-energy">
          <span> {{ title }} </span>
          <span>{{ sum.万KWH || '暂无' }} 万kWh</span>
          <span>{{ sum.TCE || '暂无' }} tce</span>
        </div>
      </el-col>
    </el-row>
    <el-col :span="17">
      <el-row style="height: 58%">
        <div class="mt-40 operate-row">
          <el-radio-group v-model="query.danwei">
            <el-radio label="KWH">kW·h</el-radio>
            <el-radio label="KGCE">kgce</el-radio>
          </el-radio-group>
          <div>
            <!-- <span class="mr-20" @click="download">导出折线图表格数据</span> -->
            <!-- <span v-if="$route.path === '/energy/icebox'" class="mr-20 " @click="download">导出折线图表格数据</span> -->
            <!-- <span class="mr-20" @click="showTable">查看折线图表格</span> -->
            <span v-show="$route.name !== 'AD'" @click="showReprot">报表查询</span>
          </div>
        </div>
        <div
          id="equipmentLine"
          ref="equipmentLine"
          v-loading="load"
          v-on-echart-resize
          class="pt-20"
          element-loading-text="拼命加载中"
          element-loading-spinner="el-icon-loading"
          element-loading-background="rgba(3, 10, 33, 0.8)"
        />
      </el-row>
    </el-col>
    <el-col :span="7">
      <div id="pieChart" ref="pieChart" v-on-echart-resize class="mt-50" />
    </el-col>
    <list-table
      type="能耗"
      :sum="sums"
      :table-visible="tableVisible"
      :total="total"
      :table-data="tableData"
      :column="column"
      @download="download"
      @close="close"
    />
  </el-row>
</template>

<script>
import * as echarts from 'echarts'
import '@/directives/chart.resize'
import { deepCopy } from '@/utils/utils'
import moment from 'moment'
import { fetchDropList } from '@/api/analysis'
import { fetchAllEnergy, fetchBridgeLine, fetchPieData } from '@/api/energy'
import ListTable from '@/components/ListTable.vue'
import { fetchEnergyTypeSelect } from '@/api/energy'
import { storage, findTitle } from '@/utils/utils'

export default {
  components: { ListTable },
  props: {
    showType: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      title: '',
      column: [],
      total: 0,
      sums: ['合计', '', 0],
      tableData: [],
      tableVisible: false,
      load: false,
      energyType: [],
      line: undefined,
      pie: undefined,
      switchArray: [
        { value: 'D', label: '单吨' },
        { value: 'B', label: '单箱' },
        { value: 'A', label: '全部' }
      ],
      sum: {},
      machineOption: [],
      format: 'yyyy 年 MM 月 dd 日 HH 时',
      valueFormat: 'yyyy-MM-dd HH',
      timeChange: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      },
      query: {
        type: this.$route.name,
        postType: 'query',
        machine: '',
        // feedback: true,
        startTime: moment().format('YYYY-MM') + '-' + '01' + ' ' + '00',
        endTime: moment().format('YYYY-MM-DD') + ' ' + '00',
        danwei: 'KWH',
        dt: 'day',
        unit: 'A',
        i: ''
      }
    }
  },
  computed: {
    danwei() {
      return this.query.danwei
    }
  },
  watch: {
    danwei: {
      handler: 'fetchBridgeLine'
    }
  },
  mounted() {
    this.title = findTitle(storage.get('energyMenu'), this.$route.path)
    this.line = echarts.init(document.getElementById('equipmentLine'))
    this.pie = echarts.init(document.getElementById('pieChart'))
  },
  created() {
    if (this.$route.name === 'AD') {
      this.query.startTime =
        moment()
          .month(moment().month() - 1)
          .startOf('month')
          .format('YYYY-MM-DD') +
        ' ' +
        '00'
    }
    if (
      this.$route.name === 'QC' ||
      this.$route.name === 'ASC' ||
      this.$route.name === 'AGV' ||
      this.$route.name === 'ZHSC'
    ) {
      this.switchArray = [
        { value: 'B', label: '单箱' },
        { value: 'A', label: '全部' }
      ]
    }
    if (this.$route.path === '/energy/agvSingle') {
      this.query.type = 'AGV'
      this.query.i = 'AGV'
    } else {
      delete this.query.i
    }
    this.showType ? this.fetchEnergyTypeSelect() : this.fetchDropList()
  },
  destroyed() {
    if (this.line) this.line.dispose()
  },
  methods: {
    fetchEnergyTypeSelect() {
      fetchEnergyTypeSelect().then((res) => {
        res.data.items.forEach((i) => {
          i.disabled = false
          if (this.$route.meta.title !== '综合能耗') {
            if (i.LIBTITLE.includes('LNG') || i.LIBTITLE.includes('氢')) {
              i.disabled = true
            }
          }
        })
        this.energyType = res.data.items
        console.log(this.$route)
        this.fetchBridgeLine()
      })
    },
    download() {
      const query = this.transformParameters()
      const env = process.env.NODE_ENV
      let url = ''
      env === 'development'
        ? (url = `/power/ajaxJsp/screen/ajaxEquipmentEnergy.jsp?postType=download&danwei=${query.danwei}&dt=${query.dt}&startTime=${query.startTime}&endTime=${query.endTime}&machine=${query.machine}&type=${query.type}&type=${query.type}&unit=${query.unit}`)
        : (url =
            process.env.VUE_APP_BASE_API +
            `ajaxJsp/screen/ajaxEquipmentEnergy.jsp?postType=download&danwei=${query.danwei}&dt=${query.dt}&startTime=${query.startTime}&endTime=${query.endTime}&machine=${query.machine}&type=${query.type}&type=${query.type}&unit=${query.unit}`)
      window.location.href = url
    },
    close() {
      this.tableVisible = false
    },
    showTable() {
      this.tableVisible = true
    },
    showReprot() {
      this.$emit('showReprotDialog', true)
    },
    transformParameters() {
      const query = deepCopy(this.query)
      if (!query.startTime) query.startTime = moment().format('YYYY-MM') + '-' + '01'
      if (!query.endTime) query.endTime = moment().format('YYYY-MM-DD')
      console.log(query)
      // query.feedback ? (query.feedback = 1) : (query.feedback = 0)
      if (this.$route.path !== '/energy/bridge' && this.$route.path !== '/energy/crane') {
        // delete query.feedback
      }
      if (this.$route.name !== 'AGV') {
        if (!query.machine || query.machine.length === 0) {
          query.machine = ''
        } else {
          query.machine = query.machine.join()
        }
      } else {
        query.machine = ''
      }
      return query
    },
    fetchBridgeLine() {
      this.load = true
      const query = this.transformParameters()
      fetchAllEnergy(query).then((res) => {
        this.sum = res.data[0]
      })
      fetchPieData(query).then((res) => {
        this.drawPie(res.data)
      })
      fetchBridgeLine(query).then((res) => {
        if (res.data.length === 0) {
          this.$message({
            message: '暂无数据',
            type: 'warning'
          })
          this.load = false
        } else {
          this.tableData = res.data
          this.transformData(res.data)
        }
      })
    },
    transformData(data) {
      const series = []
      let time = []
      data.forEach((item) => {
        time = item.value.map((ele) => ele.TIME)
        series.push({
          name: item.name,
          type: 'line',
          data: item.value.map((ele) => ele.TOTAL)
        })
      })
      data.forEach((i) => {
        i.value.forEach((x) => {
          x.name = i.name
        })
      })
      // const arr = [].concat(...data.map(item => item.value))
      const newArr = []
      for (const i in data) {
        newArr.push({
          name: data[i].name
        })
      }
      data.forEach((x) => {
        for (let i = 0; i < x.value.length; i++) {
          const obj = x.value[i]
          const newKey = x.value[i].TIME
          obj[newKey] = obj.TOTAL
          for (const y of newArr) {
            if (y.name === obj.name) {
              y[newKey] = obj.TOTAL
            }
          }
        }
      })
      this.tableData = newArr
      const scope = data[0].value.map((x) => x.TIME)
      const column = [{ prop: 'name', label: '设备编码', fixed: true }]
      // 把时间筛选出来 为column赋值
      for (const i of scope) {
        column.push({
          prop: i,
          label: i
        })
      }
      this.column = column
      // if (this.sums[2] !== 0) this.sums = ['合计', '', 0]
      // this.tableData.forEach(i => {
      //   this.sums[2] += Number(i.TOTAL)
      // })
      // this.sums[2] = Math.floor(this.sums[2] * 100) / 100
      this.total = this.tableData.length
      if (this.line) this.line.clear()
      this.drawLine(series, time)
    },
    changeMachine(val) {
      if (val[val.length - 1] === '') {
        this.query.machine = ['']
      } else {
        const index = val.indexOf('')
        if (index !== -1) this.query.machine.splice(index, 1)
      }
    },
    fetchDropList() {
      fetchDropList({ eqName: this.query.type }).then((res) => {
        this.machineOption = res.data
        if (this.$route.name !== 'AGV' && this.$route.name !== 'AD') {
          const temp = deepCopy(this.machineOption)
          this.query.machine = temp.splice(0, 5)
        } else {
          this.query.machine = ['']
        }
        this.fetchBridgeLine()
      })
    },
    drawLine(series, time) {
      console.log(series)
      const option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: '#6a7985'
            }
          },
          formatter: (params) => {
            let str = ''
            params.forEach((i, index) => {
              if (index !== 0 && (index + 1) % 3 === 0) {
                str = str + i.marker + i.seriesName + ' ' + i.value + '<br>'
              } else {
                str = str + i.marker + `<span style='margin-right:10px;'>${i.seriesName} ${i.value}</span>`
              }
            })
            return str
          }
        },
        legend: {
          type: 'scroll',
          textStyle: {
            color: '#fff',
            fontSize: 16
          }
        },
        grid: {
          top: '15%',
          left: '0%',
          right: '3%',
          bottom: '0%',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            axisLabel: {
              show: true,
              textStyle: {
                color: '#fff'
              }
            },
            data: time
          }
        ],
        yAxis: [
          {
            type: 'value',
            axisLabel: {
              show: true,
              textStyle: {
                color: '#17bae0'
              }
            }
          }
        ],
        series: series
      }
      this.line = echarts.init(document.getElementById('equipmentLine'))
      option && this.line.setOption(option)
      this.load = false
    },
    drawPie(data) {
      const option = {
        tooltip: {
          trigger: 'item'
        },
        series: [
          {
            name: '能耗占比',
            type: 'pie',
            radius: '50%',
            label: {
              color: '#fff',
              fontSize: '15',
              formatter: function(params) {
                if (params.name === '当前查询设备KWH占比') {
                  return '当前查询设' + '\n\n' + '备KWH占比' + '{one|' + '\n\n' + params.value + '%' + ' }'
                } else {
                  return '其余查询设' + '\n\n' + '备KWH占比' + '{two|' + '\n\n' + params.value + '%' + ' }'
                }
              },
              rich: {
                one: {
                  color: '#3db5f0',
                  fontSize: 20,
                  fontWeight: 'bold'
                },
                two: {
                  fontSize: 20,
                  fontWeight: 'bold',
                  color: '#fead51'
                }
              },
              align: 'left'
            },
            labelLine: {
              length2: 20
            },
            center: ['50%', '60%'],
            data: [
              { value: Number(data), name: '当前查询设备KWH占比', itemStyle: { color: '#3db5f0' }},
              { value: (100 - Number(data)).toFixed(2), name: '其余查询设备KWH占比', itemStyle: { color: '#fead51' }}
            ]
          }
        ]
      }
      this.pie = echarts.init(document.getElementById('pieChart'))
      option && this.pie.setOption(option)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/energy/searchBar.scss';
</style>
