<template>
  <el-dialog :title="$route.meta.title + '列表'" :visible="tableVisible" fullscreen @close="close">
    <el-table
      v-el-table-infinite-scroll="load"
      height="400"
      :show-summary="showSummary"
      :data="tableData"
      :row-style="getRowClass"
      :header-cell-style="getHeaderClass"
    >
      <el-table-column
        v-for="(item, index) in column"
        :key="index"
        :fixed="item.fixed"
        :label="item.label"
        :prop="item.prop"
        width="100"
        align="center"
      />
    </el-table>
    <el-row type="flex" justify="center" align="middle" class="mt-20">
      <!-- <el-pagination
        :current-page="currentPage"
        :page-size="10"
        class="text-center"
        background
        layout="prev, pager, next"
        :total="Number(total)"
        @current-change="getcurrentNumber"
        @prev-click="leftClick"
        @next-click="rightClick"
      /> -->
      <span class="export-table mr-20" @click="$emit('download')">导出</span>
    </el-row>
  </el-dialog>
</template>

<script>
import elTableInfiniteScroll from 'el-table-infinite-scroll'

export default {
  name: 'EnergyReport',
  directives: {
    'el-table-infinite-scroll': elTableInfiniteScroll,
  },
  props: {
    showSummary: {
      type: Boolean,
      default() {
        return true
      },
    },
    tableVisible: {
      type: Boolean,
      default() {
        return false
      },
    },
    tableData: {
      type: Array,
      default() {
        return []
      },
    },
    column: {
      type: Array,
      default() {
        return [{ prop: 'name', label: '设备编码', fixed: true }]
      },
    },
    sum: {
      type: Array,
      default() {
        return ['合计', '', 0]
      },
    },
    type: {
      type: String,
      default: '箱量',
    },
    total: {
      type: Number,
      default() {
        return 0
      },
    },
  },
  data() {
    return {
      currentPage: 1,
      currentList: [],
    }
  },
  watch: {
    tableData: {
      handler: function (val) {
        this.getcurrentNumber()
      },
    },
  },
  methods: {
    load() {
      // console.log(1)
      // if (this.currentList.length < this.tableData.length) {
      //   this.currentList.push(this.tableData.slice(m, n))
      // } else {
      //   return false
      // }
    },
    getcurrentNumber(val) {
      if (val) this.currentPage = val
      const m = (this.currentPage - 1) * 10
      const n = this.currentPage * 10
      this.currentList = this.tableData.slice(m, n)
    },
    leftClick() {
      this.currentPage -= 1
    },
    rightClick() {
      this.currentPage += 1
    },
    getHeaderClass() {
      return {
        background: '#010306',
        color: '#fff',
      }
    },
    getRowClass({ row, column, rowIndex, columnIndex }) {
      if (rowIndex % 2 === 0) {
        return {
          background: 'rgba(25,25,25,.4)',
          color: '#fff',
        }
      } else {
        return {
          background: 'rgba(12,49,63,.4)',
          color: '#fff',
        }
      }
    },
    close() {
      this.$emit('close')
    },
  },
}
</script>

<style lang="scss" scoped>
::v-deep .el-dialog {
  background: rgba(10, 19, 23, 0.8);
  color: #fff;
  padding: 50px 60px 45px 60px;
  .el-dialog__title {
    color: #fff;
  }
  .export-table {
    width: 80px;
    line-height: 30px;
    padding: 0 10px;
    height: 30px;
    text-align: center;
    background-color: #3399ff;
    cursor: pointer;
    margin-left: 10px;
    color: #fff;
  }
  .el-table--enable-row-hover .el-table__body tr:hover > td {
    background-color: transparent !important;
  }
  .el-table::before {
    height: 0px;
  }
  /* 表格内背景颜色 */
  .el-table th,
  .el-table tr,
  .el-table,
  .el-table td {
    border: 0;
    background-color: transparent;
  }
  .hover-row .el-table__cell {
    background-color: transparent;
  }
  .el-table__footer > tbody > tr > td:nth-child(1) {
    color: #fff;
    background-color: rgba(39, 129, 174, 1);
  }
  .el-table__fixed {
    background: rgba(25, 25, 25, 1);
    .el-table__fixed-header-wrapper > table > thead > tr > th:nth-child(1) {
      background: rgb(1, 3, 6);
      color: rgb(255, 255, 255);
      border: 1px solid #30a0d8;
      border-right: none;
    }
  }
  .el-table__fixed::before {
    display: none;
  }
  .el-table__footer-wrapper {
    background-color: rgba(39, 129, 174, 0.8);
    td {
      color: #fff;
    }
  }
  .el-checkbox__inner {
    border: 2px solid #407997;
    background-color: rgba(21, 61, 57, 0.7);
    border-radius: 0;
  }
  .el-table {
    color: #fff;
  }
  .el-table__header-wrapper {
    border: 1px solid #30a0d8;
  }
  .el-table td,
  .el-table th.is-leaf {
    border-bottom: none;
  }
}
::v-deep .el-dialog__headerbtn {
  font-size: 30px;
  border-radius: 50%;
  height: 40px;
  width: 40px;
  background-color: #5493f1;
  .el-dialog__close {
    color: #fff;
  }
}
.dialog-title {
  display: flex;
  align-items: center;
  > span:nth-child(1) {
    font-size: 2.6rem;
    margin-right: 15px;
  }
  .search {
    height: 40px;
    width: 120px;
    background-color: #3399ff;
    line-height: 40px;
    text-align: center;
    font-size: 1.6rem;
  }
}
@import '~@/styles/pagination.scss';
</style>
