import { login, fetchMenu } from '@/api/user'
import { storage, recursion } from '@/utils/utils'
import { resetRouter } from '@/router'
import { Message } from 'element-ui'
import store from '@/store'
const getDefaultState = () => {
  return {
    name: '',
    avatar: '',
    routers: [],
    roles: ['admin']
  }
}

const state = getDefaultState()

const mutations = {
  RESET_STATE: state => {
    Object.assign(state, getDefaultState())
  },
  SET_MENU: (state, data) => {
    state.routers = data
  },
  RESET_MENU: state => {
    state.routers = []
  },
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  },
  SET_ROLES: (state, roles) => {
    state.roles = roles
  }
}

const actions = {
  login({ commit }, userInfo) {
    const { userid, password } = userInfo
    return new Promise((resolve, reject) => {
      login({ userid: userid.trim(), password: password })
        .then(res => {
          if (res === 'ok') {
            fetchMenu({ type: 'front' }).then(res => {
              const online = recursion(res.MENU)
              const date = new Date().valueOf()
              storage.set('energyMenu', online, date)
              commit('SET_MENU', online)
              resolve(res)
            })
          } else {
            Message.error(res)
            const url = window.location.href
            const redirect_uri = `${url.substring(0, url.lastIndexOf('#'))}#/login`
            window.location.href = redirect_uri
            resolve(res)
          }
        })
        .catch(error => {
          reject(error)
        })
    })
  },

  // get user info
  getInfo({ commit }) {
    commit('SET_ROLES', ['admin'])
    // storage.set('role', ['admin'])
  },

  logout({ commit }) {
    storage.clear()
    resetRouter()
    store.commit('permission/RESET_ROUTES')
    commit('RESET_STATE')
  },

  resetToken({ commit }) {
    return new Promise(resolve => {
      commit('RESET_STATE')
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
