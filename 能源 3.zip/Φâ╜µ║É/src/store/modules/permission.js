const state = {
  addRoutes: []
}

const mutations = {
  SET_ROUTES: (state, routes) => {
    state.addRoutes = routes
  },
  RESET_ROUTES: state => {
    state.addRoutes = []
  }
}

const actions = {}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
